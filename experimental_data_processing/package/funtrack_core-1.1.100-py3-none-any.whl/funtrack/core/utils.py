"""core 通用工具函数。"""

from __future__ import annotations

import cv2


def read_obstacle_video_frame_size_px(video_path: str) -> tuple[int, int] | None:
    """读取视频标称宽高（像素）；读取失败返回 ``None``。"""
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        return None
    try:
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        if w <= 0 or h <= 0:
            return None
        return (w, h)
    finally:
        cap.release()
