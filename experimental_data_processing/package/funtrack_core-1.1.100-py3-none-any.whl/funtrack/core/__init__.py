"""核心：任务基类与路径约定。"""

from funtrack.core.base import BaseTask, output_base_name, task_record_path
from funtrack.core.dependencies import (
    TaskDependency,
    ensure_dependencies,
    find_input_from_task_record,
    infer_video_path_from_tracks_table,
)
from funtrack.core.pipeline_request import FuntrackTaskRequest
from funtrack.core.pipeline_response import FuntrackPipelineResponse
from funtrack.core.utils import read_obstacle_video_frame_size_px

__all__ = [
    "BaseTask",
    "FuntrackPipelineResponse",
    "FuntrackTaskRequest",
    "output_base_name",
    "task_record_path",
    "TaskDependency",
    "ensure_dependencies",
    "infer_video_path_from_tracks_table",
    "find_input_from_task_record",
    "read_obstacle_video_frame_size_px",
]
