"""流水线 Response：在 nltspec ``BaseResponse`` 上增加 ``pipeline_value``（兼容原 ``run()`` 返回值）。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from nltspec.task import BaseResponse


@dataclass
class FuntrackPipelineResponse(BaseResponse):
    """业务层返回值置于 ``pipeline_value``；结构化轨迹仍用 ``events``。"""

    pipeline_value: Optional[Any] = None
