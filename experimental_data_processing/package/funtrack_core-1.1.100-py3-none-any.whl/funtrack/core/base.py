"""
funtrack 流水线任务基类。

继承 ``nltspec.task.BaseTask``：编排语义（Request / Response、``run`` 生命周期、``events``）由 nltspec
提供；本层在 :meth:`execute` 中串联校验、依赖、可选跳过已缓存结果、业务 :meth:`_run` 与
``.task/<task_name>.json`` 落盘逻辑。人读排障日志仍用 ``nltlog``，与 ``response.events`` 分工。
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

from nltlog import getLogger
from nltspec.task import BaseRequest
from nltspec.task import BaseTask as SpecBaseTask

from funtrack.core.pipeline_request import FuntrackTaskRequest
from funtrack.core.pipeline_response import FuntrackPipelineResponse

logger = getLogger("funtrack")

TASK_RECORD_SUBDIR = ".task"
"""任务元数据与结果摘要的投放目录名（位于 output_dir 下）。"""


def task_record_path(output_dir: Path, task_name: str) -> Path:
    """任务记录 JSON 路径：``output_dir / .task / {task_name}.json``。"""
    return output_dir / TASK_RECORD_SUBDIR / f"{task_name}.json"


def output_base_name(path, from_trajectory_data: bool = False) -> str:
    """
    从结果文件路径得到输出文件名基名（无扩展名）。
    from_trajectory_data=True 时按任务结果命名后缀回推视频基名。
    """
    stem = Path(path).stem
    if from_trajectory_data:
        if stem.endswith("_101_tracks"):
            return stem[: -len("_101_tracks")]
        if stem.endswith("_201_particle_kinematics"):
            return stem[: -len("_201_particle_kinematics")]
        if stem.endswith("_particle_kinematics"):  # 旧格式兼容
            return stem[: -len("_particle_kinematics")]
        if stem.endswith("_202_particle_statistics"):
            return stem[: -len("_202_particle_statistics")]
        # 圆形分析格式：{base}_301_circle_analysis_{frame_suffix}_idx_{idx_suffix}
        if "_301_circle_analysis_" in stem:
            return stem.split("_301_circle_analysis_")[0]
        # 数据分析格式：{base}_302_analyzed
        if stem.endswith("_302_analyzed"):
            return stem[: -len("_302_analyzed")]
        if stem.endswith("_analyzed"):  # 旧格式兼容
            return stem[: -len("_analyzed")]
    return stem


class BaseTask(SpecBaseTask[BaseRequest, FuntrackPipelineResponse], ABC):
    """流水线任务：继承 nltspec ``BaseTask``，在 ``execute`` 中写入 funtrack 侧落盘与业务结果。"""

    task_name: str = "task"

    def __init__(self, request: BaseRequest) -> None:
        super().__init__(request)
        self.results: Any = None
        self._last_run_error: Optional[Exception] = None
        od = getattr(self.request, "output_dir", None)
        self.output_dir = Path(od) if od else Path("output")
        self.output_dir.mkdir(exist_ok=True, parents=True)
        self.output_prefix = str(getattr(self.request, "output_prefix", "") or "")

    def build_response(self) -> FuntrackPipelineResponse:
        r = FuntrackPipelineResponse()
        r.request_id = self.request.request_id
        return r

    def run(
        self, *args: Any, overwrite: Optional[bool] = None, **kwargs: Any
    ) -> FuntrackPipelineResponse:
        """支持 ``overwrite=`` 覆盖请求中的同名字段（供依赖递归时传入）。"""
        prev_ow: Optional[bool] = None
        if overwrite is not None and isinstance(self.request, FuntrackTaskRequest):
            prev_ow = self.request.overwrite
            self.request.overwrite = overwrite
        try:
            return super().run(*args, **kwargs)
        finally:
            if (
                overwrite is not None
                and prev_ow is not None
                and isinstance(self.request, FuntrackTaskRequest)
            ):
                self.request.overwrite = prev_ow

    def execute(
        self,
        response: FuntrackPipelineResponse,
        *args: Any,
        **kwargs: Any,
    ) -> FuntrackPipelineResponse:
        self._last_run_error = None
        if not self.validate_inputs():
            raise ValueError(f"{self.__class__.__name__}: validate_inputs failed")

        from funtrack.core.dependencies import ensure_dependencies

        ow = bool(getattr(self.request, "overwrite", False))
        if not ensure_dependencies(self, overwrite=ow):
            raise RuntimeError(f"{self.__class__.__name__}: dependencies not satisfied")

        if not self.validate_inputs():
            raise ValueError(
                f"{self.__class__.__name__}: validate_inputs failed after dependencies"
            )

        task_name = getattr(self.__class__, "task_name", self.__class__.__name__)
        task_json_path = task_record_path(self.output_dir, task_name)

        short_circuit = self._maybe_short_circuit_from_record(
            task_name, task_json_path, overwrite=ow
        )
        if short_circuit is not None:
            response.pipeline_value = short_circuit
            response.payload = {"task": task_name, "pipeline_value": short_circuit}
            return response

        start_dt = datetime.now()
        try:
            ret = self._run(**kwargs)
        except Exception as e:
            self._last_run_error = e
            logger.error(f"任务执行异常: {e}", exc_info=True)
            raise
        end_dt = datetime.now()
        duration_sec = (end_dt - start_dt).total_seconds()
        task_json_path.parent.mkdir(exist_ok=True)
        paths = self.get_output_paths()
        output_paths = {k: str(p) for k, p in paths.items()}
        record = {
            "task": task_name,
            "start_time": start_dt.isoformat(),
            "end_time": end_dt.isoformat(),
            "duration_sec": round(duration_sec, 2),
            "inputs": self.get_task_inputs(),
            "output_paths": output_paths,
            "results": self.get_task_results() or {},
        }
        with open(task_json_path, "w", encoding="utf-8") as f:
            json.dump(record, f, ensure_ascii=False, indent=2)

        response.pipeline_value = ret
        response.payload = {
            "task": task_name,
            "pipeline_value": ret,
            "output_paths": output_paths,
            "duration_sec": round(duration_sec, 2),
        }
        return response

    def _maybe_short_circuit_from_record(
        self, task_name: str, task_json_path: Path, *, overwrite: bool
    ) -> Optional[Any]:
        if task_name != "101" or overwrite or not task_json_path.exists():
            return None
        try:
            with open(task_json_path, encoding="utf-8") as f:
                record = json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"读取任务记录失败，将重新执行: {e}")
            return None
        output_paths = record.get("output_paths") or {}
        if not output_paths or not all(Path(p).exists() for p in output_paths.values()):
            return None
        self.results = self._results_from_skip_record(record)
        self.apply_output_paths(self.get_output_paths())
        return self.get_skip_return_value(record)

    @abstractmethod
    def validate_inputs(self) -> bool:
        pass

    @abstractmethod
    def _run(self, **kwargs) -> Any:
        pass

    @abstractmethod
    def get_output_paths(self) -> Dict[str, Path]:
        pass

    def get_task_inputs(self) -> Dict[str, Any]:
        return {}

    def get_task_results(self) -> Optional[Dict[str, Any]]:
        return None

    def get_dependencies(self) -> list:
        return []

    def apply_output_paths(self, paths: Dict[str, Path]) -> None:
        pass

    def _results_from_skip_record(self, record: Dict[str, Any]) -> Dict[str, Any]:
        return record.get("results") or {}

    def get_skip_return_value(self, record: Dict[str, Any]) -> Any:
        return None

    def print_summary(self):
        pass

    def print_info(self, **kwargs):
        for key, value in kwargs.items():
            try:
                if hasattr(value, "item") and callable(getattr(value, "item", None)):
                    value = value.item()
            except Exception:
                pass
            logger.info(f"{key}: {value}")
        logger.info("=" * 60)
