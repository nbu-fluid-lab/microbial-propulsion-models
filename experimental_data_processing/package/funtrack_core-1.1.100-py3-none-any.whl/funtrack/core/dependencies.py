"""
任务依赖管理系统：自动检测和运行上游依赖任务。

依赖关系：
- TrajectoryTrackingTask (funtrack.task.tracking) -> 根节点，依赖 video_path
- ParticleKinematicsTask (kinematics) -> 依赖 TrajectoryTrackingTask
- TrajectoryDataTask (data_analysis) -> 依赖 ParticleKinematicsTask
- CircleRegionTask (circle) -> 依赖 ParticleKinematicsTask
"""

import json
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Type

from nltlog import getLogger
from nltspec.task import TaskStatus

from funtrack.core.base import BaseTask, output_base_name, task_record_path

logger = getLogger("funtrack")


def find_input_from_task_record(output_dir: Path, task_name: str, input_key: str) -> Optional[Any]:
    """
    从任务记录中查找输入参数。

    参数:
        output_dir: 输出目录
        task_name: 任务名称
        input_key: 输入参数的键名（如 "video_path"）

    返回:
        输入参数值，如果找不到则返回 None
    """
    record_path = task_record_path(output_dir, task_name)
    if not record_path.exists():
        return None

    try:
        with open(record_path, encoding="utf-8") as f:
            record = json.load(f)
        inputs = record.get("inputs") or {}
        value = inputs.get(input_key)
        if value:
            path = Path(value)
            if path.exists():
                return path
            return value  # 返回原始值（可能是字符串路径）
    except (json.JSONDecodeError, OSError, KeyError):
        pass

    return None


def infer_video_path_from_tracks_table(track_data_path: Path, output_dir: Path) -> Optional[Path]:
    """
    从轨迹结果路径推导视频路径。

    尝试方法：
    1. 从任务记录中读取原始 video_path
    2. 从轨迹结果路径的目录结构推导（假设 output_dir/video_stem_101_tracks.*）

    参数:
        track_data_path: 轨迹结果路径
        output_dir: 输出目录

    返回:
        视频路径，如果找不到则返回 None
    """
    # 方法1: 从任务记录读取原始 video_path（支持新编号和旧名称）
    video_path_str = find_input_from_task_record(output_dir, "101", "video_path")
    if not video_path_str:
        video_path_str = find_input_from_task_record(
            output_dir, "tracking", "video_path"
        )  # 向后兼容
    if video_path_str:
        video_path = Path(video_path_str)
        if video_path.exists():
            return video_path

    # 方法2: 从结果路径推导（格式为 output_dir/video_stem_101_tracks.*）
    base = output_base_name(track_data_path, from_trajectory_data=True)
    possible_dirs = [track_data_path.parent, output_dir, output_dir.parent]
    for dir_path in possible_dirs:
        for ext in [".mp4", ".avi", ".mov"]:
            video_path = dir_path / f"{base}{ext}"
            if video_path.exists():
                return video_path

    return None


class TaskDependency:
    """任务依赖项：描述一个任务依赖另一个任务的关系。"""

    def __init__(
        self,
        task_class: Type[BaseTask],
        build_params: Callable[[BaseTask], Dict[str, Any]],
        extract_input: Optional[Callable[[BaseTask, BaseTask], Dict[str, Any]]] = None,
        check_output: Optional[Callable[[BaseTask], Optional[Path]]] = None,
    ):
        """
        参数:
            task_class: 依赖的任务类
            build_params: 函数 (current_task) -> 依赖任务的参数字典
            extract_input: 可选，函数 (current_task, dependency_task) -> 更新当前任务输入的字典
            check_output: 可选，函数 (current_task) -> 依赖任务的预期输出路径，用于快速检查
        """
        self.task_class = task_class
        self.build_params = build_params
        self.extract_input = extract_input or (lambda ct, dt: {})
        self.check_output = check_output

    def create_dependency_task(self, current_task: BaseTask) -> BaseTask:
        """创建依赖任务实例。"""
        params = self.build_params(current_task)
        return self.task_class(**params)

    def update_current_task_inputs(self, current_task: BaseTask, dependency_task: BaseTask) -> None:
        """从依赖任务的输出更新当前任务的输入。"""
        updates = self.extract_input(current_task, dependency_task)
        for key, value in updates.items():
            if hasattr(current_task, key):
                setattr(current_task, key, value)
            else:
                logger.warning(f"任务 {current_task.__class__.__name__} 没有属性 {key}，跳过更新")

    def get_expected_output(self, current_task: BaseTask) -> Optional[Path]:
        """获取依赖任务的预期输出路径（如果可推导）。"""
        if self.check_output:
            return self.check_output(current_task)
        return None


def ensure_dependencies(
    task: BaseTask, overwrite: bool = False, visited: Optional[set] = None
) -> bool:
    """
    确保任务的所有依赖都已运行并生成输出文件。

    参数:
        task: 当前任务实例
        overwrite: 是否强制重新运行依赖任务
        visited: 已访问的任务集合（用于循环检测），内部使用

    返回:
        True 如果所有依赖都满足，False 如果有依赖失败
    """
    if visited is None:
        visited = set()

    task_id = id(task)
    if task_id in visited:
        logger.error(f"检测到循环依赖: {task.__class__.__name__}")
        return False
    visited.add(task_id)

    dependencies = task.get_dependencies()
    if not dependencies:
        visited.remove(task_id)  # 清理 visited
        return True

    logger.info(f"检查任务 {task.__class__.__name__} 的 {len(dependencies)} 个依赖...")

    success = True
    for dep in dependencies:
        # 快速检查：如果可推导预期输出路径，先检查文件是否存在
        expected_output = dep.get_expected_output(task)
        if expected_output and expected_output.exists() and not overwrite:
            logger.debug(f"依赖输出已存在: {expected_output}")
            # 创建依赖任务实例以更新当前任务输入
            dep_task = dep.create_dependency_task(task)
            dep.update_current_task_inputs(task, dep_task)
            continue

        dep_task = dep.create_dependency_task(task)

        # 验证依赖任务的输入
        if not dep_task.validate_inputs():
            logger.error(
                f"依赖任务 {dep_task.__class__.__name__} 输入验证失败，"
                f"无法为 {task.__class__.__name__} 创建依赖"
            )
            success = False
            break

        # 检查依赖任务的输出是否存在
        dep_outputs = dep_task.get_output_paths()
        all_outputs_exist = all(Path(p).exists() for p in dep_outputs.values())

        if not all_outputs_exist or overwrite:
            logger.info(f"运行依赖任务: {dep_task.__class__.__name__}")
            # 递归运行依赖任务（dep_task.run() 内部会调用 ensure_dependencies，形成递归）
            result = dep_task.run(overwrite=overwrite)
            if result.status != TaskStatus.SUCCEEDED:
                logger.error(f"依赖任务 {dep_task.__class__.__name__} 执行失败: {result.status}")
                success = False
                break

            # 再次检查输出（防止任务返回成功但文件未生成）
            dep_outputs = dep_task.get_output_paths()
            if not all(Path(p).exists() for p in dep_outputs.values()):
                logger.error(
                    f"依赖任务 {dep_task.__class__.__name__} 输出文件不存在: {dep_outputs}"
                )
                success = False
                break

        # 从依赖任务的输出更新当前任务的输入
        dep.update_current_task_inputs(task, dep_task)
        logger.debug(f"已从 {dep_task.__class__.__name__} 更新 {task.__class__.__name__} 的输入")

    visited.remove(task_id)  # 清理 visited
    return success
