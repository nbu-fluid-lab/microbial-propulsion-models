"""流水线侧 Request 扩展字段（与 nltspec ``BaseRequest`` 组合）。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from nltspec.task import BaseRequest


@dataclass
class FuntrackTaskRequest(BaseRequest):
    """funtrack 任务公共字段：输出目录、前缀、是否覆盖重跑缓存。"""

    output_dir: Optional[str] = None
    output_prefix: str = ""
    overwrite: bool = False
