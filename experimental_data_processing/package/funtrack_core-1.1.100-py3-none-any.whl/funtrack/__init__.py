"""
funtrack - 微生物轨迹跟踪和分析工具包

提供视频中微生物（如细菌、草履虫等）的轨迹跟踪、数据分析和可视化功能。
"""

from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)

from funtrack.core import BaseTask
from funtrack.task import (
    BacteriaTracker,
    CircleRegionTask,
    KINEMATICS_COLUMNS,
    ParticleKinematicsTask,
    ParticleStatisticsTask,
    TrajectoryDataTask,
    TrajectoryTrackingTask,
    VideoInfoTask,
    analyze_and_visualize,
    analyze_circle_trajectories,
    analyze_tracks,
    calculate_angle,
    calculate_angular_velocity,
    calculate_velocity,
    estimate_detection_params,
    filter_kinematics_by_statistics,
    filter_particles_by_statistics,
    filter_tracks,
    get_particle_indices,
    plot_trajectory_segment,
    smooth_tracks,
)
from funtrack.utils import extract_video_info

__all__ = [
    # Base
    "BaseTask",
    # Video Info
    "VideoInfoTask",
    "extract_video_info",
    # Tracker
    "BacteriaTracker",
    "TrajectoryTrackingTask",
    "estimate_detection_params",
    # Kinematics (canonical base for downstream)
    "KINEMATICS_COLUMNS",
    "ParticleKinematicsTask",
    # Statistics
    "ParticleStatisticsTask",
    "filter_particles_by_statistics",
    "get_particle_indices",
    "filter_kinematics_by_statistics",
    # Trajectory Data
    "TrajectoryDataTask",
    "analyze_and_visualize",
    "analyze_tracks",
    "calculate_velocity",
    "calculate_angle",
    "calculate_angular_velocity",
    "filter_tracks",
    "smooth_tracks",
    # Circle
    "CircleRegionTask",
    "analyze_circle_trajectories",
    "plot_trajectory_segment",
]
