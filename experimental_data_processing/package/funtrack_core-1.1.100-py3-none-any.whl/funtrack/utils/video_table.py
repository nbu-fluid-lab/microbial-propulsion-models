"""视频文件信息表：扫描目录并返回 DataFrame。"""

import os
from pathlib import Path
from typing import Optional

import pandas as pd
from nltlog import getLogger

from .video import extract_video_info

logger = getLogger("funtrack")


def format_file_size(size_bytes):
    if size_bytes is None or size_bytes < 0:
        return ""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    if size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.2f} KB"
    if size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"
    return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"


def all_videos_with_info(video_root: str, output_path: Optional[str] = None) -> pd.DataFrame:
    """
    扫描目录并生成视频信息表。
    output_path 可选，若提供则写为 parquet 文件。
    """
    video_paths = sorted(
        os.path.join(root, f)
        for root, _, files in os.walk(video_root)
        for f in files
        if f.lower().endswith(".mp4")
    )
    if not video_paths:
        logger.warning("未找到 .mp4 视频")
        return pd.DataFrame()

    rows = []
    for video_path in video_paths:
        info = extract_video_info(video_path)
        if info.get("error"):
            continue
        w = info.get("width")
        h = info.get("height")
        resolution = f"{w}x{h}" if (w and h) else ""
        rows.append(
            {
                "video_path": video_path,
                "filename": info.get("filename", Path(video_path).name),
                "file_size": format_file_size(info.get("file_size_bytes")),
                "duration_sec": info.get("duration_sec"),
                "frame_count": info.get("frame_count"),
                "resolution": resolution,
                "fps": info.get("fps"),
                "width": w,
                "height": h,
                "experimenter": "",
                "particle_type": "",
                "scale_um_per_pixel": 1,
                "circle_radius_um": 100,
                "obstacle_circle_count": 0,
            }
        )
    df = pd.DataFrame(rows).sort_values("video_path")
    if output_path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        df.to_parquet(out, index=False)
        logger.info(f"已写入 {out}")
    return df
