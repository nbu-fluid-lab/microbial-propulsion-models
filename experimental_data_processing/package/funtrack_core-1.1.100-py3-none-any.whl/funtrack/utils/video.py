"""视频相关工具。"""

from pathlib import Path
from typing import Any, Dict

import cv2


def extract_video_info(video_path: str) -> Dict[str, Any]:
    """从视频文件提取基础信息（路径、文件大小、尺寸、高宽比、帧数、帧率等）。"""
    path = Path(video_path).resolve()
    info: Dict[str, Any] = {
        "path": str(path),
        "filename": path.name,
        "stem": path.stem,
        "file_size_bytes": path.stat().st_size if path.exists() else None,
    }

    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        info["error"] = "无法打开视频文件"
        return info

    try:
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        duration_sec = frame_count / fps if fps and fps > 0 else None

        info["width"] = width
        info["height"] = height
        info["aspect_ratio"] = round(width / height, 4) if height else None
        info["frame_count"] = frame_count
        info["fps"] = round(fps, 2) if fps is not None else None
        info["duration_sec"] = round(duration_sec, 2) if duration_sec is not None else None
    finally:
        cap.release()

    return info
