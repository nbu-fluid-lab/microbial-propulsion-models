"""轨迹跟踪任务：封装 BacteriaTracker 为 BaseTask。"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict

from nltlog import getLogger

from funtrack.core import BaseTask, FuntrackTaskRequest
from funtrack.task.tracking.auto_params import (
    estimate_tracking_param_overrides,
    log_estimate_result,
)
from funtrack.task.tracking.engine import BacteriaTracker

logger = getLogger("funtrack")


@dataclass
class TrajectoryTrackingRequest(FuntrackTaskRequest):
    video_path: str = ""
    min_area: int = 2
    max_area: int = 2000
    max_distance: int = 50
    area_weight: float = 0.3
    velocity_weight: float = 0.2
    trail_length: int = 300
    bg_history: int = 500
    bg_threshold: Any | None = None
    bg_learning_rate: Any | None = None
    debug: bool = False
    preprocess_sharpen: bool = False
    preprocess_denoise: bool = False
    preprocess_clahe: bool = False
    max_age: int = 10
    detection_scale: float = 1.0
    # 正式跟踪前按分辨率/fps/前景面积采样自动调整 max_area、max_distance 等
    auto_estimate_tracking_params: bool = True
    tracking_extras: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TrajectoryTrackingRequest:
        """与 Job params 兼容：未声明在 dataclass 中的键进入 ``tracking_extras``。"""
        payload = dict(data or {})
        known = set(cls.__dataclass_fields__) - {"tracking_extras"}
        ctor: dict[str, Any] = {}
        extras: dict[str, Any] = {}
        te_in = payload.get("tracking_extras")
        if isinstance(te_in, dict):
            extras.update(te_in)
        for key, val in payload.items():
            if key == "tracking_extras":
                continue
            if key in known:
                ctor[key] = val
            else:
                extras[key] = val
        if extras:
            ctor["tracking_extras"] = extras
        return cls(**{k: v for k, v in ctor.items() if k in cls.__dataclass_fields__})


class TrajectoryTrackingTask(BaseTask):
    """轨迹识别任务：从视频中识别和跟踪轨迹"""

    task_name = "101"

    def __init__(self, request: TrajectoryTrackingRequest) -> None:
        super().__init__(request)
        self.tracking_params = self._build_tracking_params()
        self.output_video = None

    def _build_tracking_params(self) -> dict[str, Any]:
        r = self.request
        params: Dict[str, Any] = {
            "min_area": r.min_area,
            "max_area": r.max_area,
            "max_distance": r.max_distance,
            "area_weight": r.area_weight,
            "velocity_weight": r.velocity_weight,
            "trail_length": r.trail_length,
            "bg_history": r.bg_history,
            "bg_threshold": r.bg_threshold,
            "bg_learning_rate": r.bg_learning_rate,
            "debug": r.debug,
            "preprocess_sharpen": r.preprocess_sharpen,
            "preprocess_denoise": r.preprocess_denoise,
            "preprocess_clahe": r.preprocess_clahe,
            "max_age": r.max_age,
            "detection_scale": r.detection_scale,
        }
        params.update(r.tracking_extras or {})
        return params

    def validate_inputs(self) -> bool:
        vp = Path(self.request.video_path)
        if not vp.exists():
            logger.error(f"视频文件不存在: {vp}")
            return False
        return True

    def get_output_paths(self):
        return {}

    def get_task_inputs(self):
        return {"video_path": str(Path(self.request.video_path)), "params": self.tracking_params}

    def get_task_results(self):
        if not self.results or "summary" not in self.results:
            return None
        s = self.results["summary"]
        return {
            "total_tracks": s.get("total_tracks"),
            "tracks_info_count": len(s.get("tracks_info", [])),
        }

    def apply_output_paths(self, paths):
        return None

    def _results_from_skip_record(self, record):
        r = record.get("results") or {}
        return {"tracker": None, "summary": r}

    def get_skip_return_value(self, record):
        return (None, record.get("results", {}))

    def _run(self, **kwargs):
        params = {**self.tracking_params, **kwargs}
        video = str(Path(self.request.video_path))
        self.print_info(Input_Video=video)

        params.pop("overwrite", False)
        params.pop("visualize", None)

        if self.request.auto_estimate_tracking_params:
            try:
                overrides, est_meta = estimate_tracking_param_overrides(
                    video, current_params=params
                )
                log_estimate_result(est_meta, overrides)
                params.update(overrides)
            except Exception as e:
                logger.warning(f"101 参数预估失败，使用请求原始参数: {e}")

        self.tracking_params = dict(params)

        params.pop("two_stage_tracking", None)

        tracker = BacteriaTracker(video_path=video, **params)
        tracker.process_video()
        summary = tracker.get_tracks_summary()

        self.results = {"tracker": tracker, "summary": summary}
        return tracker, summary

    def print_summary(self):
        total_tracks = None
        if total_tracks is None and self.results:
            summary = (self.results or {}).get("summary") or (
                self.results
                if isinstance(self.results, dict) and "total_tracks" in (self.results or {})
                else None
            )
            total_tracks = summary.get("total_tracks") if summary else None
        if total_tracks is not None:
            logger.info("=" * 60)
            logger.info("Tracking Summary")
            logger.info("=" * 60)
            logger.info(f"Total Tracks: {total_tracks}")
            logger.info("=" * 60)
