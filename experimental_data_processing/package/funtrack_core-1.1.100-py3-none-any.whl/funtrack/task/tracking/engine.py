"""
跟踪引擎：检测与多目标跟踪算法（Track、BacteriaTracker）及参数估计。
"""

from pathlib import Path
from typing import Optional

import cv2
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist
from nltlog import getLogger
from tqdm import tqdm

logger = getLogger("funtrack")


class Track:
    """单个轨迹对象，包含位置、速度、面积等信息"""

    def __init__(self, track_id, x, y, area, frame_num):
        self.track_id = track_id
        self.frame_num = frame_num

        # 卡尔曼滤波器（用于预测位置和速度）
        self.kalman = cv2.KalmanFilter(4, 2)  # 4个状态（x, y, vx, vy），2个观测（x, y）
        self.kalman.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
        self.kalman.transitionMatrix = np.array(
            [[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32
        )
        self.kalman.processNoiseCov = 0.03 * np.eye(4, dtype=np.float32)
        self.kalman.measurementNoiseCov = 0.1 * np.eye(2, dtype=np.float32)
        self.kalman.errorCovPost = np.eye(4, dtype=np.float32)

        # 初始化状态
        # self.kalman.statePre = np.array([x, y, 0, 0], dtype=np.float32)
        # self.kalman.statePost = np.array([x, y, 0, 0], dtype=np.float32)
        initial_state = np.array([[x], [y], [0], [0]], dtype=np.float32)
        self.kalman.statePre = initial_state.copy()
        self.kalman.statePost = initial_state.copy()

        # 轨迹历史
        self.positions = [(frame_num, x, y)]
        self.areas = [area]

        # 轨迹特征
        self.avg_area = area
        self.age = 0
        self.hit_streak = 1  # 连续匹配次数
        self.time_since_update = 0

    def predict(self):
        """预测下一帧的位置"""
        prediction = self.kalman.predict()
        # return prediction[0], prediction[1]
        return float(prediction[0, 0]), float(prediction[1, 0])

    def update(self, x, y, area, frame_num):
        """更新轨迹"""
        measurement = np.array([[x], [y]], dtype=np.float32)
        self.kalman.correct(measurement)

        self.positions.append((frame_num, x, y))
        self.areas.append(area)

        # 更新平均面积（使用指数移动平均）
        self.avg_area = 0.7 * self.avg_area + 0.3 * area

        self.age += 1
        self.hit_streak += 1
        self.time_since_update = 0
        self.frame_num = frame_num

    def get_velocity(self):
        """获取当前速度"""
        if len(self.positions) < 2:
            return 0, 0
        # 使用最近几帧计算速度
        recent = min(5, len(self.positions))
        if recent < 2:
            return 0, 0

        x1, y1 = self.positions[-recent][1], self.positions[-recent][2]
        x2, y2 = self.positions[-1][1], self.positions[-1][2]
        frames_diff = self.positions[-1][0] - self.positions[-recent][0]
        if frames_diff == 0:
            return 0, 0
        return (x2 - x1) / frames_diff, (y2 - y1) / frames_diff

    def get_position(self):
        """获取当前位置"""
        return self.positions[-1][1], self.positions[-1][2]


def _preprocess_frame(frame, sharpen=False, denoise=False, clahe=False):
    """
    可选帧预处理，用于模糊或低对比度视频。
    """
    out = frame
    if denoise:
        out = cv2.bilateralFilter(out, d=5, sigmaColor=50, sigmaSpace=50)
    if sharpen:
        kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]], dtype=np.float32)
        out = cv2.filter2D(out, -1, kernel)
        out = np.clip(out, 0, 255).astype(np.uint8)
    if clahe:
        lab = cv2.cvtColor(out, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe_obj = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        l = clahe_obj.apply(l)
        out = cv2.merge([l, a, b])
        out = cv2.cvtColor(out, cv2.COLOR_LAB2BGR)
    return out


class BacteriaTracker:
    """大肠杆菌跟踪器"""

    def __init__(
        self,
        video_path,
        # 放宽颗粒面积限制：降低最小面积、提高最大面积，减少漏检
        min_area=2,
        max_area=2000,
        max_distance=50,
        area_weight=0.3,
        velocity_weight=0.2,
        trail_length=300,
        bg_history=500,
        bg_threshold=None,
        bg_learning_rate=None,
        debug=False,
        preprocess_sharpen=False,
        preprocess_denoise=False,
        preprocess_clahe=False,
        max_age=10,
        detection_scale=1.0,
    ):
        self.video_path = video_path
        self.min_area = min_area
        self.max_area = max_area
        self.max_distance = max_distance
        self.area_weight = area_weight
        self.velocity_weight = velocity_weight
        self.trail_length = trail_length
        self.debug = debug
        self.preprocess_sharpen = preprocess_sharpen
        self.preprocess_denoise = preprocess_denoise
        self.preprocess_clahe = preprocess_clahe
        self.max_age = max_age
        self.bg_learning_rate = bg_learning_rate
        self.detection_scale = max(0.25, min(1.0, float(detection_scale)))

        if bg_threshold is None:
            if max_area > 2000:
                bg_threshold = 30
            elif max_area > 1000:
                bg_threshold = 40
            elif max_area > 200:
                bg_threshold = 50
            else:
                bg_threshold = 25

        self.bg_subtractor = cv2.createBackgroundSubtractorMOG2(
            history=bg_history, varThreshold=bg_threshold, detectShadows=False
        )

        self.tracks = {}
        self.next_id = 0
        self.fps = None

    def detect_bacteria(self, frame, fg_mask, min_area=None, max_area=None):
        """从前景掩码中检测细菌/草履虫等目标，返回 [(x, y, area), ...]。"""
        min_area = min_area if min_area is not None else self.min_area
        max_area = max_area if max_area is not None else self.max_area
        if max_area > 2000:
            kernel_size = 9
        elif self.max_area > 1000:
            kernel_size = 7
        elif self.max_area > 500:
            kernel_size = 5
        elif self.max_area > 100:
            kernel_size = 3
        else:
            kernel_size = 2

        kernel_size = max(2, kernel_size)
        if kernel_size >= 3:
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (kernel_size, kernel_size))
        else:
            kernel = np.ones((2, 2), np.uint8)

        fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_CLOSE, kernel)
        if max_area > 100:
            fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel)

        contours, _ = cv2.findContours(fg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        detections = []
        for contour in contours:
            area = cv2.contourArea(contour)
            if min_area <= area <= max_area:
                M = cv2.moments(contour)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    detections.append((cx, cy, area))

        if self.debug and len(contours) > 0:
            all_areas = [cv2.contourArea(c) for c in contours]
            logger.debug(
                f"检测到 {len(contours)} 个轮廓, "
                f"面积范围: {min(all_areas):.0f}-{max(all_areas):.0f}, "
                f"有效检测: {len(detections)} (范围: {min_area}-{max_area})"
            )

        return detections

    def compute_cost_matrix(self, tracks, detections):
        """计算轨迹和检测之间的代价矩阵（向量化，颗粒多时显著加速）。"""
        n_tracks = len(tracks)
        n_detections = len(detections)
        if n_tracks == 0 or n_detections == 0:
            return np.full((n_tracks, n_detections), np.inf)

        # 收集轨迹预测与速度 (单层循环，无内层)
        pred_xy = np.empty((n_tracks, 2), dtype=np.float64)
        vx = np.empty(n_tracks, dtype=np.float64)
        vy = np.empty(n_tracks, dtype=np.float64)
        avg_area = np.empty(n_tracks, dtype=np.float64)
        for i, track in enumerate(tracks):
            pred_xy[i, 0], pred_xy[i, 1] = track.predict()
            vx[i], vy[i] = track.get_velocity()
            avg_area[i] = track.avg_area

        det_arr = np.array(detections, dtype=np.float64)
        det_xy = det_arr[:, :2]
        det_area = det_arr[:, 2]

        # 位置距离 (T, D)
        pos_dist = cdist(pred_xy, det_xy, metric="euclidean")

        # 速度一致性得分 (T, D)
        dx = det_xy[:, 0] - pred_xy[:, 0:1]
        dy = det_xy[:, 1] - pred_xy[:, 1:2]
        vel_mag = np.sqrt(vx * vx + vy * vy)
        det_mag = np.sqrt(dx * dx + dy * dy)
        cos_angle = (vx[:, np.newaxis] * dx + vy[:, np.newaxis] * dy) / (
            vel_mag[:, np.newaxis] * det_mag + 1e-12
        )
        vel_active = (np.abs(vx) > 0.1) | (np.abs(vy) > 0.1)
        det_active = det_mag > 0.1
        vel_score = np.where(
            vel_active[:, np.newaxis] & det_active,
            np.where(cos_angle < 0, 100.0, (1.0 - cos_angle) * 20.0),
            0.0,
        )

        # 面积得分 (T, D)
        area_ratio = np.abs(avg_area[:, np.newaxis] - det_area) / np.maximum(
            np.maximum(avg_area[:, np.newaxis], det_area), 1.0
        )
        area_score = area_ratio * 30.0

        cost = pos_dist + vel_score * self.velocity_weight + area_score * self.area_weight
        cost = np.asarray(cost, dtype=np.float64)
        cost[pos_dist > self.max_distance] = np.inf

        # 面积差异过大时禁止匹配，减少 A 经过 B 时把 B 识别成 A 的误关联
        area_ratio_val = np.maximum(avg_area[:, np.newaxis], 1.0) / np.maximum(det_area, 1.0)
        cost[area_ratio_val > 2.0] = np.inf  # 检测面积远小于轨迹
        cost[area_ratio_val < 0.5] = np.inf  # 检测面积远大于轨迹

        return cost

    def associate_detections_to_tracks(self, cost_matrix, threshold=0.5):
        """
        使用匈牙利算法做全局最优匹配，减少两颗粒交汇时的 ID 互换。
        只接受代价 <= max_cost 的匹配，其余视为未匹配。
        """
        n_tracks, n_detections = cost_matrix.shape
        if n_tracks == 0 or n_detections == 0:
            return [], list(range(n_tracks)), list(range(n_detections))

        max_cost = self.max_distance * threshold
        # 复制一份用于求解：inf 改为大数，否则 linear_sum_assignment 会忽略
        C = np.where(np.isfinite(cost_matrix), cost_matrix, 1e10)
        row_ind, col_ind = linear_sum_assignment(C)

        matches = []
        for i, j in zip(row_ind, col_ind):
            if cost_matrix[i, j] <= max_cost and np.isfinite(cost_matrix[i, j]):
                matches.append((i, j))

        matched_t = {i for i, _ in matches}
        matched_d = {j for _, j in matches}
        unmatched_tracks = [i for i in range(n_tracks) if i not in matched_t]
        unmatched_detections = [j for j in range(n_detections) if j not in matched_d]
        return matches, unmatched_tracks, unmatched_detections

    def update_tracks(self, detections, frame_num):
        """更新跟踪轨迹。"""
        active_tracks = [
            track for track in self.tracks.values() if track.time_since_update < self.max_age
        ]

        if len(active_tracks) == 0:
            for x, y, area in detections:
                track = Track(self.next_id, x, y, area, frame_num)
                self.tracks[self.next_id] = track
                self.next_id += 1
            return

        if len(detections) == 0:
            for track in active_tracks:
                track.time_since_update += 1
                track.age += 1
            return

        cost_matrix = self.compute_cost_matrix(active_tracks, detections)
        matches, unmatched_tracks, unmatched_detections = self.associate_detections_to_tracks(
            cost_matrix, threshold=0.8
        )

        for track_idx, det_idx in matches:
            track = active_tracks[track_idx]
            det_x, det_y, det_area = detections[det_idx]
            track.update(det_x, det_y, det_area, frame_num)

        for track_idx in unmatched_tracks:
            track = active_tracks[track_idx]
            track.time_since_update += 1
            track.age += 1

        for det_idx in unmatched_detections:
            det_x, det_y, det_area = detections[det_idx]
            track = Track(self.next_id, det_x, det_y, det_area, frame_num)
            self.tracks[self.next_id] = track
            self.next_id += 1

    def process_video(self):
        """处理视频并跟踪细菌，仅输出轨迹数据。"""
        cap = cv2.VideoCapture(self.video_path)

        if not cap.isOpened():
            error_msg = f"无法打开视频文件: {self.video_path}"
            logger.error(error_msg)
            raise ValueError(error_msg)

        fps = cap.get(cv2.CAP_PROP_FPS)
        if fps <= 0:
            fps = 30.0
        self.fps = fps
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        logger.info(f"视频信息: {width}x{height}, {fps:.2f} FPS, {total_frames} 帧")

        frame_num = 0
        pbar = tqdm(
            total=total_frames,
            desc="处理视频",
            unit="帧",
            miniters=1,
            mininterval=0.5,
            smoothing=0.1,
        )

        last_active_tracks_count = 0
        last_detections_count = 0

        scale = self.detection_scale
        use_scale = scale < 1.0

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            if self.preprocess_sharpen or self.preprocess_denoise or self.preprocess_clahe:
                frame = _preprocess_frame(
                    frame,
                    sharpen=self.preprocess_sharpen,
                    denoise=self.preprocess_denoise,
                    clahe=self.preprocess_clahe,
                )

            work_frame = frame
            if use_scale:
                h, w = frame.shape[:2]
                work_frame = cv2.resize(
                    frame, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_LINEAR
                )

            if self.bg_learning_rate is not None:
                fg_mask = self.bg_subtractor.apply(work_frame, None, self.bg_learning_rate)
            else:
                fg_mask = self.bg_subtractor.apply(work_frame)

            if use_scale:
                min_a = max(2, int(self.min_area * scale * scale))
                max_a = max(min_a + 1, int(self.max_area * scale * scale))
                detections = self.detect_bacteria(
                    work_frame, fg_mask, min_area=min_a, max_area=max_a
                )
                inv = 1.0 / scale
                inv2 = inv * inv
                detections = [
                    (int(x * inv), int(y * inv), max(1, int(a * inv2))) for x, y, a in detections
                ]
            else:
                detections = self.detect_bacteria(work_frame, fg_mask)
            self.update_tracks(detections, frame_num)

            frame_num += 1
            pbar.update(1)

            if frame_num % 10 == 0:
                active_tracks_count = len(
                    [t for t in self.tracks.values() if t.time_since_update < self.max_age]
                )
                if (
                    active_tracks_count != last_active_tracks_count
                    or len(detections) != last_detections_count
                ):
                    pbar.set_postfix({"检测数": len(detections), "轨迹数": active_tracks_count})
                    last_active_tracks_count = active_tracks_count
                    last_detections_count = len(detections)

        pbar.close()
        cap.release()

        logger.success(f"处理完成！共跟踪到 {len(self.tracks)} 条轨迹")
        return self.tracks

    def save_tracks_data(self, output_path):
        """旧导出接口已废弃，请改用 tracks_dataframe() + 数据库写入。"""
        _ = output_path
        raise RuntimeError("save_tracks_data 已下线，请使用数据库结果写入流程")

    def tracks_dataframe(self) -> pd.DataFrame:
        """返回轨迹 DataFrame（frame, time, idx, x, y）。"""
        if self.fps is None or self.fps <= 0:
            fps = 30.0
        else:
            fps = float(self.fps)
        data = []
        for track_id, track in self.tracks.items():
            for frame_num, x, y in track.positions:
                time = round(frame_num / fps, 4)
                data.append({"frame": frame_num, "time": time, "idx": track_id, "x": x, "y": y})
        df = pd.DataFrame(data)
        if len(df) == 0:
            return df
        return df.sort_values(by=["frame", "idx"]).reset_index(drop=True)

    def get_tracks_summary(self):
        """获取轨迹摘要信息。"""
        summary = {"total_tracks": len(self.tracks), "tracks_info": []}

        for track_id, track in self.tracks.items():
            if len(track.positions) > 0:
                track_info = {
                    "track_id": track_id,
                    "frame_count": len(track.positions),
                    "start_frame": track.positions[0][0],
                    "end_frame": track.positions[-1][0],
                    "total_distance": 0,
                    "avg_area": track.avg_area,
                }

                for i in range(1, len(track.positions)):
                    x1, y1 = track.positions[i - 1][1], track.positions[i - 1][2]
                    x2, y2 = track.positions[i][1], track.positions[i][2]
                    track_info["total_distance"] += np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

                summary["tracks_info"].append(track_info)

        return summary


def _estimate_min_max_area(areas, min_floor=2, max_ceiling=20000):
    """从面积分布自动估算 min_area / max_area。"""
    areas = np.asarray(areas, dtype=np.float64)
    areas = np.sort(areas[areas >= min_floor])
    if len(areas) == 0:
        return min_floor, min(max_ceiling, 5000)
    n = len(areas)
    p_low = np.percentile(areas, 1)
    p_high = np.percentile(areas, 99)
    min_suggested = max(min_floor, int(p_low * 0.8))
    max_suggested = min(max_ceiling, int(p_high * 1.4))
    log_a = np.log10(areas + 1)
    hist, bin_edges = np.histogram(log_a, bins=min(50, max(10, n // 20)))
    peaks = []
    for i in range(1, len(hist) - 1):
        if hist[i] >= hist[i - 1] and hist[i] >= hist[i + 1] and hist[i] > 0:
            peaks.append((bin_edges[i] + bin_edges[i + 1]) / 2)
    if len(peaks) >= 2:
        peaks = sorted(peaks)
        low_log = min(peaks[0], np.log10(areas.min() + 1))
        high_log = max(peaks[-1], np.log10(areas.max() + 1))
        min_suggested = max(min_floor, min(min_suggested, int(10**low_log)))
        max_suggested = min(max_ceiling, max(max_suggested, int(10**high_log * 1.2)))
    if max_suggested <= min_suggested:
        max_suggested = min(max_ceiling, min_suggested + max(int(p_high * 0.5), 1))
    return min_suggested, max_suggested


def estimate_detection_params(video_path, sample_frames=15):
    """分析视频，自动估算检测参数。"""
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise ValueError(f"无法打开视频文件: {video_path}")
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    sample_interval = max(1, total_frames // max(sample_frames, 1))
    sampled = []
    for i in range(0, total_frames, sample_interval):
        cap.set(cv2.CAP_PROP_POS_FRAMES, i)
        ret, frame = cap.read()
        if ret:
            sampled.append(frame)
    cap.release()
    if not sampled:
        logger.warning("未能读取视频帧")
        return {"min_area": 2, "max_area": 5000, "max_distance": 100}

    bg_thresholds = [20, 30, 45]
    morph_small = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2, 2))
    morph_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    areas = []
    for var_t in bg_thresholds:
        bg = cv2.createBackgroundSubtractorMOG2(
            history=500, varThreshold=var_t, detectShadows=False
        )
        for frame in sampled:
            fg = bg.apply(frame)
            for do_open, k in [(False, morph_small), (True, morph_open)]:
                m = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, k)
                if do_open:
                    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k)
                contours, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                for c in contours:
                    a = cv2.contourArea(c)
                    if a >= 2:
                        areas.append(a)
    if len(areas) == 0:
        logger.warning("未能检测到目标，请检查视频或手动调整参数")
        return {"min_area": 2, "max_area": 5000, "max_distance": 100}
    areas = np.array(areas)
    min_area_suggested, max_area_suggested = _estimate_min_max_area(areas)
    if max_area_suggested > 2000:
        max_distance_suggested = 150
    elif max_area_suggested > 1000:
        max_distance_suggested = 100
    else:
        max_distance_suggested = 50
    suggested_params = {
        "min_area": int(min_area_suggested),
        "max_area": int(max_area_suggested),
        "max_distance": max_distance_suggested,
    }
    logger.info(
        f"检测到的目标面积范围: {areas.min():.0f} - {areas.max():.0f} 像素, "
        f"建议 min_area={suggested_params['min_area']}, max_area={suggested_params['max_area']}, "
        f"max_distance={suggested_params['max_distance']}"
    )
    return suggested_params
