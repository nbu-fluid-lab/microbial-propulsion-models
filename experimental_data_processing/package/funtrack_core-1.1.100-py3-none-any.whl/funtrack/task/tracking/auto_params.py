"""101 轨迹识别前的轻量参数预估（前景面积采样 + 分辨率/fps 启发式）。"""

from __future__ import annotations

import math
from typing import Any

import cv2
import numpy as np
from nltlog import getLogger

logger = getLogger("funtrack")


def probe_foreground_contour_areas(
    video_path: str,
    *,
    warmup_frames: int = 45,
    sample_frames: int = 28,
) -> tuple[list[float], int, int, float, int]:
    """
    用 MOG2 + 与引擎相近的形态学，采样多帧前景轮廓面积（不做面积上下限过滤）。
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"cannot open video: {video_path}")
    try:
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = float(cap.get(cv2.CAP_PROP_FPS))
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        if fps <= 0 or math.isnan(fps):
            fps = 25.0

        mog = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=40, detectShadows=False)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))

        for _ in range(min(warmup_frames, max(0, total))):
            ok, frame = cap.read()
            if not ok or frame is None:
                break
            mog.apply(frame)

        areas: list[float] = []
        if total <= 0:
            return areas, w, h, fps, total

        start = min(warmup_frames, max(0, total - 1))
        idxs = np.linspace(
            start, total - 1, num=min(sample_frames, max(1, total - start)), dtype=int
        )
        for fi in idxs:
            cap.set(cv2.CAP_PROP_POS_FRAMES, int(fi))
            ok, frame = cap.read()
            if not ok or frame is None:
                continue
            fg = mog.apply(frame)
            fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, kernel)
            fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN, kernel)
            contours, _ = cv2.findContours(fg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for c in contours:
                a = float(cv2.contourArea(c))
                if a >= 8.0:
                    areas.append(a)

        return areas, w, h, fps, total
    finally:
        cap.release()


def suggest_max_area(areas: list[float], w: int, h: int) -> int:
    if not areas:
        short_side = min(w, h)
        return max(6000, min(80_000, int((short_side / 720.0) ** 2 * 2500)))
    p90 = float(np.percentile(areas, 90))
    p99 = float(np.percentile(areas, 99))
    peak = max(p99, max(areas))
    guess = int(max(p90 * 1.35, peak * 1.1, 3000))
    cap_px = int(0.02 * w * h)
    return max(500, min(cap_px, guess))


def suggest_max_distance(fps: float, w: int, h: int) -> int:
    """低帧率相邻帧位移大，需要更大关联半径；随分辨率缩放。"""
    ref = 1920.0 * 1080.0
    scale = math.sqrt((w * h) / ref)
    base = 50.0 * (30.0 / max(fps, 1.0)) ** 0.85
    return int(max(40, min(450, round(base * max(1.0, scale)))))


def suggest_detection_scale(w: int, h: int) -> float:
    short_side = min(w, h)
    if short_side >= 2800:
        return 0.5
    if short_side >= 1600:
        return 0.75
    return 1.0


def estimate_tracking_param_overrides(
    video_path: str,
    *,
    current_params: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """
    基于短视频探测得到建议覆盖项（不跑完整 BacteriaTracker）。

    Returns:
        (overrides, meta)：overrides 合并进引擎参数字典；meta 供日志/排障。
    """
    areas, w, h, fps, total = probe_foreground_contour_areas(video_path)
    max_area = suggest_max_area(areas, w, h)
    max_distance = suggest_max_distance(fps, w, h)
    detection_scale = suggest_detection_scale(w, h)

    max_age = int(current_params.get("max_age", 10))
    max_age = max(max_age, 15)

    overrides: dict[str, Any] = {
        "max_area": max_area,
        "max_distance": max_distance,
        "detection_scale": float(detection_scale),
        "max_age": max_age,
    }

    meta: dict[str, Any] = {
        "video_path": video_path,
        "frame_count": total,
        "size": f"{w}x{h}",
        "fps": round(fps, 3),
        "probe_area_sample_n": len(areas),
    }
    if areas:
        meta["area_min"] = round(float(min(areas)), 1)
        meta["area_median"] = round(float(np.median(areas)), 1)
        meta["area_p90"] = round(float(np.percentile(areas, 90)), 1)
        meta["area_max"] = round(float(max(areas)), 1)

    return overrides, meta


def log_estimate_result(meta: dict[str, Any], overrides: dict[str, Any]) -> None:
    logger.info(
        f"101 参数预估: size={meta.get('size')} fps={meta.get('fps')} frames={meta.get('frame_count')} "
        f"area_samples={meta.get('probe_area_sample_n')} -> "
        f"max_area={overrides.get('max_area')} max_distance={overrides.get('max_distance')} "
        f"detection_scale={overrides.get('detection_scale')} max_age={overrides.get('max_age')}"
    )
