"""
颗粒维度统计分析任务：基于 ``kinematics_201`` 数据（由上层注入 DataFrame）统计每个颗粒的维度信息。

**单位约定（输出 statistics_202 等价 DataFrame）**
- ``start_x``, ``start_y``, ``end_x``, ``end_y`` 及各类距离、范围列：**微米（μm）**（与 kinematics_201 坐标一致）。
- ``mean_speed`` / ``max_speed`` / ``min_speed``：**微米/秒（μm/s）**。

过滤条件中的图像宽高为**像素**，经 ``scale_um_per_pixel`` 换算后与 μm 坐标可比。
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import numpy as np
import pandas as pd
from nltlog import getLogger

from funtrack.core import BaseTask, FuntrackTaskRequest

logger = getLogger("funtrack")

KINEMATICS_REQUIRED_COLUMNS = ["idx", "frame", "time", "x", "y"]
"""统计计算所需的最小运动学字段集合。"""

_STATISTICS_OUTPUT_COLUMNS = [
    "idx",
    "frame_count",
    "start_time",
    "end_time",
    "duration",
    "start_x",
    "start_y",
    "end_x",
    "end_y",
    "total_displacement",
    "total_distance",
    "x_range",
    "y_range",
    "max_x_distance",
    "max_y_distance",
    "mean_speed",
    "max_speed",
    "min_speed",
    "is_filtered",
    "filter_reason",
]


def _empty_statistics_df() -> pd.DataFrame:
    return pd.DataFrame(columns=list(_STATISTICS_OUTPUT_COLUMNS))


@dataclass
class ParticleStatisticsRequest(FuntrackTaskRequest):
    kinematics_db_path: str = ""
    video_id: int = 0
    image_width: Optional[int] = None
    image_height: Optional[int] = None
    scale_um_per_pixel: float = 1.0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ParticleStatisticsRequest":
        payload = dict(data or {})
        allowed = {
            "kinematics_db_path",
            "video_id",
            "output_dir",
            "output_prefix",
            "overwrite",
            "request_id",
            "meta",
            "image_width",
            "image_height",
            "scale_um_per_pixel",
        }
        return cls(**{k: v for k, v in payload.items() if k in allowed})

    def to_dict(self) -> dict[str, Any]:
        return super().to_dict()


class ParticleStatisticsTask(BaseTask):
    """颗粒维度统计分析任务：统计每个颗粒的帧数、时间范围、距离、运动范围等信息。"""

    task_name = "202"

    def __init__(self, request: ParticleStatisticsRequest):
        super().__init__(request)
        self.output_ref = None

    def validate_inputs(self) -> bool:
        """校验任务级静态输入；运动学 DataFrame 的完整校验在 ``_run`` 内执行。"""
        db = str(self.request.kinematics_db_path or "").strip()
        if db:
            p = Path(db)
            if not p.exists():
                logger.error(f"kinematics_db_path not found: {p}")
                return False
        return True

    def get_output_paths(self) -> dict[str, Path]:
        return {"results_db": Path(self.request.kinematics_db_path)}

    def get_task_inputs(self) -> dict[str, Any]:
        r = self.request
        return {
            "kinematics_db_path": str(Path(r.kinematics_db_path)),
            "video_id": int(r.video_id),
            "image_width": r.image_width,
            "image_height": r.image_height,
            "scale_um_per_pixel": float(r.scale_um_per_pixel),
            "required_kinematics_columns": list(KINEMATICS_REQUIRED_COLUMNS),
        }

    def get_task_results(self) -> dict[str, Any] | None:
        if not self.results or self.results.get("df_stats") is None:
            return None
        df_stats = self.results["df_stats"]
        return {
            "total_particles": len(df_stats),
            "mean_frame_count": float(df_stats["frame_count"].mean()) if len(df_stats) > 0 else 0,
            "mean_total_distance": (
                float(df_stats["total_distance"].mean()) if len(df_stats) > 0 else 0
            ),
        }

    def apply_output_paths(self, paths: dict[str, Path]) -> None:
        self.output_ref = None

    def _results_from_skip_record(self, record: dict[str, Any]) -> dict[str, Any]:
        return record.get("results") or {}

    def get_skip_return_value(self, record: dict[str, Any]) -> pd.DataFrame | None:
        if self.results and self.results.get("df_stats") is not None:
            return self.results["df_stats"]
        return None

    def get_dependencies(self) -> list[Any]:
        return []

    def _run(self, *, kinematics_df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame:
        """执行统计分析（纯计算）：显式输入 ``kinematics_df``，输出统计 DataFrame。"""
        r = self.request
        if not isinstance(kinematics_df, pd.DataFrame):
            raise TypeError("kinematics_df 必须为 pandas.DataFrame")
        df = kinematics_df.copy()
        if len(df.columns) > 0:
            df.columns = df.columns.str.strip()
        missing_cols = [c for c in KINEMATICS_REQUIRED_COLUMNS if c not in df.columns]
        self.print_info(
            Input_DataFrame=f"kinematics_df rows={len(df)}",
            Output_DataFrame="statistics_202_like_df",
        )

        if df.empty:
            df_stats = _empty_statistics_df()
            logger.info("无运动学行，返回空 statistics DataFrame")
            self.results = {"df_stats": df_stats}
            return df_stats

        if missing_cols:
            logger.error(f"运动学结果文件缺少必需的列: {missing_cols}")
            raise ValueError(f"kinematics table missing columns: {missing_cols}")

        # SQLite 可能以 TEXT 存浮点/整数，read_sql 会得到 object 列，导致 time/x/y 相减报 str - str
        for col in ("frame", "time", "x", "y"):
            df[col] = pd.to_numeric(df[col], errors="coerce")
        if "speed" in df.columns:
            df["speed"] = pd.to_numeric(df["speed"], errors="coerce")
        if "idx" in df.columns:
            df["idx"] = pd.to_numeric(df["idx"], errors="coerce")

        before = len(df)
        df = df.dropna(subset=["frame", "time", "x", "y", "idx"])
        dropped = before - len(df)
        if dropped:
            logger.warning(
                f"kinematics_201 中有 {dropped} 行无法解析为数值（frame/time/x/y/idx），已跳过"
            )
        if df.empty:
            df_stats = _empty_statistics_df()
            logger.info("运动学数据无有效数值行，返回空 statistics DataFrame")
            self.results = {"df_stats": df_stats}
            return df_stats

        # 按颗粒分组统计
        stats_list = []
        for idx, group in df.groupby("idx"):
            group = group.sort_values("frame")

            # 基本统计
            frame_count = len(group)
            start_time = group["time"].min()
            end_time = group["time"].max()
            duration = end_time - start_time

            # 位置信息
            start_x = group["x"].iloc[0]
            start_y = group["y"].iloc[0]
            end_x = group["x"].iloc[-1]
            end_y = group["y"].iloc[-1]

            # 距离计算
            # 总位移（起始点到结束点的直线距离）
            total_displacement = np.sqrt((end_x - start_x) ** 2 + (end_y - start_y) ** 2)

            # 总路径长度（所有相邻点之间的距离之和）
            dx = group["x"].diff().fillna(0)
            dy = group["y"].diff().fillna(0)
            total_distance = np.sqrt(dx**2 + dy**2).sum()

            # x轴和y轴的最大距离（范围）
            x_range = group["x"].max() - group["x"].min()
            y_range = group["y"].max() - group["y"].min()

            # x轴和y轴的最大位移（从起始点到最远点的距离）
            x_distances = group["x"] - start_x
            y_distances = group["y"] - start_y
            max_x_distance = x_distances.abs().max()
            max_y_distance = y_distances.abs().max()

            # 速度统计（如果有speed列）
            mean_speed = group["speed"].mean() if "speed" in group.columns else None
            max_speed = group["speed"].max() if "speed" in group.columns else None
            min_speed = group["speed"].min() if "speed" in group.columns else None

            stats_list.append(
                {
                    "idx": idx,
                    "frame_count": frame_count,
                    "start_time": start_time,
                    "end_time": end_time,
                    "duration": duration,
                    "start_x": start_x,
                    "start_y": start_y,
                    "end_x": end_x,
                    "end_y": end_y,
                    "total_displacement": total_displacement,
                    "total_distance": total_distance,
                    "x_range": x_range,
                    "y_range": y_range,
                    "max_x_distance": max_x_distance,
                    "max_y_distance": max_y_distance,
                    "mean_speed": mean_speed,
                    "max_speed": max_speed,
                    "min_speed": min_speed,
                }
            )

        # 创建统计DataFrame
        df_stats = pd.DataFrame(stats_list)
        df_stats = df_stats.sort_values("idx").reset_index(drop=True)

        # 获取图像尺寸（用于过滤判断，单位 px）
        image_width = r.image_width
        image_height = r.image_height
        scale = float(r.scale_um_per_pixel)
        if not (scale > 0) or not np.isfinite(scale):
            scale = 1.0

        # 如果未提供图像尺寸，尝试从任务记录中获取（仅作为计算过滤阈值辅助）
        if image_width is None or image_height is None:
            # 尝试从视频信息任务记录中获取
            video_info_path = self.output_dir / ".task" / "video_info.json"
            if video_info_path.exists():
                try:
                    import json

                    with open(video_info_path, encoding="utf-8") as f:
                        video_info = json.load(f)
                    if "results" in video_info:
                        info = video_info["results"]
                        image_width = image_width or info.get("width")
                        image_height = image_height or info.get("height")
                        if image_width and image_height:
                            logger.info(f"从视频信息记录读取图像尺寸: {image_width}x{image_height}")
                except Exception as e:
                    logger.warning(f"无法从视频信息记录读取尺寸: {e}")

            # 如果还是无法获取，尝试从运动学数据（μm）反推像素尺寸
            if image_width is None or image_height is None:
                max_x = df["x"].max() if len(df) > 0 else None
                max_y = df["y"].max() if len(df) > 0 else None
                if max_x is not None and max_y is not None:
                    # 最大坐标为 μm，除以比例尺得像素量级
                    image_width = image_width or int((float(max_x) * 1.1) / scale)
                    image_height = image_height or int((float(max_y) * 1.1) / scale)
                    logger.info(f"从数据估算图像尺寸(px): {image_width}x{image_height}")

        # 应用过滤条件并添加过滤信息列
        if image_width is not None and image_height is not None:
            df_stats["is_filtered"] = False
            df_stats["filter_reason"] = ""

            image_area_px = float(image_width) * float(image_height)
            image_area_um2 = image_area_px * (scale**2)
            image_max_dimension_um = max(float(image_width), float(image_height)) * scale

            for idx, row in df_stats.iterrows():
                reasons = []

                # 过滤条件1: 帧数 < 10
                if row["frame_count"] < 10:
                    reasons.append("帧数小于10")

                # 过滤条件2: 活动区域占比 < 1/100（均为 μm²）
                activity_area = row["x_range"] * row["y_range"]
                activity_ratio = activity_area / image_area_um2 if image_area_um2 > 0 else 0
                if activity_ratio < 0.01:
                    reasons.append("活动区域占比小于1/100")

                # 过滤条件3: x/y 活动范围（μm）均小于图像最大边（μm）的 1/10
                min_range_threshold_um = image_max_dimension_um / 10
                if (
                    row["x_range"] < min_range_threshold_um
                    and row["y_range"] < min_range_threshold_um
                ):
                    reasons.append("x轴和y轴范围都小于图宽高的1/10")

                # 设置过滤状态
                if reasons:
                    df_stats.loc[idx, "is_filtered"] = True
                    df_stats.loc[idx, "filter_reason"] = "; ".join(reasons)
        else:
            # 如果无法获取图像尺寸，只检查帧数
            logger.warning("无法获取图像尺寸，仅使用帧数过滤条件")
            df_stats["is_filtered"] = df_stats["frame_count"] < 10
            df_stats["filter_reason"] = df_stats["is_filtered"].apply(
                lambda x: "帧数小于10" if x else ""
            )

        logger.info(f"共统计 {len(df_stats)} 个颗粒")

        filtered_count = df_stats["is_filtered"].sum()
        if filtered_count > 0:
            logger.info(f"其中 {filtered_count} 个颗粒被标记为过滤")

        self.results = {"df_stats": df_stats}
        return df_stats

    def print_summary(self):
        """打印统计摘要。"""
        if self.results and self.results.get("df_stats") is not None:
            try:
                df_stats = self.results["df_stats"]
                logger.info("=" * 60)
                logger.info("Particle Statistics Summary")
                logger.info("=" * 60)
                logger.info(f"Total Particles: {len(df_stats)}")
                if len(df_stats) > 0:
                    logger.info(f"Mean Frame Count: {df_stats['frame_count'].mean():.2f}")
                    logger.info(f"Mean Total Distance: {df_stats['total_distance'].mean():.2f}")
                    logger.info(f"Mean X Range: {df_stats['x_range'].mean():.2f}")
                    logger.info(f"Mean Y Range: {df_stats['y_range'].mean():.2f}")
                    filtered_count = (
                        df_stats["is_filtered"].sum() if "is_filtered" in df_stats.columns else 0
                    )
                    if filtered_count > 0:
                        logger.info(f"Filtered Particles: {filtered_count}/{len(df_stats)}")
                logger.info("=" * 60)
            except Exception as e:
                logger.warning(f"无法读取统计结果进行摘要: {e}")
