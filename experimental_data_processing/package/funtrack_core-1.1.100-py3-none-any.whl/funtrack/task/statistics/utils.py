"""颗粒统计过滤工具（DataFrame 版本）。"""

from typing import Optional

import pandas as pd
from nltlog import getLogger

logger = getLogger("funtrack")


def filter_particles_by_statistics(
    statistics_df: pd.DataFrame,
    min_frame_count: Optional[int] = None,
    max_frame_count: Optional[int] = None,
    min_total_distance: Optional[float] = None,
    max_total_distance: Optional[float] = None,
    min_x_range: Optional[float] = None,
    max_x_range: Optional[float] = None,
    min_y_range: Optional[float] = None,
    max_y_range: Optional[float] = None,
    min_max_x_distance: Optional[float] = None,
    min_max_y_distance: Optional[float] = None,
    min_duration: Optional[float] = None,
    max_duration: Optional[float] = None,
) -> pd.DataFrame:
    """根据统计表过滤颗粒。"""
    df_stats = statistics_df.copy()
    mask = pd.Series([True] * len(df_stats), index=df_stats.index)

    if min_frame_count is not None:
        mask &= df_stats["frame_count"] >= min_frame_count
    if max_frame_count is not None:
        mask &= df_stats["frame_count"] <= max_frame_count
    if min_total_distance is not None:
        mask &= df_stats["total_distance"] >= min_total_distance
    if max_total_distance is not None:
        mask &= df_stats["total_distance"] <= max_total_distance
    if min_x_range is not None:
        mask &= df_stats["x_range"] >= min_x_range
    if max_x_range is not None:
        mask &= df_stats["x_range"] <= max_x_range
    if min_y_range is not None:
        mask &= df_stats["y_range"] >= min_y_range
    if max_y_range is not None:
        mask &= df_stats["y_range"] <= max_y_range
    if min_max_x_distance is not None:
        mask &= df_stats["max_x_distance"] >= min_max_x_distance
    if min_max_y_distance is not None:
        mask &= df_stats["max_y_distance"] >= min_max_y_distance
    if min_duration is not None:
        mask &= df_stats["duration"] >= min_duration
    if max_duration is not None:
        mask &= df_stats["duration"] <= max_duration

    filtered = df_stats[mask].copy()
    logger.info(f"过滤结果: {len(filtered)}/{len(df_stats)}")
    return filtered


def get_particle_indices(statistics_df: pd.DataFrame, **kwargs) -> list[int]:
    """获取满足条件的颗粒索引。"""
    filtered = filter_particles_by_statistics(statistics_df, **kwargs)
    return filtered["idx"].astype(int).tolist()


def filter_kinematics_by_statistics(
    kinematics_df: pd.DataFrame,
    statistics_df: pd.DataFrame,
    **kwargs,
) -> pd.DataFrame:
    """按统计表过滤运动学表。"""
    valid_indices = get_particle_indices(statistics_df, **kwargs)
    df_filtered = kinematics_df[kinematics_df["idx"].isin(valid_indices)].copy()
    logger.info(f"运动学过滤: {len(df_filtered)}/{len(kinematics_df)}")
    return df_filtered
