"""圆形分析片段：邻局颗粒距离过滤（WAR-264）。

在写出 ``circle_301`` 前，若片段时间窗内任一整帧存在异颗粒与当前颗粒**圆心距**
≤ ``0.1 × 圆形分析直径（μm）``，则丢弃该片段。分析直径 = 301 几何分析圆盘的直径（2×分析半径）。
"""

from __future__ import annotations

from collections import defaultdict

import numpy as np
import pandas as pd
from nltlog import getLogger

from funtrack.task.circle.log_format import log_str_um

logger = getLogger("funtrack")

# 邻局判据：两颗粒圆心距 ≤ 该阈值（μm）则视为邻局；阈值为分析圆盘直径的固定比例。
NEIGHBOR_PROXIMITY_FRACTION_OF_ANALYSIS_DIAMETER = 0.1


def filter_circle_segments_by_neighbor_proximity(
    segments_df: pd.DataFrame,
    kinematics_df: pd.DataFrame,
    analysis_circle_diameter_um: float,
    proximity_fraction_of_analysis_diameter: float = (
        NEIGHBOR_PROXIMITY_FRACTION_OF_ANALYSIS_DIAMETER
    ),
) -> pd.DataFrame:
    """若某片段时间窗内任一整数帧上，存在异 ``idx`` 与当前颗粒圆心距（μm）
    ≤ ``proximity_fraction_of_analysis_diameter * analysis_circle_diameter_um``，
    则丢弃该片段行。

    ``analysis_circle_diameter_um``：301 用于几何穿行的**分析圆盘直径**（微米），即 2×任务内使用的分析半径。

    距离：运动学表 ``x``, ``y``（微米）的欧氏距离。坐标已为颗粒中心，不再加半径。
    """
    if segments_df is None or segments_df.empty:
        return segments_df
    d_analysis = float(analysis_circle_diameter_um)
    if d_analysis <= 0.0:
        return segments_df
    frac = float(proximity_fraction_of_analysis_diameter)
    if frac <= 0.0:
        return segments_df
    thresh_um = frac * d_analysis
    n_seg_in = len(segments_df)

    kin = kinematics_df.copy()
    if len(kin.columns) > 0:
        kin.columns = kin.columns.str.strip()
    required = ("idx", "frame", "x", "y")
    if not set(required).issubset(kin.columns):
        logger.warning("邻局过滤: 运动学缺少 idx/frame/x/y，跳过过滤")
        return segments_df

    n_kin = len(kin)
    n_particles = int(kin["idx"].nunique()) if n_kin > 0 else 0
    if n_kin > 0:
        f_lo = int(round(float(kin["frame"].min())))
        f_hi = int(round(float(kin["frame"].max())))
    else:
        f_lo, f_hi = None, None
    fr_lo = f_lo if f_lo is not None else "—"
    fr_hi = f_hi if f_hi is not None else "—"
    logger.info(
        f"邻局过滤参数: 圆形分析直径={log_str_um(d_analysis)}（2×301 几何分析半径）; "
        f"排斥圆心距阈值={frac}×该直径={log_str_um(thresh_um)}; "
        f"规则=在片段帧闭区间[min(enter,exit,inside_first,inside_last), max(...)] 内，"
        f"任一整帧若存在异 idx 满足上述距离则整段丢弃；输入片段={n_seg_in} 条，运动学行={n_kin}，"
        f"颗粒数={n_particles}，帧范围=[{fr_lo},{fr_hi}]"
    )

    frame_positions: dict[int, dict[int, tuple[float, float]]] = defaultdict(dict)
    for _, r in kin.iterrows():
        f = int(round(float(r["frame"])))
        idx = int(r["idx"])
        frame_positions[f][idx] = (float(r["x"]), float(r["y"]))

    keep_rows: list[bool] = []
    first_drop_detail: str | None = None
    for _, row in segments_df.iterrows():
        tid = int(row["idx"])
        fe = int(round(float(row["enter_frame"])))
        fx = int(round(float(row["exit_frame"])))
        fi0 = int(round(float(row.get("inside_frame_first", fe))))
        fi1 = int(round(float(row.get("inside_frame_last", fx))))
        lo = min(fe, fx, fi0, fi1)
        hi = max(fe, fx, fi0, fi1)
        contaminated = False
        for f in range(lo, hi + 1):
            posmap = frame_positions.get(f)
            if not posmap:
                continue
            self_xy = posmap.get(tid)
            if self_xy is None:
                continue
            sx, sy = self_xy
            for oidx, (ox, oy) in posmap.items():
                if oidx == tid:
                    continue
                dist_um = float(np.hypot(ox - sx, oy - sy))
                if dist_um <= thresh_um:
                    contaminated = True
                    if first_drop_detail is None:
                        first_drop_detail = (
                            f"idx={tid} 帧{f} 与异颗粒 idx={oidx} 圆心距="
                            f"{log_str_um(dist_um)} ≤ 阈值 {log_str_um(thresh_um)} "
                            f"(片段帧窗 [{lo},{hi}])"
                        )
                    break
            if contaminated:
                break
        keep_rows.append(not contaminated)

    n_kept = sum(keep_rows)
    n_drop = n_seg_in - n_kept
    logger.info(f"邻局过滤结果: 保留 {n_kept} / {n_seg_in} 条片段（剔除 {n_drop}）")
    if n_seg_in > 0 and n_kept == 0 and first_drop_detail is not None:
        logger.warning(
            "邻局过滤剔除全部片段。稠密视野下常见：时间窗内任一整帧有异颗粒进入排斥阈值即丢整段。"
            f" 首条命中示例: {first_drop_detail}"
        )

    return segments_df.iloc[keep_rows].reset_index(drop=True)
