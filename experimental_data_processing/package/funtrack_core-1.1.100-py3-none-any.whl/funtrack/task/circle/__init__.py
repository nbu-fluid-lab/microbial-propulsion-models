"""圆形区域分析：轨迹段分析、绘图与任务。"""

from funtrack.task.circle.neighbor_segment_filter import (
    NEIGHBOR_PROXIMITY_FRACTION_OF_ANALYSIS_DIAMETER,
    filter_circle_segments_by_neighbor_proximity,
)
from funtrack.task.circle.obstacle_circle import ObstacleCircleResult
from funtrack.task.circle.task import (
    CircleRegionRequest,
    CircleRegionTask,
    _empty_kinematics_df,
)
from funtrack.task.circle.trajectories import (
    analyze_circle_trajectories,
    analyze_circle_trajectories_fixed_circle,
    plot_trajectory_segment,
)
from funtrack.task.circle.utils import (
    calculate_angle,
    calculate_speed,
    line_circle_intersection,
    point_in_circle,
)

__all__ = [
    "CircleRegionTask",
    "CircleRegionRequest",
    "_empty_kinematics_df",
    "NEIGHBOR_PROXIMITY_FRACTION_OF_ANALYSIS_DIAMETER",
    "filter_circle_segments_by_neighbor_proximity",
    "ObstacleCircleResult",
    "analyze_circle_trajectories",
    "analyze_circle_trajectories_fixed_circle",
    "plot_trajectory_segment",
    "calculate_angle",
    "calculate_speed",
    "line_circle_intersection",
    "point_in_circle",
]
