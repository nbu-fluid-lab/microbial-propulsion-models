"""圆形区域分析用几何与速度工具。"""

import numpy as np


def calculate_angle(x1, y1, x2, y2):
    """计算从点1到点2的角度（弧度，0-2π）。"""
    dx = x2 - x1
    dy = y2 - y1
    angle = np.arctan2(dy, dx)
    if angle < 0:
        angle += 2 * np.pi
    return angle


def calculate_speed(df_row, prev_row, scale_um_per_pixel=1.0):
    """
    计算速度，单位 μm/s。比例尺单位 微米/像素（1 表示 1 微米/像素）。

    参数:
        df_row: 当前行（含 x, y, time）
        prev_row: 上一行
        scale_um_per_pixel: 比例尺，单位 微米/像素
    """
    if prev_row is None:
        return 0.0

    dx = df_row["x"] - prev_row["x"]
    dy = df_row["y"] - prev_row["y"]
    dt = df_row["time"] - prev_row["time"]

    if dt <= 0:
        return 0.0

    speed_px_s = np.sqrt(dx**2 + dy**2) / dt
    return speed_px_s * scale_um_per_pixel


def point_in_circle(x, y, center_x, center_y, radius):
    """判断点是否在圆内。"""
    dist = np.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)
    return dist <= radius


def line_circle_intersection(x1, y1, x2, y2, center_x, center_y, radius):
    """
    计算线段与圆的交点。
    返回: (intersection_x, intersection_y, t) 或 None。
    t 为交点在线段上的参数 (0-1)。
    """
    dx = x2 - x1
    dy = y2 - y1

    vx = x1 - center_x
    vy = y1 - center_y

    a = dx * dx + dy * dy
    b = 2 * (vx * dx + vy * dy)
    c = vx * vx + vy * vy - radius * radius

    discriminant = b * b - 4 * a * c

    if discriminant < 0 or a == 0:
        return None

    sqrt_discriminant = np.sqrt(discriminant)

    t1 = (-b - sqrt_discriminant) / (2 * a)
    t2 = (-b + sqrt_discriminant) / (2 * a)

    valid_t = None
    for t in [t1, t2]:
        if 0 < t <= 1:
            if valid_t is None or t > valid_t:
                valid_t = t

    if valid_t is None:
        return None

    intersection_x = x1 + valid_t * dx
    intersection_y = y1 + valid_t * dy

    return intersection_x, intersection_y, valid_t
