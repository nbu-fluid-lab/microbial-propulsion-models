"""圆形分析等环节的日志数字格式：避免 :g 科学计数、numpy 标量显示异常。"""

from __future__ import annotations

import math
from typing import Any


def _to_python_scalar(v: Any) -> Any:
    if hasattr(v, "item") and callable(getattr(v, "item", None)):
        try:
            return v.item()
        except Exception:
            pass
    return v


def log_str_scalar(v: Any) -> str:
    """将标量格式化为易读十进制字符串（非科学计数）。"""
    v = _to_python_scalar(v)
    if v is None:
        return "None"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int) and not isinstance(v, bool):
        return str(v)
    try:
        x = float(v)
    except (TypeError, ValueError):
        return str(v)
    if not math.isfinite(x):
        return "non-finite"
    s = f"{x:.8f}".rstrip("0").rstrip(".")
    return s if s else "0"


def log_str_um(v: Any) -> str:
    s = log_str_scalar(v)
    return s if s == "non-finite" else f"{s} μm"


def log_str_scale_um_per_px(v: Any) -> str:
    return f"{log_str_scalar(v)} μm/px"
