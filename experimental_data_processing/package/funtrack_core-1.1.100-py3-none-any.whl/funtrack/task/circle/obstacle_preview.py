"""在检测帧上绘制障碍物小圆与最终固定分析圆，编码为 PNG 字节（不落盘）。"""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
from nltlog import getLogger

from funtrack.task.circle.obstacle_circle import ObstacleCircleResult
from funtrack.task.obstacle_detection.preview import draw_obstacle_result_on_bgr

logger = getLogger("funtrack")


def _read_frame_bgr(video_path: Path, frame_index: int) -> np.ndarray:
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise OSError(f"cannot open video: {video_path}")
    try:
        fi = int(frame_index)
        if fi < 0:
            fi = 0
        cap.set(cv2.CAP_PROP_POS_FRAMES, fi)
        ok, frame = cap.read()
        if not ok or frame is None:
            raise OSError(f"failed to read frame {fi} from {video_path}")
        return frame
    finally:
        cap.release()


def draw_obstacle_fixed_circle_on_bgr(bgr: np.ndarray, result: ObstacleCircleResult) -> np.ndarray:
    """在 BGR 帧上绘制小圆与固定分析圆，返回新数组。"""
    return draw_obstacle_result_on_bgr(bgr, result)


def encode_obstacle_fixed_circle_preview_png(
    video_path: str, result: ObstacleCircleResult
) -> bytes:
    """
    从主视频读取与库内 ``ObstacleCircleResult.frame_index`` 一致的帧，再叠绘小圆与固定分析圆，返回 PNG 字节。
    """
    path = Path(video_path)
    if not path.is_file():
        raise FileNotFoundError(f"video not found: {video_path}")

    frame = _read_frame_bgr(path, int(result.frame_index))
    vis = draw_obstacle_result_on_bgr(frame, result)
    ok, buf = cv2.imencode(".png", vis)
    if not ok or buf is None:
        raise OSError("failed to encode obstacle preview PNG")

    logger.debug(
        f"障碍物固定圆预览 PNG 已编码: frame={result.frame_index}, markers={len(result.marker_points)}"
    )
    return bytes(buf)
