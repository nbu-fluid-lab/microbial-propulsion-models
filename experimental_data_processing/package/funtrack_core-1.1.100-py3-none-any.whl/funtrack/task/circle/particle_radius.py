"""颗粒类型与圆形分析参考尺寸（微米）。"""

from __future__ import annotations

import math

# 业务约定：circle_301.circle_radius 为半径（μm）；enter/exit/center 等位置列为微米（μm）。
# tracks_101、obstacle_fixed_circle 的几何列为像素（px）。
#
# 301 任务参数 circle_radius：与视频详情「圆形分析直径」一致时，对预设颗粒类型写入的是**直径**（μm），
# 任务运行时再折半为分析半径；避免用户按「85μm 细胞直径」理解而参数里却是 42.5 造成困惑。
# 手动填写的数值若恰好等于预设直径表中的值（85 / 265 / 1500），也按直径解析（纠正常见误填）。
_PRESET_CIRCLE_ANALYSIS_DIAMETERS_UM: frozenset[float] = frozenset({1500.0, 265.0, 85.0})

CIRCLE_ANALYSIS_DIAMETER_UM_BY_PARTICLE_TYPE: dict[str, float] = {
    "草履虫": 1500.0,
    "衣藻": 265.0,
    "大肠杆菌": 85.0,
}

OBSTACLE_MARKER_DIAMETER_UM_BY_PARTICLE_TYPE: dict[str, float] = {
    "草履虫": 85.0,
    "衣藻": 15.0,
    "大肠杆菌": 5.0,
}


def circle_radius_um_for_particle_type(particle_type: str | None) -> float | None:
    """若颗粒类型在预设表中，返回分析圆参考半径（μm）= 预设直径/2，否则 None。"""
    if particle_type is None:
        return None
    t = str(particle_type).strip()
    if not t:
        return None
    d = CIRCLE_ANALYSIS_DIAMETER_UM_BY_PARTICLE_TYPE.get(t)
    return float(d) * 0.5 if d is not None else None


def circle_analysis_diameter_um_for_particle_type(particle_type: str | None) -> float | None:
    """预设颗粒类型的圆形分析参考直径（μm），与视频 API「圆形分析直径」一致；无预设则 None。"""
    if particle_type is None:
        return None
    t = str(particle_type).strip()
    if not t:
        return None
    d = CIRCLE_ANALYSIS_DIAMETER_UM_BY_PARTICLE_TYPE.get(t)
    return float(d) if d is not None else None


def analysis_radius_um_from_circle_task_param(param_um: float, *, tol: float = 0.05) -> float:
    """由 301 任务参数 ``circle_radius``（μm）得到分析圆半径（μm）。

    - 数值在容差内等于预设分析直径 1500 / 265 / 85 时，按**直径**折半为半径（与页面上「细胞直径」一致）。
    - 其余值按**半径**使用（如手动填 42.5、50 等）。
    """
    x = float(param_um)
    if not math.isfinite(x) or x <= 0.0:
        return x
    for d in _PRESET_CIRCLE_ANALYSIS_DIAMETERS_UM:
        if abs(x - d) <= tol:
            return x * 0.5
    return x


def obstacle_marker_diameter_um_for_particle_type(particle_type: str | None) -> float | None:
    """若颗粒类型在预设表中，返回障碍物小圆直径（μm），否则 None。

    与 WebAPI ``VideoOut.obstacle_marker_diameter_um``（视频信息摘要）同源，用作障碍物 Hough 小圆筛选参考。
    """
    if particle_type is None:
        return None
    t = str(particle_type).strip()
    if not t:
        return None
    d = OBSTACLE_MARKER_DIAMETER_UM_BY_PARTICLE_TYPE.get(t)
    return float(d) if d is not None else None


def preset_diameters_um_for_particle_type(
    particle_type: str | None,
) -> tuple[float | None, float | None]:
    """返回 (圆形分析直径 μm, 障碍物小圆直径 μm)，仅预设颗粒类型有值。"""
    if particle_type is None:
        return None, None
    t = str(particle_type).strip()
    if not t:
        return None, None
    cd = CIRCLE_ANALYSIS_DIAMETER_UM_BY_PARTICLE_TYPE.get(t)
    od = OBSTACLE_MARKER_DIAMETER_UM_BY_PARTICLE_TYPE.get(t)
    return (
        float(cd) if cd is not None else None,
        float(od) if od is not None else None,
    )
