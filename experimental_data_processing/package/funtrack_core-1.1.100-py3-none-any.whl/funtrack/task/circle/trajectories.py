"""圆形区域轨迹分析（DataFrame 版本）。

障碍物固定圆模式：给定圆心、半径（μm），沿轨迹扫描 **圆外→圆内→圆外** 的完整穿行；
入/出点为对应帧间线段与 **圆周** 的交点；记录入点帧（进圆前最后一帧，圆外）、出点帧（出圆后第一帧，圆外）。

动态模式：以**当前帧位置**为起点，用**前后若干点**估计的平滑速度方向（单位向量），沿该方向
前移**任务分析半径 r**（μm）得到圆心 ``(cx, cy)``，与半径 r 构成圆盘；在全轨迹上枚举穿行，
仅保留与当前索引附近帧带相交的穿行；同一条穿行去重只写一行。**若无法估计平滑速度**，该锚点
直接跳过（无任何几何回退）。

指标：圆内路径长、历时、位移、平均速度、入/出边速度、L（弦/直径）、V_eff、delta_p 等。

剔除：圆内折线路径长（μm）小于 **0.5×圆半径（μm）** 的穿行（过短噪声）。
"""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
from nltlog import getLogger

from funtrack.task.circle.log_format import log_str_um

logger = getLogger("funtrack")


def _default_eps_px(r_px: float) -> float:
    return max(1e-6, 1e-4 * float(r_px))


def _default_eps_um(r_um: float) -> float:
    return max(1e-6, 1e-4 * float(r_um))


def _dist(px: float, py: float, cx: float, cy: float) -> float:
    return float(np.hypot(px - cx, py - cy))


def _inside_disk(d: float, r: float, eps: float) -> bool:
    return d <= float(r) + float(eps)


def _outside_disk(d: float, r: float, eps: float) -> bool:
    return d > float(r) + float(eps)


def _segment_circle_boundary_ts(
    ax: float,
    ay: float,
    bx: float,
    by: float,
    cx: float,
    cy: float,
    r: float,
) -> list[float]:
    """线段与圆周 ‖x-c‖=r 的交点参数 t∈[0,1]（含端点，去重）。"""
    dx = bx - ax
    dy = by - ay
    fx = ax - cx
    fy = ay - cy
    a = dx * dx + dy * dy
    if a < 1e-20:
        return []
    b = 2.0 * (fx * dx + fy * dy)
    c_ = fx * fx + fy * fy - float(r) ** 2
    disc = b * b - 4.0 * a * c_
    out: list[float] = []
    if disc < -1e-8:
        return []
    if abs(disc) <= 1e-8:
        if abs(a) <= 1e-18:
            return []
        t = -b / (2.0 * a)
        if -1e-9 <= t <= 1.0 + 1e-9:
            out.append(float(min(1.0, max(0.0, t))))
    else:
        s = float(np.sqrt(max(disc, 0.0)))
        for t in ((-b - s) / (2.0 * a), (-b + s) / (2.0 * a)):
            if -1e-9 <= t <= 1.0 + 1e-9:
                out.append(float(min(1.0, max(0.0, t))))
    out.sort()
    merged: list[float] = []
    for t in out:
        if not merged or abs(t - merged[-1]) > 1e-7:
            merged.append(t)
    return merged


def _linear_crossing_t_outside_to_inside(
    ax: float,
    ay: float,
    bx: float,
    by: float,
    cx: float,
    cy: float,
    r: float,
    eps: float,
) -> float | None:
    """圆外 A → 圆内 B：线段上与圆周首次相交的 t∈(0,1)。"""
    da = _dist(ax, ay, cx, cy)
    db = _dist(bx, by, cx, cy)
    if not (_outside_disk(da, r, eps) and _inside_disk(db, r, eps)):
        return None
    ts = _segment_circle_boundary_ts(ax, ay, bx, by, cx, cy, r)
    for t in ts:
        # 允许 t→1：端点 B 落在圆周上仍视为「从圆外进入」的落点（动态圆心常使采样点在圆上）
        if 1e-10 < t <= 1.0:
            return t
    if abs(da - db) > 1e-18:
        t = (da - r) / (da - db)
        if 1e-10 < t <= 1.0:
            return float(t)
    return None


def _linear_crossing_t_inside_to_outside(
    ax: float,
    ay: float,
    bx: float,
    by: float,
    cx: float,
    cy: float,
    r: float,
    eps: float,
) -> float | None:
    """圆内 A → 圆外 B：线段上与圆周首次相交的 t∈[0,1)（允许 t→0：A 在圆周上穿出）。"""
    da = _dist(ax, ay, cx, cy)
    db = _dist(bx, by, cx, cy)
    if not (_inside_disk(da, r, eps) and _outside_disk(db, r, eps)):
        return None
    ts = _segment_circle_boundary_ts(ax, ay, bx, by, cx, cy, r)
    for t in ts:
        if 0.0 <= t < 1.0 - 1e-10:
            return t
    if abs(da - db) > 1e-18:
        t = (da - r) / (da - db)
        if 0.0 <= t < 1.0 - 1e-10:
            return float(t)
    return None


def _interp_edge(fa: float, fb: float, ta: float, tb: float, t_param: float) -> float:
    """边参数 t_param∈[0,1] 处的标量（优先 time，退化到 frame）。"""
    if np.isfinite(ta) and np.isfinite(tb) and abs(tb - ta) > 1e-15:
        return float(ta + t_param * (tb - ta))
    return float(fa + t_param * (fb - fa))


def _at_xy(ax: float, ay: float, bx: float, by: float, t: float) -> tuple[float, float]:
    return float(ax + t * (bx - ax)), float(ay + t * (by - ay))


def _enumerate_disk_passages_um(
    track: pd.DataFrame,
    cx: float,
    cy: float,
    r_um: float,
) -> list[dict]:
    """全轨迹上枚举给定闭圆盘的所有「进→出」穿行（μm）。"""
    eps = _default_eps_um(r_um)
    n = len(track)
    if n < 2:
        return []
    fr = track["frame"].to_numpy(dtype=float)
    tt = track["time"].to_numpy(dtype=float)
    xy = track[["x", "y"]].to_numpy(dtype=float)
    idx_val = int(track["idx"].iloc[0])
    r = float(r_um)

    passages: list[dict] = []
    i = 0
    while i < n - 1:
        ax, ay = float(xy[i, 0]), float(xy[i, 1])
        bx, by = float(xy[i + 1, 0]), float(xy[i + 1, 1])
        fa, fb = float(fr[i]), float(fr[i + 1])
        ta, tb = float(tt[i]), float(tt[i + 1])
        t_in = _linear_crossing_t_outside_to_inside(ax, ay, bx, by, cx, cy, r, eps)
        if t_in is None:
            i += 1
            continue

        qex, qey = _at_xy(ax, ay, bx, by, t_in)
        enter_frame_out = fa
        enter_time = _interp_edge(fa, fb, ta, tb, t_in)
        seg_len_in = float(np.hypot(bx - ax, by - ay))
        dt_in = tb - ta
        enter_speed = seg_len_in / dt_in if abs(dt_in) > 1e-15 else 0.0
        vx_in = (bx - ax) / dt_in if abs(dt_in) > 1e-15 else 0.0
        vy_in = (by - ay) / dt_in if abs(dt_in) > 1e-15 else 0.0

        inside_first_f = fb
        j = i + 1
        t_out: float | None = None
        axo = ayo = bxo = byo = 0.0
        fao = fbo = tao = tbo = 0.0
        seg_len_out = 0.0
        dt_out = 1.0
        while j < n - 1:
            ax2, ay2 = float(xy[j, 0]), float(xy[j, 1])
            bx2, by2 = float(xy[j + 1, 0]), float(xy[j + 1, 1])
            fa2, fb2 = float(fr[j]), float(fr[j + 1])
            ta2, tb2 = float(tt[j]), float(tt[j + 1])
            t_try = _linear_crossing_t_inside_to_outside(ax2, ay2, bx2, by2, cx, cy, r, eps)
            if t_try is not None:
                t_out = t_try
                axo, ayo, bxo, byo = ax2, ay2, bx2, by2
                fao, fbo = fa2, fb2
                tao, tbo = ta2, tb2
                seg_len_out = float(np.hypot(bxo - axo, byo - ayo))
                dt_out = tbo - tao
                break
            j += 1

        if t_out is None:
            # 未完成「出圆」：丢弃本次入圆尝试，继续向后扫描（勿 break，否则密采样轨会过早结束）
            i += 1
            continue

        qxx, qxy = _at_xy(axo, ayo, bxo, byo, t_out)
        exit_frame_out = fbo
        exit_time = _interp_edge(fao, fbo, tao, tbo, t_out)
        exit_speed = seg_len_out / dt_out if abs(dt_out) > 1e-15 else 0.0
        vx_out = (bxo - axo) / dt_out if abs(dt_out) > 1e-15 else 0.0
        vy_out = (byo - ayo) / dt_out if abs(dt_out) > 1e-15 else 0.0

        inside_last_f = fao

        path_len = 0.0
        bx_in, by_in = bx, by
        path_len += float(np.hypot(bx_in - qex, by_in - qey))
        for k in range(i + 1, j):
            x0, y0 = float(xy[k, 0]), float(xy[k, 1])
            x1, y1 = float(xy[k + 1, 0]), float(xy[k + 1, 1])
            path_len += float(np.hypot(x1 - x0, y1 - y0))
        path_len += float(np.hypot(qxx - axo, qxy - ayo))

        inside_dur = exit_time - enter_time
        if inside_dur <= 1e-15:
            inside_dur = max(1e-15, abs(fbo - fa) * 1e-3)

        disp = float(np.hypot(qxx - qex, qxy - qey))
        mean_sp = path_len / inside_dur if inside_dur > 1e-15 else 0.0
        diam = 2.0 * r
        L_norm = disp / diam if diam > 1e-15 else 0.0
        path_over_diam = path_len / diam if diam > 1e-15 else 0.0
        v_eff_norm = L_norm / path_over_diam if path_over_diam > 1e-18 else 0.0

        ang_in = math.atan2(vy_in, vx_in)
        ang_out = math.atan2(vy_out, vx_out)
        delta_p = (ang_out - ang_in + math.pi) % (2 * math.pi) - math.pi

        min_inside_path_um = 0.5 * r
        if path_len < min_inside_path_um:
            i = j + 1
            continue

        passages.append(
            {
                "idx": idx_val,
                "enter_frame": enter_frame_out,
                "exit_frame": exit_frame_out,
                "enter_time": enter_time,
                "exit_time": exit_time,
                "enter_x": qex,
                "enter_y": qey,
                "exit_x": qxx,
                "exit_y": qxy,
                "inside_frame_first": inside_first_f,
                "inside_frame_last": inside_last_f,
                "inside_duration_s": float(inside_dur),
                "inside_path_length_um": float(path_len),
                "inside_displacement_um": float(disp),
                "inside_mean_speed_um_s": float(mean_sp),
                "L_normalized": float(L_norm),
                "V_eff_normalized": float(v_eff_norm),
                "angle_change_rad": float(delta_p),
                "angle_change_deg": float(np.degrees(delta_p)),
                "enter_angle_rad": float(ang_in),
                "exit_angle_rad": float(ang_out),
                "enter_speed": float(abs(enter_speed)),
                "exit_speed": float(abs(exit_speed)),
                "circle_radius": float(r_um),
                "circle_center_x": float(cx),
                "circle_center_y": float(cy),
                "delta_p": float(delta_p),
                "path_length_inside": float(path_len),
            }
        )
        i = j + 1

    return passages


def _segment_circle_open_crossings(
    p_a: np.ndarray,
    p_b: np.ndarray,
    c: np.ndarray,
    r: float,
    eps: float,
) -> int:
    """线段 ``p_a→p_b`` 与圆周 ``‖x-c‖=r`` 在 ``t∈(0,1)`` 上的交点个数（端点不计入）。

    退化：线段长度 ≤ 1e-6 → 0。判别：对切（重根）按 **一次** 穿越计数；近重合根合并。
    ``eps`` 保留用于与调用方容差体系一致（求根判据仍以 ``r`` 为准）。
    """
    _ = eps
    p_a = np.asarray(p_a, dtype=np.float64).reshape(2)
    p_b = np.asarray(p_b, dtype=np.float64).reshape(2)
    c = np.asarray(c, dtype=np.float64).reshape(2)
    v = p_b - p_a
    lv = float(np.linalg.norm(v))
    if lv <= 1e-6:
        return 0
    u = p_a - c
    aa = float(np.dot(v, v))
    bb = 2.0 * float(np.dot(u, v))
    cc = float(np.dot(u, u)) - float(r) ** 2
    disc = bb * bb - 4.0 * aa * cc
    tol_t = max(1e-10, 1e-12 * lv)
    roots: list[float] = []
    if disc < -1e-10:
        return 0
    if abs(disc) <= 1e-10:
        if abs(aa) <= 1e-18:
            return 0
        t = -bb / (2.0 * aa)
        if tol_t < t < 1.0 - tol_t:
            roots.append(float(t))
    else:
        s = float(np.sqrt(max(disc, 0.0)))
        t1 = (-bb - s) / (2.0 * aa)
        t2 = (-bb + s) / (2.0 * aa)
        for t in (t1, t2):
            if tol_t < t < 1.0 - tol_t:
                roots.append(float(t))
    roots.sort()
    merged: list[float] = []
    for t in roots:
        if not merged or abs(t - merged[-1]) > 1e-7:
            merged.append(t)
    return len(merged)


def obstacle_disk_three_point_transit(
    p0: np.ndarray,
    p1: np.ndarray,
    p2: np.ndarray,
    c: np.ndarray,
    r_px: float,
    eps_px: float,
) -> bool:
    """障碍物圆盘「有入有出」局部判定（主规则 + 边–圆开区间交点补救）。"""
    c = np.asarray(c, dtype=np.float64).reshape(2)
    p0 = np.asarray(p0, dtype=np.float64).reshape(2)
    p1 = np.asarray(p1, dtype=np.float64).reshape(2)
    p2 = np.asarray(p2, dtype=np.float64).reshape(2)
    cx, cy = float(c[0]), float(c[1])
    r = float(r_px)
    eps = float(eps_px)
    d0 = _dist(float(p0[0]), float(p0[1]), cx, cy)
    d1 = _dist(float(p1[0]), float(p1[1]), cx, cy)
    d2 = _dist(float(p2[0]), float(p2[1]), cx, cy)
    if _outside_disk(d0, r, eps) and _inside_disk(d1, r, eps) and _outside_disk(d2, r, eps):
        return True
    if _outside_disk(d0, r, eps) and _outside_disk(d2, r, eps):
        n = _segment_circle_open_crossings(p0, p1, c, r, eps) + _segment_circle_open_crossings(
            p1, p2, c, r, eps
        )
        if n >= 2:
            return True
    return False


# 动态圆心：速度由 ``index ± half_span`` 内的位移 / Δtime 估计，抑制单步噪声
_DYNAMIC_VELOCITY_HALF_SPAN = 2


def _smoothed_velocity_unit_xy(
    track: pd.DataFrame,
    index: int,
    *,
    half_span: int = _DYNAMIC_VELOCITY_HALF_SPAN,
    min_prev_step_um_for_direct_direction: float | None = None,
) -> tuple[float, float] | None:
    """当前点的运动方向（单位向量，μm/s 等价于 μm 差商因仅要方向）。

    优先用 ``index-half_span .. index+half_span`` 的位移 / 时间差；窗口贴边时自动收紧到合法下标。
    速度模长过小则返回 ``None``。
    """
    n = len(track)
    if n < 2 or index < 0 or index >= n:
        return None
    tt = track["time"].to_numpy(dtype=float)
    xx = track["x"].to_numpy(dtype=float)
    yy = track["y"].to_numpy(dtype=float)

    if (
        min_prev_step_um_for_direct_direction is not None
        and np.isfinite(min_prev_step_um_for_direct_direction)
        and float(min_prev_step_um_for_direct_direction) > 0.0
        and index > 0
    ):
        dx1 = float(xx[index] - xx[index - 1])
        dy1 = float(yy[index] - yy[index - 1])
        step = math.hypot(dx1, dy1)
        if step >= float(min_prev_step_um_for_direct_direction):
            return float(dx1 / step), float(dy1 / step)

    for span in range(half_span, 0, -1):
        j0 = max(0, index - span)
        j1 = min(n - 1, index + span)
        dt = float(tt[j1] - tt[j0])
        if abs(dt) < 1e-18 or j1 <= j0:
            continue
        vx = (float(xx[j1]) - float(xx[j0])) / dt
        vy = (float(yy[j1]) - float(yy[j0])) / dt
        hyp = math.hypot(vx, vy)
        if hyp >= 1e-12:
            return float(vx / hyp), float(vy / hyp)
    return None


def _validate_input_df(df: pd.DataFrame) -> pd.DataFrame:
    required = ["idx", "frame", "time", "x", "y"]
    out = df.copy()
    out.columns = out.columns.str.strip()
    missing = [c for c in required if c not in out.columns]
    if missing:
        raise ValueError(f"输入缺少列: {missing}")
    return out.sort_values(by=["idx", "frame"]).reset_index(drop=True)


def _build_segment_rows_dynamic(
    track: pd.DataFrame,
    circle_radius_um: float,
    *,
    direct_velocity_step_threshold_um: float | None = None,
) -> list[dict]:
    """无障碍物动态圆：锚点即入点；从锚点起取第一次出圆。"""
    n = len(track)
    if n < 2:
        return []
    r = float(circle_radius_um)
    eps = _default_eps_um(r)
    xy = track[["x", "y"]].to_numpy(dtype=float)
    fr = track["frame"].to_numpy(dtype=float)
    tt = track["time"].to_numpy(dtype=float)
    seen: set[tuple[float, float]] = set()
    rows: list[dict] = []
    span = _DYNAMIC_VELOCITY_HALF_SPAN

    for i in range(n):
        mx, my = float(xy[i, 0]), float(xy[i, 1])
        if direct_velocity_step_threshold_um is not None:
            unit = _smoothed_velocity_unit_xy(
                track,
                i,
                half_span=span,
                min_prev_step_um_for_direct_direction=float(direct_velocity_step_threshold_um),
            )
        else:
            unit = _smoothed_velocity_unit_xy(track, i, half_span=span)
        if unit is None:
            continue
        ux, uy = unit
        cx = mx + r * ux
        cy = my + r * uy
        if i >= n - 1:
            continue

        qex, qey = mx, my
        fa = float(fr[i])
        ta = float(tt[i])

        bx0, by0 = float(xy[i + 1, 0]), float(xy[i + 1, 1])
        fb0 = float(fr[i + 1])
        tb0 = float(tt[i + 1])
        dt_in = tb0 - ta
        seg_len_in = float(np.hypot(bx0 - mx, by0 - my))
        enter_speed = seg_len_in / dt_in if abs(dt_in) > 1e-15 else 0.0
        vx_in = (bx0 - mx) / dt_in if abs(dt_in) > 1e-15 else 0.0
        vy_in = (by0 - my) / dt_in if abs(dt_in) > 1e-15 else 0.0

        inside_first_f = fb0
        j = i
        t_out: float | None = None
        axo = ayo = bxo = byo = 0.0
        fao = fbo = tao = tbo = 0.0
        seg_len_out = 0.0
        dt_out = 1.0
        while j < n - 1:
            ax2, ay2 = float(xy[j, 0]), float(xy[j, 1])
            bx2, by2 = float(xy[j + 1, 0]), float(xy[j + 1, 1])
            fa2, fb2 = float(fr[j]), float(fr[j + 1])
            ta2 = float(tt[j])
            tb2 = float(tt[j + 1])
            t_try = _linear_crossing_t_inside_to_outside(ax2, ay2, bx2, by2, cx, cy, r, eps)
            if t_try is not None:
                t_out = t_try
                axo, ayo, bxo, byo = ax2, ay2, bx2, by2
                fao, fbo = fa2, fb2
                tao, tbo = ta2, tb2
                seg_len_out = float(np.hypot(bxo - axo, byo - ayo))
                dt_out = tbo - tao
                break
            j += 1
        if t_out is None:
            continue

        qxx, qxy = _at_xy(axo, ayo, bxo, byo, t_out)
        exit_frame_out = fbo
        exit_time = _interp_edge(fao, fbo, tao, tbo, t_out)
        enter_time = ta
        exit_speed = seg_len_out / dt_out if abs(dt_out) > 1e-15 else 0.0
        vx_out = (bxo - axo) / dt_out if abs(dt_out) > 1e-15 else 0.0
        vy_out = (byo - ayo) / dt_out if abs(dt_out) > 1e-15 else 0.0
        inside_last_f = fao

        path_len = 0.0
        path_len += float(np.hypot(bx0 - qex, by0 - qey))
        for k in range(i + 1, j):
            x0, y0 = float(xy[k, 0]), float(xy[k, 1])
            x1, y1 = float(xy[k + 1, 0]), float(xy[k + 1, 1])
            path_len += float(np.hypot(x1 - x0, y1 - y0))
        path_len += float(np.hypot(qxx - axo, qxy - ayo))

        inside_dur = exit_time - enter_time
        if inside_dur <= 1e-15:
            inside_dur = max(1e-15, abs(exit_frame_out - fa) * 1e-3)

        disp = float(np.hypot(qxx - qex, qxy - qey))
        mean_sp = path_len / inside_dur if inside_dur > 1e-15 else 0.0
        diam = 2.0 * r
        L_norm = disp / diam if diam > 1e-15 else 0.0
        path_over_diam = path_len / diam if diam > 1e-15 else 0.0
        v_eff_norm = L_norm / path_over_diam if path_over_diam > 1e-18 else 0.0

        ang_in = math.atan2(vy_in, vx_in)
        ang_out = math.atan2(vy_out, vx_out)
        delta_p = (ang_out - ang_in + math.pi) % (2 * math.pi) - math.pi
        min_inside_path_um = 0.5 * r
        if path_len < min_inside_path_um:
            continue

        p = {
            "idx": int(track["idx"].iloc[0]),
            "enter_frame": fa,
            "exit_frame": exit_frame_out,
            "enter_time": enter_time,
            "exit_time": exit_time,
            "enter_x": qex,
            "enter_y": qey,
            "exit_x": qxx,
            "exit_y": qxy,
            "inside_frame_first": inside_first_f,
            "inside_frame_last": inside_last_f,
            "inside_duration_s": float(inside_dur),
            "inside_path_length_um": float(path_len),
            "inside_displacement_um": float(disp),
            "inside_mean_speed_um_s": float(mean_sp),
            "L_normalized": float(L_norm),
            "V_eff_normalized": float(v_eff_norm),
            "angle_change_rad": float(delta_p),
            "angle_change_deg": float(np.degrees(delta_p)),
            "enter_angle_rad": float(ang_in),
            "exit_angle_rad": float(ang_out),
            "enter_speed": float(abs(enter_speed)),
            "exit_speed": float(abs(exit_speed)),
            "circle_radius": float(r),
            "circle_center_x": float(cx),
            "circle_center_y": float(cy),
            "delta_p": float(delta_p),
            "path_length_inside": float(path_len),
        }
        key = (
            round(float(p["enter_frame"]), 5),
            round(float(p["exit_frame"]), 5),
            round(float(p["circle_center_x"]), 5),
            round(float(p["circle_center_y"]), 5),
        )
        if key in seen:
            continue
        seen.add(key)
        rows.append(p)
    return rows


def _build_segment_rows_obstacle_fixed_disk_um(
    track: pd.DataFrame,
    circle_radius_um: float,
    cx_um: float,
    cy_um: float,
    r_um: float,
):
    """障碍物固定圆：圆心半径（μm）固定，枚举所有穿行。"""
    _ = circle_radius_um
    return _enumerate_disk_passages_um(track, float(cx_um), float(cy_um), float(r_um))


_CIRCLE_SEGMENT_COLUMNS = [
    "idx",
    "enter_frame",
    "exit_frame",
    "enter_time",
    "exit_time",
    "enter_x",
    "enter_y",
    "exit_x",
    "exit_y",
    "inside_frame_first",
    "inside_frame_last",
    "inside_duration_s",
    "inside_path_length_um",
    "inside_displacement_um",
    "inside_mean_speed_um_s",
    "L_normalized",
    "V_eff_normalized",
    "angle_change_rad",
    "angle_change_deg",
    "enter_angle_rad",
    "exit_angle_rad",
    "enter_speed",
    "exit_speed",
    "circle_radius",
    "circle_center_x",
    "circle_center_y",
    "delta_p",
    "path_length_inside",  # μm，圆内折线路径长（与 inside_path_length_um 同值）
]


def analyze_circle_trajectories(
    data_source=None,
    target_idx=None,
    circle_radius=50,  # 微米 μm，写入结果表 circle_radius 列
    output_path=None,
    target_frame=None,
    df: pd.DataFrame | None = None,
    direct_velocity_step_threshold_um: float | None = None,
):
    """动态 301：滑动三点窗定义圆盘，全轨迹穿行入库（去重）。输入 ``df`` 的 x/y 为 μm。"""
    _ = (data_source, output_path, target_frame)
    if df is None:
        raise ValueError("需要传入 df（数据库读取后的轨迹/运动学表）")
    src = _validate_input_df(df)

    if target_idx is None:
        ids = src["idx"].unique().tolist()
    elif isinstance(target_idx, (list, tuple)):
        ids = list(target_idx)
    else:
        ids = [target_idx]

    rows = []
    for tid in ids:
        sub = src[src["idx"] == tid].copy()
        if len(sub) == 0:
            continue
        rows.extend(
            _build_segment_rows_dynamic(
                sub,
                float(circle_radius),
                direct_velocity_step_threshold_um=direct_velocity_step_threshold_um,
            )
        )

    r_um = float(circle_radius)
    logger.info(
        f"301 穿行枚举(动态速度定向圆): 分析圆半径={log_str_um(r_um)}, 运动学行数={len(src)}, "
        f"参与颗粒数={len(ids)}, 枚举片段数={len(rows)}"
    )
    if not rows:
        return pd.DataFrame(columns=_CIRCLE_SEGMENT_COLUMNS)
    return pd.DataFrame(rows)


def analyze_circle_trajectories_fixed_circle(
    data_source=None,
    circle_center_x=0.0,
    circle_center_y=0.0,
    circle_radius=50.0,
    output_path=None,
    target_frame=None,
    target_idx=None,
    scale_um_per_pixel=1.0,
    df: pd.DataFrame | None = None,
):
    """固定圆模式：轨迹为 μm；圆心参数为**像素**（与 obstacle_fixed_circle 一致），在此乘 scale 转为 μm。"""
    _ = (data_source, output_path, target_frame)
    if df is None:
        raise ValueError("需要传入 df（数据库读取后的轨迹/运动学表）")
    scale = float(scale_um_per_pixel)
    if scale <= 0.0:
        raise ValueError("scale_um_per_pixel 必须为正")
    r_um = float(circle_radius)
    if r_um <= 0.0:
        raise ValueError("非法半径")
    cx_um = float(circle_center_x) * scale
    cy_um = float(circle_center_y) * scale
    src = _validate_input_df(df)

    if target_idx is None:
        ids = src["idx"].unique().tolist()
    elif isinstance(target_idx, (list, tuple)):
        ids = list(target_idx)
    else:
        ids = [target_idx]

    rows = []
    for tid in ids:
        sub = src[src["idx"] == tid].copy()
        if len(sub) == 0:
            continue
        for p in _build_segment_rows_obstacle_fixed_disk_um(
            sub,
            float(circle_radius),
            cx_um,
            cy_um,
            r_um,
        ):
            p = dict(p)
            p["circle_radius"] = float(circle_radius)
            rows.append(p)

    logger.info(
        f"301 穿行枚举(障碍物固定圆): 圆心(μm)=({log_str_um(cx_um)}, {log_str_um(cy_um)}), "
        f"分析圆半径(μm)={log_str_um(r_um)}, 运动学行数={len(src)}, 参与颗粒数={len(ids)}, "
        f"枚举片段数={len(rows)}"
    )
    if not rows:
        return pd.DataFrame(columns=_CIRCLE_SEGMENT_COLUMNS)
    return pd.DataFrame(rows)


def plot_trajectory_segment(
    data_source, result_row, output_path=None, df: pd.DataFrame | None = None
):
    """兼容接口：该绘图由 Web 前端承担。"""
    _ = (data_source, result_row, output_path, df)
    logger.info("trajectory segment 绘图在新版 Web 前端完成")
