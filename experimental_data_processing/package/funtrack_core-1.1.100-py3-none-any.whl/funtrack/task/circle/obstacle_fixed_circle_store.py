"""障碍物固定圆结果与 DataFrame 的互转工具。"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
from nltlog import getLogger

from funtrack.task.circle.obstacle_circle import ObstacleCircleResult

logger = getLogger("funtrack")


class ObstacleFixedCircleStore:
    """``obstacle_fixed_circle`` 表的行结构与结果对象互转。"""

    TABLE = "obstacle_fixed_circle"

    def __init__(self, db_path: Path | str) -> None:
        self._db_path = Path(db_path)

    @staticmethod
    def obstacle_result_to_dataframe(
        result: ObstacleCircleResult, *, expected_marker_count: int
    ) -> pd.DataFrame:
        pts: list[list[float]] = []
        fallback_r = float(result.obstacle_marker_radius_px)
        for t in result.marker_points or []:
            if len(t) >= 3:
                pts.append([float(t[0]), float(t[1]), float(t[2])])
            elif len(t) >= 2:
                pts.append([float(t[0]), float(t[1]), fallback_r])
        return pd.DataFrame(
            {
                "center_x": [float(result.center_x)],
                "center_y": [float(result.center_y)],
                "radius": [float(result.radius)],
                "frame_index": [int(result.frame_index)],
                "marker_count": [int(result.marker_count)],
                "score": [float(result.score)],
                "strict_mode_used": [bool(result.strict_mode_used)],
                "obstacle_marker_radius_px": [float(result.obstacle_marker_radius_px)],
                "marker_points_json": [json.dumps(pts, ensure_ascii=False)],
                "expected_marker_count": [int(expected_marker_count)],
            }
        )

    @staticmethod
    def _row_to_result(row: pd.Series) -> ObstacleCircleResult | None:
        try:
            raw_json = row.get("marker_points_json")
            if raw_json is None or (isinstance(raw_json, float) and pd.isna(raw_json)):
                marker_points: list[tuple[float, float, float]] = []
            else:
                data: Any = json.loads(str(raw_json))
                default_r = float(row.get("obstacle_marker_radius_px", 5.0))
                marker_points: list[tuple[float, float, float]] = []
                for p in data:
                    if not isinstance(p, (list, tuple)) or len(p) < 2:
                        continue
                    x, y = float(p[0]), float(p[1])
                    r = float(p[2]) if len(p) >= 3 else default_r
                    marker_points.append((x, y, r))
            sm = row.get("strict_mode_used")
            if sm is None or pd.isna(sm):
                strict_used = False
            else:
                strict_used = bool(sm)
            return ObstacleCircleResult(
                center_x=float(row["center_x"]),
                center_y=float(row["center_y"]),
                radius=float(row["radius"]),
                frame_index=int(row["frame_index"]),
                marker_count=int(row["marker_count"]),
                score=float(row["score"]),
                strict_mode_used=strict_used,
                marker_points=marker_points,
                obstacle_marker_radius_px=float(row.get("obstacle_marker_radius_px", 5.0)),
            )
        except Exception as e:
            logger.warning(f"解析 obstacle_fixed_circle 行失败，将忽略缓存: {e}")
            return None

    @classmethod
    def from_dataframe(
        cls,
        df: pd.DataFrame | None,
        *,
        expected_marker_count: int | None = None,
    ) -> ObstacleCircleResult | None:
        if df is None or df.empty:
            return None
        row = df.iloc[0]
        if expected_marker_count is not None and "expected_marker_count" in row.index:
            try:
                ec_raw = row["expected_marker_count"]
                if ec_raw is not None and not pd.isna(ec_raw):
                    ec = int(ec_raw)
                    if ec != int(expected_marker_count):
                        logger.info(
                            f"障碍物固定圆缓存 expected_marker_count={ec} 与当前 {expected_marker_count} 不一致，将重新检测"
                        )
                        return None
            except (TypeError, ValueError):
                pass
        return cls._row_to_result(row)

    def read(
        self, video_id: int, *, expected_marker_count: int | None = None
    ) -> ObstacleCircleResult | None:
        """兼容旧调用：从 ``results.db`` 读取一行并转成 ``ObstacleCircleResult``。"""
        from funtrack.services.results_db import read_table

        df = read_table(
            db_path=self._db_path,
            table=self.TABLE,
            video_id=int(video_id),
            limit=1,
        )
        return self.from_dataframe(df, expected_marker_count=expected_marker_count)

    def write(
        self,
        video_id: int,
        result: ObstacleCircleResult,
        *,
        expected_marker_count: int,
    ) -> None:
        """兼容旧调用：把 ``ObstacleCircleResult`` 写入 ``results.db``。"""
        from funtrack.services.results_db import write_table

        df = self.obstacle_result_to_dataframe(
            result, expected_marker_count=int(expected_marker_count)
        )
        write_table(
            db_path=self._db_path,
            table=self.TABLE,
            df=df,
            video_id=int(video_id),
            clear_before_write=True,
        )

    def clear(self, video_id: int) -> None:
        """兼容旧调用：清理指定视频的缓存行。"""
        from funtrack.services.results_db import clear_video_rows

        clear_video_rows(
            db_path=self._db_path,
            table=self.TABLE,
            video_id=int(video_id),
        )
