"""圆形区域分析任务。

**模式（仅由 ``obstacle_circle_count`` 决定，与请求里的 ``circle_mode`` 字符串无关）**

- **无障碍物 / 动态圆**（``occ == 0``）：``analyze_circle_trajectories``，以各帧位置为起点、
  平滑速度方向前移分析半径得圆心，枚举穿行（详见 ``trajectories`` 模块说明）；无法估速时跳过该锚点。
- **有障碍物 / 固定圆**（``occ > 0``）：从障碍物视频或 DB 缓存得到固定圆心、半径，走
  ``analyze_circle_trajectories_fixed_circle``。

流水线 ``run_circle`` 在 ``occ > 0`` 时注入 ``obstacle_detection_video_path``；本任务在读取
运动学前校验该路径存在。
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

import pandas as pd
from nltlog import getLogger

from funtrack.core import BaseTask, FuntrackTaskRequest
from funtrack.core.utils import read_obstacle_video_frame_size_px
from funtrack.task.circle.log_format import log_str_scale_um_per_px, log_str_um
from funtrack.task.circle.neighbor_segment_filter import (
    NEIGHBOR_PROXIMITY_FRACTION_OF_ANALYSIS_DIAMETER,
    filter_circle_segments_by_neighbor_proximity,
)
from funtrack.task.circle.obstacle_circle import ObstacleCircleResult
from funtrack.task.circle.particle_radius import analysis_radius_um_from_circle_task_param
from funtrack.task.circle.trajectories import (
    analyze_circle_trajectories,
    analyze_circle_trajectories_fixed_circle,
)
from funtrack.task.obstacle_detection import validate_obstacle_detection_result
from funtrack.task.obstacle_detection.service import (
    ObstacleVideoDetectionRequest,
    run_obstacle_video_detection_request,
)

logger = getLogger("funtrack")


def _coerce_obstacle_circle_count(raw: Any) -> int:
    try:
        if raw is None or (isinstance(raw, float) and pd.isna(raw)):
            return 0
        return int(float(raw))
    except (TypeError, ValueError):
        return 0


# 与 trajectories._validate_input_df 一致；用于表缺失或 0 行且无列名时的空输入
_KINEMATICS_MIN_COLUMNS = ["idx", "frame", "time", "x", "y"]


def _empty_kinematics_df() -> pd.DataFrame:
    return pd.DataFrame(columns=list(_KINEMATICS_MIN_COLUMNS))


def _load_kinematics_df_for_301(
    *,
    kinematics_df: pd.DataFrame,
    statistics_df: pd.DataFrame | None,
) -> pd.DataFrame:
    """供 301 使用的 ``kinematics_201``：优先只保留 ``statistics_202`` 中未过滤颗粒。"""
    df_kin = kinematics_df.copy()
    if len(df_kin.columns) > 0:
        df_kin.columns = df_kin.columns.str.strip()
    if df_kin.empty and not set(_KINEMATICS_MIN_COLUMNS).issubset(df_kin.columns):
        logger.info("kinematics_201 无表或无列，按 0 颗粒继续圆形分析")
        return _empty_kinematics_df()
    if statistics_df is None or statistics_df.empty:
        return df_kin
    stats_df = statistics_df.copy()
    if len(stats_df.columns) > 0:
        stats_df.columns = stats_df.columns.str.strip()
    if "idx" not in stats_df.columns or "is_filtered" not in stats_df.columns:
        return df_kin
    col = stats_df["is_filtered"]
    if col.dtype == bool:
        valid_indices = stats_df.loc[~col, "idx"].tolist()
    else:
        is_unfiltered = ~col.astype(str).str.strip().str.lower().isin(["true", "1"])
        valid_indices = stats_df.loc[is_unfiltered, "idx"].tolist()
    if "idx" not in df_kin.columns:
        return df_kin
    out = df_kin[df_kin["idx"].isin(valid_indices)].copy()
    logger.info(
        "301 输入运动学: 使用 statistics_202 未过滤颗粒, 行数 {}/{}, 颗粒数 {}",
        len(out),
        len(df_kin),
        int(out["idx"].nunique()) if len(out) > 0 else 0,
    )
    return out


def _resolve_obstacle_fixed_circle_um(
    *,
    cached_fixed_circle: ObstacleCircleResult | None,
    occ: int,
    det_path: str,
    marker_um: Optional[float],
    scale: float,
    circle_r_eff_um: float,
    obstacle_strict_mode: bool,
) -> tuple[ObstacleCircleResult, float]:
    """障碍物模式：得到固定圆（像素几何）及分析半径（μm，已乘 scale）。"""
    frame_wh = read_obstacle_video_frame_size_px(str(det_path))
    fw, fh = frame_wh if frame_wh is not None else (None, None)

    fixed_circle = cached_fixed_circle
    if fixed_circle is not None:
        v_cache = validate_obstacle_detection_result(
            fixed_circle,
            expected_marker_count=occ,
            marker_diameter_um=marker_um,
            scale_um_per_pixel=scale,
            circle_analysis_radius_um=(circle_r_eff_um if circle_r_eff_um > 0 else None),
            frame_width_px=fw,
            frame_height_px=fh,
        )
        if not v_cache.ok:
            logger.warning(
                "障碍物固定圆缓存未通过输出校验，将忽略并重新检测: {}",
                v_cache.reason,
            )
            fixed_circle = None
        else:
            r_px = float(fixed_circle.radius)
            radius_um = r_px * scale
            logger.info(
                f"障碍物固定圆(缓存): 圆心(px)=({fixed_circle.center_x:.4f}, {fixed_circle.center_y:.4f}), "
                f"半径(px)={r_px:.4f}, 半径(μm)={log_str_um(radius_um)}, "
                f"frame={fixed_circle.frame_index}, markers={fixed_circle.marker_count}, "
                f"strict={fixed_circle.strict_mode_used}"
            )
            return fixed_circle, radius_um

    analysis_r_um = circle_r_eff_um if circle_r_eff_um > 0 else None
    resp = run_obstacle_video_detection_request(
        ObstacleVideoDetectionRequest(
            video_path=str(det_path),
            expected_marker_count=occ,
            marker_um=marker_um,
            scale_um_per_pixel=scale,
            circle_analysis_radius_um=analysis_r_um,
            strict_expected_count=bool(obstacle_strict_mode),
        )
    )
    fixed_circle = (
        ObstacleCircleResult.from_dict(resp.result) if resp.ok and resp.result is not None else None
    )
    if fixed_circle is None:
        raise ValueError(
            "未能从障碍物视频识别到固定圆（且无有效 obstacle_fixed_circle 缓存），无法写入 circle_301；"
            "检测链（主路径/宽松/超宽松）均已尝试且无候选通过输出校验（个数、±20% 半径、"
            "圆心相对画幅中心各轴 ±10%），请检查画面、个数与颗粒预设。"
        )
    r_px = float(fixed_circle.radius)
    radius_um = r_px * scale
    logger.info(
        f"障碍物固定圆(实时检测): 圆心(px)=({fixed_circle.center_x:.4f}, {fixed_circle.center_y:.4f}), "
        f"半径(px)={r_px:.4f}, 半径(μm)={log_str_um(radius_um)}, "
        f"frame={fixed_circle.frame_index}, markers={fixed_circle.marker_count}, "
        f"strict={fixed_circle.strict_mode_used}"
    )
    return fixed_circle, radius_um


@dataclass
class CircleRegionRequest(FuntrackTaskRequest):
    results_db_path: str = ""
    video_id: int = 0
    target_idx: int | list[int] | None = None
    circle_radius: float = 50
    target_frame: int | None = None
    scale_um_per_pixel: float = 1.0
    frame_height_px: int | None = None
    circle_mode: str = "dynamic"
    obstacle_detection_video_path: str | None = None
    obstacle_circle_count: int = 0
    obstacle_strict_mode: bool = True
    obstacle_marker_diameter_um: float | None = None
    # 历史任务 JSON 可能仍带此字段；邻局过滤已不再读取（阈值改为 0.1×圆形分析直径）。
    neighbor_body_diameter_um: float | None = None
    neighbor_proximity_fraction_of_analysis_diameter: float = (
        NEIGHBOR_PROXIMITY_FRACTION_OF_ANALYSIS_DIAMETER
    )
    # 流水线从 videos 表注入的可读摘要（μm/px、分析圆直径来源等）
    calibration_log: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "CircleRegionRequest":
        payload = dict(data or {})
        allowed = {
            "results_db_path",
            "video_id",
            "target_idx",
            "circle_radius",
            "output_dir",
            "target_frame",
            "output_prefix",
            "overwrite",
            "request_id",
            "meta",
            "scale_um_per_pixel",
            "frame_height_px",
            "circle_mode",
            "obstacle_detection_video_path",
            "obstacle_circle_count",
            "obstacle_strict_mode",
            "obstacle_marker_diameter_um",
            "neighbor_body_diameter_um",
            "neighbor_proximity_fraction_of_analysis_diameter",
            "calibration_log",
        }
        payload = {k: v for k, v in payload.items() if k in allowed}
        return cls(**payload)

    def to_dict(self) -> dict[str, Any]:
        return super().to_dict()


class CircleRegionTask(BaseTask):
    """圆形区域分析任务：分析进入指定圆形区域的轨迹段。输入为颗粒运动学结果文件。"""

    task_name = "301"

    def __init__(
        self,
        request: CircleRegionRequest,
    ):
        super().__init__(request)

        self.output_ref = None

    def validate_inputs(self) -> bool:
        db = Path(self.request.results_db_path)
        if not db.exists():
            logger.error(f"results_db_path not found: {db}")
            return False
        return True

    def get_output_paths(self):
        return {"results_db": Path(self.request.results_db_path)}

    def get_task_inputs(self):
        r = self.request
        dp = (r.obstacle_detection_video_path or "").strip() or None
        m_um = r.obstacle_marker_diameter_um
        r_param = float(r.circle_radius)
        r_eff = analysis_radius_um_from_circle_task_param(r_param)
        d_analysis = 2.0 * r_eff
        n_thresh = (
            float(r.neighbor_proximity_fraction_of_analysis_diameter) * d_analysis
            if d_analysis > 0 and float(r.neighbor_proximity_fraction_of_analysis_diameter) > 0
            else None
        )
        return {
            "results_db_path": str(Path(r.results_db_path)),
            "video_id": int(r.video_id),
            "target_idx": r.target_idx,
            "circle_radius": r_param,
            "circle_analysis_radius_um": r_eff,
            "analysis_circle_diameter_um": d_analysis,
            "neighbor_proximity_threshold_um": n_thresh,
            "video_calibration_log": r.calibration_log,
            "target_frame": r.target_frame,
            "scale_um_per_pixel": float(r.scale_um_per_pixel),
            "frame_height_px": int(r.frame_height_px) if r.frame_height_px is not None else None,
            "circle_mode": r.circle_mode,
            "obstacle_detection_video_path": dp,
            "obstacle_circle_count": _coerce_obstacle_circle_count(r.obstacle_circle_count),
            "obstacle_strict_mode": bool(r.obstacle_strict_mode),
            "obstacle_marker_diameter_um": float(m_um) if m_um is not None else None,
            "neighbor_body_diameter_um": (
                float(r.neighbor_body_diameter_um)
                if r.neighbor_body_diameter_um is not None
                else None
            ),
            "neighbor_proximity_fraction_of_analysis_diameter": float(
                r.neighbor_proximity_fraction_of_analysis_diameter
            ),
        }

    def get_dependencies(self):
        return []

    def get_task_results(self):
        if not self.results or "df" not in self.results:
            return None
        df = self.results["df"]
        return {"segments_count": len(df) if df is not None else 0}

    def apply_output_paths(self, paths):
        self.output_ref = None

    def get_skip_return_value(self, record):
        return None

    def _run(
        self,
        *,
        kinematics_df: pd.DataFrame,
        statistics_df: pd.DataFrame | None = None,
        cached_obstacle_fixed_circle: ObstacleCircleResult | None = None,
        **kwargs: Any,
    ) -> pd.DataFrame:
        _ = kwargs
        self.output_ref = None

        req = self.request
        occ = _coerce_obstacle_circle_count(req.obstacle_circle_count)
        circle_r_param_um = float(req.circle_radius)
        circle_r_eff_um = analysis_radius_um_from_circle_task_param(circle_r_param_um)
        if abs(circle_r_eff_um - circle_r_param_um) > 1e-9:
            logger.info(
                f"301 circle_radius 任务参数 {log_str_um(circle_r_param_um)} → 几何分析半径 "
                f"{log_str_um(circle_r_eff_um)}（与预设直径 85/265/1500 μm 重合时按直径折半）"
            )
        scale = float(req.scale_um_per_pixel)
        frame_height_px: int | None = None
        if req.frame_height_px is not None:
            try:
                fh = int(req.frame_height_px)
                if fh > 0:
                    frame_height_px = fh
            except (TypeError, ValueError):
                frame_height_px = None
        t_idx = req.target_idx
        t_frame = req.target_frame
        det_path = (req.obstacle_detection_video_path or "").strip() or None
        marker_um: Optional[float] = (
            float(req.obstacle_marker_diameter_um)
            if req.obstacle_marker_diameter_um is not None
            else None
        )

        frame_info = f"Frame {t_frame}" if t_frame is not None else "All frames"
        if t_idx is None:
            target_info = "All trajectories"
        elif isinstance(t_idx, (list, tuple)):
            target_info = f"Trajectories {t_idx}"
        else:
            target_info = f"Trajectory {t_idx}"

        # 仅由障碍物小圆数决定模式；缺路径时在读取运动学前失败（与流水线 / API 一致）
        use_obstacle = occ > 0
        run_circle_mode = "obstacle" if use_obstacle else "dynamic"
        req.circle_mode = run_circle_mode
        if use_obstacle:
            if not det_path or not Path(det_path).is_file():
                raise ValueError(
                    "障碍物模式需要有效的障碍物检测视频路径（由流水线注入主视频本地路径）。"
                )

        cal = (req.calibration_log or "").strip() or "未注入（非平台流水线或缺 videos 摘要）"
        analysis_circle_diameter_um = 2.0 * circle_r_eff_um
        neighbor_fraction = float(req.neighbor_proximity_fraction_of_analysis_diameter)
        if analysis_circle_diameter_um > 0:
            if neighbor_fraction > 0:
                neighbor_thresh_um = neighbor_fraction * analysis_circle_diameter_um
                neighbor_filter_info = (
                    f"排斥圆心距≤{log_str_um(neighbor_thresh_um)} "
                    f"（={neighbor_fraction}×分析圆直径 {log_str_um(analysis_circle_diameter_um)}）"
                )
            else:
                neighbor_filter_info = f"关闭（neighbor_fraction={neighbor_fraction}）"
        else:
            neighbor_filter_info = "跳过（分析半径≤0）"
        self.print_info(
            Input_DataFrame=f"kinematics_df rows={len(kinematics_df)}",
            Target_Frame=frame_info,
            Target_Trajectory_ID=target_info,
            Video_Calibration=cal,
            Scale_um_per_px=log_str_scale_um_per_px(scale),
            Circle_Param_um=f"{log_str_um(circle_r_param_um)} (任务入参 μm；预设直径时在 301 内折半为分析半径)",
            Circle_Analysis_Radius_um=log_str_um(circle_r_eff_um),
            Neighbor_Proximity_Filter=neighbor_filter_info,
            Circle_Mode=run_circle_mode,
            Obstacle_Video=(str(det_path) if det_path is not None else "None"),
            Obstacle_Circle_Count=occ,
            Obstacle_Strict_Mode=bool(req.obstacle_strict_mode),
            Output_DataFrame="circle_301_like_df",
        )

        kinematics_df_for_analysis = _load_kinematics_df_for_301(
            kinematics_df=kinematics_df,
            statistics_df=statistics_df,
        )

        if use_obstacle:
            assert det_path is not None
            fixed_circle, radius_um = _resolve_obstacle_fixed_circle_um(
                cached_fixed_circle=cached_obstacle_fixed_circle,
                occ=occ,
                det_path=det_path,
                marker_um=marker_um,
                scale=scale,
                circle_r_eff_um=circle_r_eff_um,
                obstacle_strict_mode=bool(req.obstacle_strict_mode),
            )
            results_df = analyze_circle_trajectories_fixed_circle(
                "",
                circle_center_x=fixed_circle.center_x,
                circle_center_y=fixed_circle.center_y,
                circle_radius=radius_um,
                output_path=None,
                target_frame=t_frame,
                target_idx=t_idx,
                scale_um_per_pixel=scale,
                df=kinematics_df_for_analysis,
            )
        else:
            direct_velocity_step_threshold_um = (
                float(frame_height_px) * scale * 0.02 if frame_height_px is not None else None
            )
            if direct_velocity_step_threshold_um is not None:
                logger.info(
                    "301 动态圆速度方向: 前后帧位移≥{:.6g}μm(=画面高{}px×{:.6g}μm/px×2%)时优先用前一帧→当前帧方向，否则回退平滑速度方向。",
                    direct_velocity_step_threshold_um,
                    frame_height_px,
                    scale,
                )
            # 无障碍物：滑动三点窗 + 任务分析半径（μm），见 trajectories.analyze_circle_trajectories
            results_df = analyze_circle_trajectories(
                "",
                t_idx,
                circle_radius=float(circle_r_eff_um),
                output_path=None,
                target_frame=t_frame,
                df=kinematics_df_for_analysis,
                direct_velocity_step_threshold_um=direct_velocity_step_threshold_um,
            )

        if results_df is not None and analysis_circle_diameter_um > 0 and neighbor_fraction > 0:
            n_before = len(results_df)
            results_df = filter_circle_segments_by_neighbor_proximity(
                results_df,
                kinematics_df_for_analysis,
                analysis_circle_diameter_um,
                proximity_fraction_of_analysis_diameter=neighbor_fraction,
            )
            n_after = len(results_df)
            if n_before > 0 and n_after == 0:
                logger.warning(
                    f"301 邻局过滤后无可入库片段（原为 {n_before} 条）。"
                    "阈值与首条命中原因见上文「邻局过滤」日志。"
                )

        if results_df is None:
            results_df = pd.DataFrame()
        self.results = {"df": results_df}
        return results_df

    def print_summary(self):
        n_segments = None
        if self.results and self.results.get("df") is not None:
            n_segments = len(self.results["df"])
        if n_segments is not None:
            if n_segments > 0:
                logger.info(f"Analysis Complete! Found {n_segments} trajectory segments")
            else:
                logger.warning("No trajectory segments found in the circle region")
                logger.info("Try adjusting parameters:")
                logger.info("  - Different target trajectory ID")
                logger.info("  - Different target frame")
                logger.info("  - Larger circle radius or forward distance")
