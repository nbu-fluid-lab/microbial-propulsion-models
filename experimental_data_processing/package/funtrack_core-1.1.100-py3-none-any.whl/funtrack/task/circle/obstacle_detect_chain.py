"""障碍物检测链兼容入口。

主实现已下沉到 ``funtrack.task.obstacle_detection.service``，本模块仅保留历史导入路径。
"""

from __future__ import annotations

from funtrack.core.utils import read_obstacle_video_frame_size_px
from funtrack.task.circle.obstacle_circle import ObstacleCircleResult
from funtrack.task.obstacle_detection.frame import recognizers as _recognizers
from funtrack.task.obstacle_detection import service as _obstacle_service
from funtrack.task.obstacle_detection.service import (
    ObstacleVideoDetectionRequest,
    run_obstacle_video_detection_request,
)

logger = _obstacle_service.logger
RelaxedHoughObstacleRecognizer = _recognizers.RelaxedHoughObstacleRecognizer
UltraRelaxedHoughObstacleRecognizer = _recognizers.UltraRelaxedHoughObstacleRecognizer


def run_obstacle_detection_chain(
    video_path: str,
    *,
    expected_marker_count: int,
    marker_um: float | None,
    scale_um_per_pixel: float,
    circle_analysis_radius_um: float | None,
    strict_expected_count: bool,
    debug: bool = False,
    debug_output_dir: str | None = None,
) -> ObstacleCircleResult | None:
    """便捷封装：经 ``run_obstacle_video_detection_request`` 执行，兼容历史调用签名。"""
    req = ObstacleVideoDetectionRequest(
        video_path=video_path,
        expected_marker_count=expected_marker_count,
        marker_um=marker_um,
        scale_um_per_pixel=scale_um_per_pixel,
        circle_analysis_radius_um=circle_analysis_radius_um,
        strict_expected_count=strict_expected_count,
        debug=debug,
        debug_output_dir=debug_output_dir,
    )
    resp = run_obstacle_video_detection_request(req)
    if not resp.ok or resp.result is None:
        return None
    return ObstacleCircleResult.from_dict(resp.result)
