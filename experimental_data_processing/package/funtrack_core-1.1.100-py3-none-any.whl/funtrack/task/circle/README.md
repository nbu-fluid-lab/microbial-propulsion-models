# circle 模块说明

本文档说明 `funtrack.task.circle`（301 圆形分析）的代码架构与运行逻辑，内容与当前实现保持一致。

## 1. 模块定位

`circle` 模块负责把运动学轨迹（`kinematics_201`）转换为圆区域穿行片段（`circle_301`）。

核心能力：
- 在圆盘内识别“圆外 -> 圆内 -> 圆外”的完整穿行片段。
- 计算每个片段的几何/运动指标（路径长、历时、速度、L、V_eff、delta_p 等）。
- 支持两种模式：
  - 无障碍物：动态圆（圆心随轨迹局部速度方向变化）
  - 有障碍物：固定圆（圆心/半径固定）

入口实现位于：`src/funtrack/task/circle/task.py`。

---

## 2. 目录结构与职责

- `task.py`
  - 301 任务入口（`CircleTask`）。
  - 组织输入读取、模式选择、调用分析函数、邻局过滤、输出 DataFrame。
- `trajectories.py`
  - 圆穿行枚举与指标计算核心。
  - 提供动态圆/固定圆两条分析函数。
- `particle_radius.py`
  - 任务参数 `circle_radius` 到“分析半径”的解释与折半规则（预设直径场景）。
- `neighbor_segment_filter.py`
  - 写出前邻局过滤（按时间窗查异颗粒距离阈值）。
- `obstacle_fixed_circle_store.py`
  - 固定圆缓存（`obstacle_fixed_circle`）读写。
- `obstacle_circle.py`
  - 固定圆结果对象（与 obstacle_detection 结果字段兼容）。
- `obstacle_preview.py`
  - 固定圆预览图渲染。
- `log_format.py`
  - 日志数字格式化。

---

## 3. 运行模式（由 obstacle_circle_count 决定）

代码位置：`task.py`。

- `obstacle_circle_count == 0`：动态圆模式（`dynamic`）
  - 调用 `analyze_circle_trajectories(...)`
- `obstacle_circle_count > 0`：固定圆模式（`obstacle`）
  - 先解析/检测固定圆，再调用 `analyze_circle_trajectories_fixed_circle(...)`

注意：
- 模式不是由字符串参数决定，而是由 `obstacle_circle_count` 决定。

---

## 4. 输入数据与预处理

301 主要输入：
- `kinematics_201`（轨迹时序点，至少包含 `idx, frame, time, x, y`）
- 可选 `statistics_202`（用于剔除已过滤颗粒）

预处理流程（`task.py::_load_kinematics_df_for_301`）：
1. 读取 `kinematics_201`。
2. 若有 `statistics_202` 且含 `idx/is_filtered`，仅保留未过滤颗粒轨迹。
3. 空表/缺表时按空输入继续，最终产出空结果而不是异常中断。

---

## 5. 圆几何定义

### 5.1 动态圆（无障碍物）

代码位置：`trajectories.py::_build_segment_rows_dynamic`。

对轨迹每个锚点：
1. 用前后窗口估计平滑速度方向单位向量 `u=(ux,uy)`。
2. 以当前点 `(mx,my)` 沿 `u` 前移分析半径 `r` 得到圆心：
   - `cx = mx + r * ux`
   - `cy = my + r * uy`
3. 若该锚点速度方向不可估（`unit is None`），**直接跳过该锚点**。

> 当前实现已完全移除“三点外心回退”逻辑。

### 5.2 固定圆（有障碍物）

代码位置：`task.py::_resolve_obstacle_fixed_circle_um`。

优先级：
1. 先读 `obstacle_fixed_circle` 缓存并做输出校验。
2. 缓存不可用时，调用 obstacle_detection 视频检测得到固定圆。
3. 检测失败则 301 失败（并记录错误日志）。

固定圆提供：
- 圆心（像素）
- 分析半径（微米，结合 scale 转换）

---

## 6. 穿行枚举与指标计算

核心函数：`trajectories.py::_enumerate_disk_passages_um`。

判定规则：
- 只保留完整“外->内->外”穿行。
- 入/出点通过相邻帧线段与圆周求交得到。

输出列（`_CIRCLE_SEGMENT_COLUMNS`）包含：
- 标识与时序：`idx`, `enter_frame`, `exit_frame`, `time_inside`
- 几何点：`enter_x/y`, `exit_x/y`, `circle_center_x/y`, `circle_radius`
- 路径与速度：`path_length_inside`, `avg_speed_inside`, `enter_speed`, `exit_speed`
- 归一化指标：`L`, `V_eff`, `delta_p`
- 以及相关辅助字段

去重：
- 动态圆按 `(enter_frame, exit_frame, circle_center_x, circle_center_y)` 去重，避免同帧不同圆心误合并。

---

## 7. 邻局过滤（写出前）

代码位置：`neighbor_segment_filter.py`。

在片段时间窗内，若存在异颗粒与当前颗粒中心距小于阈值，则剔除该片段。
- 阈值 = `0.1 * 分析圆直径(μm)`（当前默认）
- 分析圆直径 = `2 * 分析半径`

该过滤在 `task.py` 中于结果写出前执行。

---

## 8. 参数语义（重点）

`circle_radius`（任务入参）在 `particle_radius.py` 中解释：
- 若落在预设“分析直径”容差内（如 1500/265/85），按“直径”折半为分析半径。
- 否则按“半径”直接使用。

因此界面传参和内部几何半径之间存在一层“直径/半径兼容解释”。

---

## 9. 入口到输出的完整流程

1. `CircleTask.run()` 读取请求与输入表。
2. 按 `obstacle_circle_count` 选动态圆或固定圆模式。
3. 调用 `analyze_circle_trajectories*` 枚举穿行片段。
4. 执行邻局过滤。
5. 产出 DataFrame 供 `circle_301` 落库与后续 API 使用。

---

## 10. 与 obstacle_detection 的关系

- `circle` 不实现障碍物识别算法本身。
- 识别职责在 `funtrack.task.obstacle_detection`。
- `circle` 仅消费其输出（固定圆几何），并负责缓存读写与分析执行。

---

## 11. 常见排查点

- 结果为空：
  - `kinematics_201` 是否为空或被 `statistics_202` 全部过滤。
  - 动态圆模式下是否大量锚点速度不可估导致被跳过。
  - 固定圆模式下 obstacle_detection 是否失败。
- 结果偏少：
  - 邻局过滤阈值是否过严。
  - 轨迹是否很短或无完整“外->内->外”穿行。

