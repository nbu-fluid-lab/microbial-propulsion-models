"""Pipeline tasks and colocated domain code under ``funtrack.task.<domain>``."""

from funtrack.task.analysis import (
    TrajectoryDataTask,
    analyze_and_visualize,
    analyze_tracks,
    calculate_angle,
    calculate_angular_velocity,
    calculate_velocity,
    filter_tracks,
    smooth_tracks,
)
from funtrack.task.circle import (
    CircleRegionTask,
    analyze_circle_trajectories,
    plot_trajectory_segment,
)
from funtrack.task.kinematics import KINEMATICS_COLUMNS, ParticleKinematicsTask
from funtrack.task.statistics import (
    ParticleStatisticsTask,
    filter_kinematics_by_statistics,
    filter_particles_by_statistics,
    get_particle_indices,
)
from funtrack.task.tracking import (
    BacteriaTracker,
    TrajectoryTrackingTask,
    estimate_detection_params,
)
from funtrack.task.video import VideoInfoTask

__all__ = [
    "TrajectoryDataTask",
    "analyze_and_visualize",
    "analyze_tracks",
    "calculate_angle",
    "calculate_angular_velocity",
    "calculate_velocity",
    "filter_tracks",
    "smooth_tracks",
    "CircleRegionTask",
    "analyze_circle_trajectories",
    "plot_trajectory_segment",
    "KINEMATICS_COLUMNS",
    "ParticleKinematicsTask",
    "ParticleStatisticsTask",
    "filter_particles_by_statistics",
    "get_particle_indices",
    "filter_kinematics_by_statistics",
    "BacteriaTracker",
    "TrajectoryTrackingTask",
    "estimate_detection_params",
    "VideoInfoTask",
]
