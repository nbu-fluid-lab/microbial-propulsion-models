"""障碍物检测 **静态图** 服务入口：Request/Response + 默认识别器链（单帧）。"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Mapping

import cv2
from nltlog import getLogger

from funtrack.task.obstacle_detection.frame.result import ObstacleDetectionResult
from funtrack.task.obstacle_detection.service_support import default_obstacle_detection_chain
from funtrack.task.obstacle_detection.utils import ensure_no_extra_keys

logger = getLogger("funtrack")

_IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp")

_REQUEST_KEYS = {
    "image_path",
    "expected_marker_count",
    "marker_um",
    "scale_um_per_pixel",
    "circle_analysis_radius_um",
    "strict_expected_count",
    "debug",
    "debug_output_dir",
}
_RESPONSE_KEYS = {"ok", "result", "error"}


@dataclass(frozen=True, slots=True)
class ObstacleImageDetectionRequest:
    """静态图障碍物链外部入参；可与 JSON 完全互转。"""

    image_path: str
    expected_marker_count: int
    marker_um: float | None
    scale_um_per_pixel: float
    circle_analysis_radius_um: float | None
    strict_expected_count: bool
    debug: bool = False
    debug_output_dir: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "image_path": self.image_path,
            "expected_marker_count": int(self.expected_marker_count),
            "marker_um": self.marker_um,
            "scale_um_per_pixel": float(self.scale_um_per_pixel),
            "circle_analysis_radius_um": self.circle_analysis_radius_um,
            "strict_expected_count": bool(self.strict_expected_count),
            "debug": bool(self.debug),
            "debug_output_dir": self.debug_output_dir,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_dict(cls, d: Mapping[str, object]) -> ObstacleImageDetectionRequest:
        ensure_no_extra_keys(d, allowed=_REQUEST_KEYS, kind="ObstacleImageDetectionRequest")
        v = d.get("image_path")
        if not isinstance(v, str) or not v.strip():
            raise ValueError("image_path 须为非空字符串")
        p = Path(v.strip())
        if p.suffix.lower() not in _IMAGE_SUFFIXES:
            raise ValueError(f"image_path 须为支持的静态图后缀: {', '.join(_IMAGE_SUFFIXES)}")
        e = d.get("expected_marker_count")
        if e is None:
            raise ValueError("expected_marker_count 必填")
        em = d.get("marker_um")
        if em is not None and not isinstance(em, (int, float)):
            raise ValueError("marker_um 须为 number 或 null")
        s = d.get("scale_um_per_pixel")
        if s is None or not isinstance(s, (int, float)):
            raise ValueError("scale_um_per_pixel 须为 number")
        ar = d.get("circle_analysis_radius_um")
        if ar is not None and not isinstance(ar, (int, float)):
            raise ValueError("circle_analysis_radius_um 须为 number 或 null")
        st = d.get("strict_expected_count")
        if not isinstance(st, bool):
            raise ValueError("strict_expected_count 须为 bool")
        if not st:
            raise ValueError("已移除非严格模式，strict_expected_count 必须为 true")
        dbg = d.get("debug", False)
        if not isinstance(dbg, bool):
            raise ValueError("debug 须为 bool")
        dbg_dir = d.get("debug_output_dir")
        if dbg_dir is not None and not isinstance(dbg_dir, str):
            raise ValueError("debug_output_dir 须为 string 或 null")
        ec = int(e)
        if ec <= 0:
            raise ValueError("expected_marker_count 须为正整数")
        scale = float(s)
        if scale <= 0:
            raise ValueError("scale_um_per_pixel 须为正数")
        marker = float(em) if em is not None else None
        if marker is not None and marker <= 0:
            raise ValueError("marker_um 须为正数或 null")
        ar_v = float(ar) if ar is not None else None
        if ar_v is not None and ar_v <= 0:
            raise ValueError("circle_analysis_radius_um 须为正数或 null")
        return cls(
            image_path=v.strip(),
            expected_marker_count=ec,
            marker_um=marker,
            scale_um_per_pixel=scale,
            circle_analysis_radius_um=ar_v,
            strict_expected_count=bool(st),
            debug=bool(dbg),
            debug_output_dir=dbg_dir.strip() if isinstance(dbg_dir, str) else None,
        )

    @classmethod
    def from_json(cls, s: str) -> ObstacleImageDetectionRequest:
        return cls.from_dict(json.loads(s))


@dataclass(frozen=True, slots=True)
class ObstacleImageDetectionResponse:
    """静态图障碍物链的对外结果；无圆时 ``ok`` 为 False 且 ``result`` 为 ``None``。"""

    ok: bool
    result: dict[str, object] | None
    error: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "ok": self.ok,
            "result": self.result,
            "error": self.error,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_dict(cls, d: Mapping[str, object]) -> ObstacleImageDetectionResponse:
        ensure_no_extra_keys(d, allowed=_RESPONSE_KEYS, kind="ObstacleImageDetectionResponse")
        ok = d.get("ok")
        if not isinstance(ok, bool):
            raise ValueError("ok 须为 bool")
        r = d.get("result")
        if r is not None and not isinstance(r, dict):
            raise ValueError("result 须为 object 或 null")
        err = d.get("error")
        if err is not None and not isinstance(err, str):
            raise ValueError("error 须为 string 或 null")
        return cls(
            ok=ok,
            result=dict(r) if r is not None else None,
            error=err,
        )

    @classmethod
    def from_json(cls, s: str) -> ObstacleImageDetectionResponse:
        return cls.from_dict(json.loads(s))


def run_obstacle_image_detection_request(
    request: ObstacleImageDetectionRequest,
) -> ObstacleImageDetectionResponse:
    """读取静态图 BGR，经默认识别器链识别并返回 Response。"""
    if not bool(request.strict_expected_count):
        raise ValueError("已移除非严格模式，strict_expected_count 必须为 True")
    path = Path(request.image_path)
    if not path.is_file():
        return ObstacleImageDetectionResponse(ok=False, result=None, error="image_path_not_found")
    bgr = cv2.imread(str(path))
    if bgr is None:
        return ObstacleImageDetectionResponse(ok=False, result=None, error="image_read_failed")
    h, w = bgr.shape[:2]
    chain = default_obstacle_detection_chain(
        expected_marker_count=int(request.expected_marker_count),
        marker_um=request.marker_um,
        scale_um_per_pixel=float(request.scale_um_per_pixel),
        circle_analysis_radius_um=request.circle_analysis_radius_um,
        frame_width_px=int(w),
        frame_height_px=int(h),
    )
    debug_base_dir: Path | None = None
    if request.debug:
        if request.debug_output_dir is not None and str(request.debug_output_dir).strip():
            debug_base_dir = Path(request.debug_output_dir).expanduser().resolve()
        else:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            debug_base_dir = Path.cwd() / "output" / "obstacle_chain_debug" / f"{path.stem}_{ts}"
        debug_base_dir.mkdir(parents=True, exist_ok=True)
        logger.info("障碍物检测链调试图目录: {}", str(debug_base_dir))

    raw: ObstacleDetectionResult | None = chain.run_recognizers_on_bgr(
        bgr,
        frame_index=0,
        debug_base_dir=debug_base_dir,
    )
    if raw is None:
        chain.log_total_failure(str(path))
        return ObstacleImageDetectionResponse(
            ok=False, result=None, error="no_obstacle_circle_result"
        )
    return ObstacleImageDetectionResponse(
        ok=True,
        result=raw.to_dict(),
        error=None,
    )
