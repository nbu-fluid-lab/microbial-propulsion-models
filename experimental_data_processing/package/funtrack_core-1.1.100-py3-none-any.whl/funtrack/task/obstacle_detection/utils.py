"""obstacle_detection 纯通用工具（不依赖本目录其他模块）。"""

from __future__ import annotations

from typing import Mapping


def coerce_positive_int_or_none(value: object) -> int | None:
    """将任意值转为正整数；无效或 <=0 返回 ``None``。"""
    if value is None:
        return None
    try:
        n = int(value)
    except (TypeError, ValueError):
        return None
    return n if n > 0 else None


def ensure_no_extra_keys(d: Mapping[str, object], *, allowed: set[str], kind: str) -> None:
    """校验入参字典不含未知键。"""
    extra = sorted(str(k) for k in d.keys() if str(k) not in allowed)
    if extra:
        raise ValueError(f"{kind} 包含未定义字段: {extra}")


def to_jsonable_shallow_dict(d: Mapping[str, object]) -> dict[str, object]:
    """浅层 dict 规范化：保留 JSON 基本类型，其余转 ``repr``。"""
    out: dict[str, object] = {}
    for k, v in d.items():
        if isinstance(v, (str, int, float, bool)) or v is None:
            out[str(k)] = v
        else:
            out[str(k)] = repr(v)
    return out
