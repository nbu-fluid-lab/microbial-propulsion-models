"""障碍物单档检测器：参数包 + 单帧检测（实现位于 ``obstacle_detection``，供识别器链使用）。"""

from __future__ import annotations

import math
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from funtrack.task.obstacle_detection.frame.engine import ObstacleFrameDetectionEngine
    from funtrack.task.obstacle_detection.frame.fit import ObstacleFrameFitParams
    from funtrack.task.obstacle_detection.frame.hough import ObstacleFrameHoughParams

import numpy as np
from nltlog import getLogger

from funtrack.task.obstacle_detection.frame.result import ObstacleDetectionResult

logger = getLogger("funtrack")


class ObstacleCircleDetector:
    """
    **算法档位参数包** + **单档** 单帧调度：构造器收纳 Hough 半径带、期望小球/分析圆半径(px)、
    采样帧数、环形/三圆拟合阈值等；构造末组装不可变 ``ObstacleFrameDetectionEngine``（聚合
    ``frame_hough_params`` / ``frame_fit_params`` 与合并用标量），**帧内链只依赖引擎**，不直接
    依赖本类实例。

    **与链式识别器的关系**：``obstacle_detection.frame.recognizers.ObstacleRecognizer`` 子类在 **构造器**
    绑定业务标定（障碍物个数、小球/分析圆 μm、比例尺等），由 ``detector_kwargs`` 经
    ``frame_detection_engine_from_detector_kwargs`` 得到冻结引擎；``sample_frames`` 与 kwargs 同源并暴露在识别器上，
    供 ``ObstacleDetectionChain.run_video`` 取全链最大值。``recognize(bgr)`` 以图为入参、在基类做
    **输出校验**。``ObstacleDetectionChain`` 持有多档策略 **实例**，
    产品链对每帧依次 ``recognize`` 直至通过闸门——加档只需新子类 + 链节点。

    本类不承担视频抽帧/遍历；产品「视频 → 抽帧 → 每帧识别器链」编排见 ``orchestrator`` / ``service``；静态图见 ``image_service``。

    **几何模式**：环形（默认）；三圆共线（``expected_marker_count == 3``）；环形 2N+1 下的 CLAHE /
    放宽半径带 / 半径主峰预筛等。
    """

    def __init__(
        self,
        sample_frames: int = 10,
        hough_dp: float = 1.2,
        hough_min_dist: int = 12,
        hough_param1: int = 120,
        hough_param2: int = 10,
        hough_min_radius: int = 2,
        hough_max_radius: int = 30,
        marker_diameter_ratio_min: float = 0.05,
        marker_diameter_ratio_max: float = 0.10,
        use_height_ratio_radius_constraint: bool = True,
        inlier_ratio_tol: float = 0.20,
        min_inlier_pixels: float = 4.0,
        min_outer_markers: int = 4,
        expected_marker_radius_px: float | None = None,
        expected_analysis_radius_px: float | None = None,
        hough_max_radius_cap_px: float | None = None,
        analysis_radius_fit_tol: float = 0.28,
    ):
        self.sample_frames = int(max(1, sample_frames))
        self.hough_dp = float(hough_dp)
        self.hough_min_dist = int(max(1, hough_min_dist))
        self.hough_param1 = int(max(1, hough_param1))
        self.hough_param2 = int(max(1, hough_param2))
        self.hough_min_radius = int(max(0, hough_min_radius))
        self.hough_max_radius = int(max(self.hough_min_radius + 1, hough_max_radius))
        self.marker_diameter_ratio_min = float(max(0.001, marker_diameter_ratio_min))
        self.marker_diameter_ratio_max = float(
            max(self.marker_diameter_ratio_min, marker_diameter_ratio_max)
        )
        self.use_height_ratio_radius_constraint = bool(use_height_ratio_radius_constraint)
        self.inlier_ratio_tol = float(max(0.01, inlier_ratio_tol))
        self.min_inlier_pixels = float(max(1.0, min_inlier_pixels))
        self.min_outer_markers = int(max(3, min_outer_markers))
        self.expected_marker_radius_px = (
            float(expected_marker_radius_px)
            if expected_marker_radius_px is not None and float(expected_marker_radius_px) > 0
            else None
        )
        self.expected_analysis_radius_px = (
            float(expected_analysis_radius_px)
            if expected_analysis_radius_px is not None and float(expected_analysis_radius_px) > 0
            else None
        )
        self.hough_max_radius_cap_px = (
            float(hough_max_radius_cap_px)
            if hough_max_radius_cap_px is not None and float(hough_max_radius_cap_px) > 0
            else None
        )
        self.analysis_radius_fit_tol = float(max(0.05, analysis_radius_fit_tol))

        from funtrack.task.obstacle_detection.frame.engine import (
            ObstacleFrameDetectionEngine,
        )
        from funtrack.task.obstacle_detection.frame.fit import obstacle_frame_fit_params
        from funtrack.task.obstacle_detection.frame.hough import obstacle_frame_hough_params

        self._frame_fit_params = obstacle_frame_fit_params(
            expected_marker_radius_px=self.expected_marker_radius_px,
            expected_analysis_radius_px=self.expected_analysis_radius_px,
            analysis_radius_fit_tol=float(self.analysis_radius_fit_tol),
            min_outer_markers=int(self.min_outer_markers),
            min_inlier_pixels=float(self.min_inlier_pixels),
            inlier_ratio_tol=float(self.inlier_ratio_tol),
        )
        self._frame_hough_params = obstacle_frame_hough_params(
            use_height_ratio_radius_constraint=self.use_height_ratio_radius_constraint,
            marker_diameter_ratio_min=self.marker_diameter_ratio_min,
            marker_diameter_ratio_max=self.marker_diameter_ratio_max,
            hough_max_radius_cap_px=self.hough_max_radius_cap_px,
            hough_dp=self.hough_dp,
            hough_min_dist=self.hough_min_dist,
            hough_param1=self.hough_param1,
            hough_param2=self.hough_param2,
            hough_min_radius=self.hough_min_radius,
            hough_max_radius=self.hough_max_radius,
        )

        self._frame_detection_engine = ObstacleFrameDetectionEngine(
            hough_min_dist=self.hough_min_dist,
            hough_param2=self.hough_param2,
            min_outer_markers=self.min_outer_markers,
            expected_marker_radius_px=self.expected_marker_radius_px,
            expected_analysis_radius_px=self.expected_analysis_radius_px,
            frame_hough_params=self._frame_hough_params,
            frame_fit_params=self._frame_fit_params,
        )

    @property
    def frame_hough_params(self) -> ObstacleFrameHoughParams:
        """构造期固化的单帧 Hough 标量快照。"""
        return self._frame_hough_params

    @property
    def frame_fit_params(self) -> ObstacleFrameFitParams:
        """构造期固化的单帧拟合标量快照。"""
        return self._frame_fit_params

    @property
    def frame_detection_engine(self) -> ObstacleFrameDetectionEngine:
        """单帧几何管道唯一入口快照（供 ``frame_pipeline`` 使用）。"""
        return self._frame_detection_engine

    def detect_on_bgr(
        self,
        bgr: np.ndarray,
        frame_index: int = 0,
        expected_marker_count: Optional[int] = None,
        strict_expected_count: bool = True,
        *,
        debug_visualize_dir: str | Path | None = None,
    ) -> Optional[ObstacleDetectionResult]:
        """对单帧 BGR 图像做障碍物检测。"""
        from funtrack.task.obstacle_detection.frame.recognize import (
            recognize_frame,
        )

        return recognize_frame(
            self._frame_detection_engine,
            bgr,
            frame_index=int(frame_index),
            expected_marker_count=expected_marker_count,
            strict_expected_count=strict_expected_count,
            debug_visualize_dir=debug_visualize_dir,
        )

    def fit_from_circle_detections(
        self,
        circles: np.ndarray,
        frame_index: int,
        expected_marker_count: Optional[int] = None,
        strict_expected_count: bool = True,
        *,
        emit_fit_failure_diagnostic: bool = True,
        ignore_preset_analysis_radius: bool = False,
    ) -> Optional[ObstacleDetectionResult]:
        """由外部给出的等效 Hough 圆参数（每行 x, y, r 像素）拟合障碍物分析圆。

        用于 LLM 视觉兜底等路径：输入与 ``cv2.HoughCircles`` 输出格式一致。

        ``emit_fit_failure_diagnostic``：拟合失败时是否输出详细诊断（LLM 路径可能连续尝试两次，
        可第一次关、仅在最终失败时开一次，避免重复刷屏）。

        ``ignore_preset_analysis_radius``：为 True 时**暂不应用**由颗粒/圆形任务预设换算得到的
        ``expected_analysis_radius_px`` 校验（该约束用于约束传统 Hough 与物理直径一致；
        **大模型视觉兜底**应以图像上的圆点几何为准，避免因 μm 换算与视觉尺度不一致而误拒）。
        """
        if circles is None or len(circles) == 0:
            return None
        arr = np.asarray(circles, dtype=np.float32)
        if arr.ndim != 2 or arr.shape[1] < 3:
            return None
        expected_count: Optional[int] = None
        if expected_marker_count is not None:
            try:
                expected_count = int(expected_marker_count)
            except (TypeError, ValueError):
                expected_count = None
        if expected_count is not None and expected_count <= 0:
            expected_count = None
        from funtrack.task.obstacle_detection.frame import fit as frame_fit

        p = self.frame_fit_params
        if ignore_preset_analysis_radius:
            p = replace(p, expected_analysis_radius_px=None)
        res = frame_fit.fit_marker_candidate(
            arr,
            int(frame_index),
            expected_count,
            strict_expected_count,
            p,
        )
        if res is None and emit_fit_failure_diagnostic:
            self._log_fit_from_detections_failure(
                arr,
                expected_count=expected_count,
                strict_expected_count=strict_expected_count,
            )
        return res

    def _log_fit_from_detections_failure(
        self,
        arr: np.ndarray,
        *,
        expected_count: Optional[int],
        strict_expected_count: bool,
        extra_note: Optional[str] = None,
    ) -> None:
        """外部圆点（如 LLM）未能拟合为障碍物分析圆时的诊断日志。"""
        from funtrack.task.obstacle_detection.frame import fit as frame_fit

        rp = frame_fit.ring_pattern_expected(expected_count)
        rcol = arr[:, 2].astype(np.float64)
        lines = [
            "障碍物外部圆点拟合失败（帧内拟合无候选）。",
            "n_points={}, expected_total={}, strict={}, ring_pattern_expected={}".format(
                len(arr),
                expected_count,
                strict_expected_count,
                rp,
            ),
            "detector: expected_marker_radius_px={}, expected_analysis_radius_px={}, "
            "analysis_radius_fit_tol={}, min_outer_markers={}, "
            "inlier_ratio_tol={}".format(
                self.expected_marker_radius_px,
                self.expected_analysis_radius_px,
                self.analysis_radius_fit_tol,
                self.min_outer_markers,
                self.inlier_ratio_tol,
            ),
            "半径(px) min/med/max={:.4f}/{:.4f}/{:.4f}".format(
                float(np.min(rcol)),
                float(np.median(rcol)),
                float(np.max(rcol)),
            ),
            "circles (每行 x y r):\n{}".format(
                np.array2string(arr, precision=4, suppress_small=False, max_line_width=120)
            ),
        ]
        xy = arr[:, :2].astype(np.float64)
        cxy = np.mean(xy, axis=0)
        d = np.linalg.norm(xy - cxy, axis=1)
        lines.append(
            "粗几何: 点集形心=({:.4f},{:.4f}), 到形心距 min/med/max={:.4f}/{:.4f}/{:.4f}".format(
                float(cxy[0]),
                float(cxy[1]),
                float(np.min(d)),
                float(np.median(d)),
                float(np.max(d)),
            )
        )
        if rp and expected_count is not None and len(d) >= 3:
            outer_n = max(0, int(expected_count) - 1)
            if outer_n > 0:
                ideal_step = 2.0 * math.pi / float(outer_n)
                lines.append(
                    "环形提示: 周向期望约 {} 个外点, 理想相邻角间距≈{:.4f} rad；"
                    "若 LLM 点集不满足共圆/均匀或分析半径与颗粒预设偏差过大，拟合会拒绝。".format(
                        outer_n,
                        ideal_step,
                    )
                )
        if extra_note:
            lines.append(extra_note)
        logger.warning("\n".join(lines))


def frame_detection_engine_from_detector_kwargs(
    **kwargs: object,
) -> "ObstacleFrameDetectionEngine":
    """由与 ``ObstacleCircleDetector`` 构造器兼容的 kwargs 得到冻结的 ``ObstacleFrameDetectionEngine``。"""
    return ObstacleCircleDetector(**kwargs).frame_detection_engine
