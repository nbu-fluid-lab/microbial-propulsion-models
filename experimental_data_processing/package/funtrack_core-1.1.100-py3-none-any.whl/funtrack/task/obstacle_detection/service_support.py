"""障碍物检测对外服务（视频 / 静态图）共用的链构建。"""

from __future__ import annotations

from funtrack.task.obstacle_detection.orchestrator import ObstacleDetectionChain


def default_obstacle_detection_chain(
    *,
    expected_marker_count: int,
    marker_um: float | None,
    scale_um_per_pixel: float,
    circle_analysis_radius_um: float | None,
    frame_width_px: int | None,
    frame_height_px: int | None,
) -> ObstacleDetectionChain:
    """在已校验的标定与画幅下构造默认识别器链。"""
    return ObstacleDetectionChain.with_default_recognizers(
        expected_marker_count=int(expected_marker_count),
        marker_um=marker_um,
        scale_um_per_pixel=float(scale_um_per_pixel),
        circle_analysis_radius_um=circle_analysis_radius_um,
        strict_expected_count=True,
        frame_width_px=frame_width_px,
        frame_height_px=frame_height_px,
    )
