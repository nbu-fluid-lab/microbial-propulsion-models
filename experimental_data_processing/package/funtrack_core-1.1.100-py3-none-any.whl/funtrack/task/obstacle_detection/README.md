# obstacle_detection

障碍物固定圆识别子模块（`funtrack.task.obstacle_detection`），负责将视频/图片中的障碍物小圆集合
拟合为分析圆，输出 `ObstacleDetectionResult` 的字典结果，供后续 `circle` 任务自行转换。

该模块当前采用 **strict-only** 设计：只允许严格模式识别，不再支持 strict -> non-strict 回退。

---

## 1. 对外入口

推荐入口（结构化响应，便于系统集成）：

- `run_obstacle_video_detection_request(request) -> ObstacleVideoDetectionResponse`
  - 文件：`service.py`
  - 语义：返回 `ok/result/error`，适合 API 或脚本链路

---

## 2. 入参契约（Request）

`ObstacleVideoDetectionRequest` 字段：

- `video_path`：检测视频路径（必填，非空字符串）
- `expected_marker_count`：期望障碍物小圆总数（必填，正整数）
- `marker_um`：障碍物小球直径（um，可空）
- `scale_um_per_pixel`：比例尺（um/px，必填，正数）
- `circle_analysis_radius_um`：期望分析圆半径（um，可空）
- `strict_expected_count`：历史兼容字段，**必须为 `true`**
- `debug`：是否输出调试图（默认 `false`）
- `debug_output_dir`：调试输出目录（可空）

校验规则：

- 拒绝未定义字段
- 数值字段必须是正数（可空字段除外）
- `strict_expected_count=false` 直接抛错（strict-only）

---

## 3. 输出对象（Result）

`ObstacleDetectionResult` 关键字段：

- `center_x`, `center_y`：分析圆圆心（px）
- `radius`：分析圆半径（px）
- `frame_index`：命中采样帧
- `marker_count`：拟合使用的小圆个数
- `score`：候选几何得分
- `strict_mode_used`：是否在严格模式下得到（当前应为 `true`）
- `marker_points`：小圆点列表（`(x, y, r)`）
- `obstacle_marker_radius_px`：小圆半径摘要值

序列化能力：

- `to_dict()`
- `from_dict(...)`

---

## 4. 架构分层

```
obstacle_detection/
├── service.py                 # 【入口层】Request/Response DTO, 调用编排层
│
├── orchestrator.py            # 【编排层】视频抽帧 + 遍历识别器链
│   └── ObstacleDetectionChain
│       ├── run_video()                # 视频抽帧 + 遍历识别器
│       └── run_recognizers_on_bgr()   # 遍历识别器��组
│
├── frame/
│   ├── recognizers.py         # 【识别器接口】完整的单帧识别黑盒
│   │   └── ObstacleRecognizer (ABC)
│   │       ├── recognize()    # 入口：完整单帧识别
│   │       ├── _apply_output_gate()  # 输出校验（数量/半径/圆心）
│   │       └── Subclasses:
│   │           ├── PrimaryObstacleRecognizer        # 主档
│   │           ├── BinarizedPrimaryObstacleRecognizer # 主档+Otsu
│   │           ├── RelaxedHoughObstacleRecognizer   # 宽松Hough
│   │           ├── UltraRelaxedHoughObstacleRecognizer # 超宽松
│   │           └── TripletSmallScaleObstacleRecognizer # 三圆小比例尺
│   │
│   ├── recognize.py           # 【单帧识别入口】
│   │   └── recognize_frame()  # 函数
│   │       ├── run_obstacle_frame_detection()  # 帧内管道
│   │       └── check_circle_edge_completeness() # 边缘检查
│   │
│   ├── pipeline.py            # 【帧内处理管道】内部实现细节
│   │   └── DEFAULT_FRAME_DETECTION_TASKS
│   │       ├── CollectHoughTask      # Hough圆检测
│   │       ├── FilterAndConsensusTask # 过滤与共识
│   │       └── FitMarkerTask          # 圆拟合
│   │
│   ├── hough.py               # Hough圆检测实现
│   ├── fit.py                 # 圆拟合算法（三圆/环形）
│   └── edge_completeness.py   # 边缘完整性检查
│
├── output_validation.py       # 【输出校验】数量/半径/圆心位置
└── detector.py                # 【旧兼容层】单帧检测入口
```

### 调用流程

```
run_obstacle_video_detection_request()     # service.py
    │
    ▼
ObstacleDetectionChain.run_video()          # orchestrator.py
    │
    ▼ 遍历采样帧
for each frame:
    │
    ▼ 遍历识别器链
    for recognizer in recognizers:
        │
        ▼ 识别器是黑盒，内部完成:
        recognizer.recognize(bgr)            # recognizers.py
            │
            ▼ recognize_frame() 内部:
            1. Hough圆检测 (pipeline.py)
            2. 过滤与共识 (pipeline.py)
            3. 圆拟合 (fit.py)
            4. 边缘完整性检查 (edge_completeness.py)
            │
            ▼ _apply_output_gate() 校验:
            5. 数量/半径/圆心位置 (output_validation.py)
            │
            ▼ 返回结果或None
            返��� ObstacleDetectionResult 或 None
            │
            ▼ 校验通过则返回，失败则尝试下一识别器
            如果通过 → 返回结果
            如果失败 → 继续下一识别器
```

---

## 5. 识别器链

默认识别器顺序（按宽松程度递增）：

| 顺序 | 识别器 | 说明 |
|------|--------|------|
| 1 | `PrimaryObstacleRecognizer` | 主档，基于标定尺寸计算Hough半径范围 |
| 2 | `BinarizedPrimaryObstacleRecognizer` | 主档+Otsu二值化，尝试多个阈值偏移 |
| 3 | `RelaxedHoughObstacleRecognizer` | 宽松Hough，降低检测阈值 |
| 4 | `UltraRelaxedHoughObstacleRecognizer` | 超宽松Hough |
| 5 | `TripletSmallScaleObstacleRecognizer` | 三圆小比例尺定制 |

任一识别器成功即返回，全部失败则输出诊断日志。

---

## 6. 单帧识别内部流程

`recognize_frame()` 函数内部执行：

```
1. Hough圆检测 (CollectHoughTask)
   - 基础检测 + 放宽检测 → 合并
   - 三圆模式：CLAHE补检
   - 环形分级补检

2. 过滤 (FilterAndConsensusTask)
   - 半径过滤（基于标定的marker尺寸）
   - 环形共识预筛（候选过多时按半径主峰收紧）

3. 圆拟合 (FitMarkerTask)
   - 三圆模式：fit_three_collinear_equal_circles
   - 环形模式：fit_circle_from_markers (_RingFitter)
   - 计算几何分数、覆盖率、梯度���致性

4. 边缘完整性检查
   - 覆盖率：圆周上有有效边缘的采样点比例
   - 梯度一致性：边缘梯度方向与径向方向的一致程度

5. 输出校验 (validate_against_calibration)
   - 数量：|检出-期望| ≤ 1
   - 小球半径：±20%
   - 分析圆半径：±20%
   - 圆心位置：相对画幅中心各轴±10%
```

---

## 7. 失败诊断日志

检测全部失败时，输出入口参数：

```
障碍物检测链：全部识别器失败或无一通过输出校验。以下为完整入参，便于单独调试。

--- 入口入参 ---
video_path='xxx.mp4'
expected_marker_count=3
marker_diameter_um=15.0
scale_um_per_pixel=0.15
circle_analysis_radius_um=132.5
strict_expected_count=True
frame_width_px=1920
frame_height_px=1080
输出校验: 个数容差(±)=1；小球/分析圆半径±20%；圆心相对画幅中心各轴±10%

识别器链: ['primary', 'binarized_primary', 'relaxed_hough', 'ultra_relaxed_hough', 'triplet_small_scale']
```

---

## 8. strict-only 说明

- 不允许 non-strict 输入：
  - `ObstacleVideoDetectionRequest.from_dict(...)` 会拒绝 `strict_expected_count=false`
  - `run_obstacle_video_detection_request(...)` 会拒绝 `strict_expected_count=False`
  - `ObstacleRecognizer.__init__(...)` 会拒绝 `strict_expected_count=False`
- 不存在 strict 失败后自动重试 non-strict 的路径

---

## 9. Debug 图输出

启用方式：

- `request.debug = True`
- 可选 `request.debug_output_dir`

输出结构（示意）：

- `<debug_base>/f000123/primary/*.png`
- `<debug_base>/f000123/binarized_primary/otsu_*.png`
- `<debug_base>/f000123/relaxed_hough/*.png`
- `<debug_base>/f000123/ultra_relaxed_hough/*.png`

典型步骤图：

- source
- hough base / loose / merged
- filter 前后
- fit 结果
- FINAL best / no_result

---

## 10. 最小调用示例

```python
from funtrack.task.obstacle_detection import (
    ObstacleVideoDetectionRequest,
    run_obstacle_video_detection_request,
)

req = ObstacleVideoDetectionRequest(
    video_path="/data/obstacle.mp4",
    expected_marker_count=7,
    marker_um=5.0,
    scale_um_per_pixel=0.5,
    circle_analysis_radius_um=120.0,
    strict_expected_count=True,
    debug=False,
)

resp = run_obstacle_video_detection_request(req)
if (not resp.ok) or resp.result is None:
    print("no obstacle circle result")
else:
    print(resp.result["center_x"], resp.result["center_y"], resp.result["radius"])
```

---

## 11. 扩展识别器指引

新增识别器步骤：

1. 在 `frame/recognizers.py` 继承 `ObstacleRecognizer`
2. 实现 `name` 属性和 `detector_kwargs` 类方法
3. 仅调整 detector 参数，不改基类校验规则
4. 在 `orchestrator.py` 的 `with_default_recognizers(...)` 加入链路顺序
5. 增加对应测试

设计目标：

- 新识别器是"增量增强"，不破坏现有主干
- 保持统一输出闸门，避免各档行为漂移