"""障碍物检测结果在 BGR 帧上的叠绘（不依赖 ``circle`` 包）。"""

from __future__ import annotations

from typing import Protocol

import cv2
import numpy as np

# BGR
_COLOR_OBSTACLE = (0, 165, 255)
_COLOR_FIXED_CIRCLE = (0, 255, 255)
_COLOR_CENTER_DOT = (0, 255, 128)


class _ObstacleResultForDraw(Protocol):
    center_x: float
    center_y: float
    radius: float
    marker_points: list[tuple[float, float, float]]
    obstacle_marker_radius_px: float


def draw_obstacle_result_on_bgr(
    bgr: np.ndarray,
    result: _ObstacleResultForDraw,
) -> np.ndarray:
    """在 BGR 帧上绘制小圆与固定分析圆，返回新数组。"""
    vis = bgr.copy()
    mr = max(1.0, float(result.obstacle_marker_radius_px))
    thick_obs = max(1, min(4, int(round(mr * 0.25))))
    thick_ring = max(2, min(6, int(round(float(result.radius) * 0.02))))

    for i, pt in enumerate(result.marker_points):
        px, py = float(pt[0]), float(pt[1])
        pr = float(pt[2]) if len(pt) >= 3 else mr
        cx, cy = int(round(px)), int(round(py))
        r = int(round(max(1.0, pr)))
        color = _COLOR_CENTER_DOT if i == 0 else _COLOR_OBSTACLE
        cv2.circle(vis, (cx, cy), r, color, thick_obs, lineType=cv2.LINE_AA)

    fc_x = int(round(float(result.center_x)))
    fc_y = int(round(float(result.center_y)))
    fc_r = int(round(float(result.radius)))
    cv2.circle(vis, (fc_x, fc_y), fc_r, _COLOR_FIXED_CIRCLE, thick_ring, lineType=cv2.LINE_AA)
    return vis
