"""单帧障碍物 **Hough 小圆** 与合并/过滤/预筛（供 ``frame_pipeline`` 直接调用）。

- **工具类** :class:`ObstacleFrameHoughTool`：构造时接受 ``ObstacleFrameHoughParams``，对 **BGR / 灰度**
  图输出 ``(N,3)`` 的 ``float32`` 圆数据（每行 x, y, r，与 ``cv2.HoughCircles`` 一致）。
- 参数快照 ``ObstacleFrameHoughParams``（``obstacle_frame_hough_params`` 显式构造）；历史模块级
  函数名薄委托到工具类，保持兼容。拟合见 ``frame_fit``。
"""

from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass
from typing import Optional

import cv2
import numpy as np
from nltlog import getLogger

logger = getLogger("funtrack")


def triplet_enhance_gray(gray: np.ndarray) -> np.ndarray:
    """低对比度三圆：CLAHE + 高斯平滑，便于 Hough 看到柔和边缘。"""
    if gray.size == 0:
        return gray
    clahe = cv2.createCLAHE(clipLimit=3.2, tileGridSize=(8, 8))
    out = clahe.apply(gray)
    return cv2.GaussianBlur(out, (9, 9), 0)


@dataclass(frozen=True, slots=True)
class ObstacleFrameHoughParams:
    """单帧 Hough 用标量快照（由检测器构造字段显式填入）。"""

    use_height_ratio_radius_constraint: bool
    marker_diameter_ratio_min: float
    marker_diameter_ratio_max: float
    hough_max_radius_cap_px: float | None
    hough_dp: float
    hough_min_dist: int
    hough_param1: int
    hough_param2: int
    hough_min_radius: int
    hough_max_radius: int


def obstacle_frame_hough_params(
    *,
    use_height_ratio_radius_constraint: bool,
    marker_diameter_ratio_min: float,
    marker_diameter_ratio_max: float,
    hough_max_radius_cap_px: float | None,
    hough_dp: float,
    hough_min_dist: int,
    hough_param1: int,
    hough_param2: int,
    hough_min_radius: int,
    hough_max_radius: int,
) -> ObstacleFrameHoughParams:
    """由 **显式标量** 构造 Hough 参数快照。"""
    cap: float | None = None
    if hough_max_radius_cap_px is not None and float(hough_max_radius_cap_px) > 0:
        cap = float(hough_max_radius_cap_px)
    return ObstacleFrameHoughParams(
        use_height_ratio_radius_constraint=bool(use_height_ratio_radius_constraint),
        marker_diameter_ratio_min=float(marker_diameter_ratio_min),
        marker_diameter_ratio_max=float(marker_diameter_ratio_max),
        hough_max_radius_cap_px=cap,
        hough_dp=float(hough_dp),
        hough_min_dist=int(hough_min_dist),
        hough_param1=int(hough_param1),
        hough_param2=int(hough_param2),
        hough_min_radius=int(hough_min_radius),
        hough_max_radius=int(hough_max_radius),
    )


class ObstacleFrameHoughTool:
    """在固定 ``ObstacleFrameHoughParams`` 下，对 BGR/灰度图做 ``cv2.HoughCircles`` 小圆检测。"""

    __slots__ = ("_p",)

    def __init__(self, params: ObstacleFrameHoughParams) -> None:
        self._p = params

    @property
    def params(self) -> ObstacleFrameHoughParams:
        return self._p

    def detect_on_gray(
        self,
        gray: np.ndarray,
        param2_override: Optional[int] = None,
        *,
        triplet_soft_radius_band: bool = False,
        hough_param1_override: Optional[int] = None,
    ) -> Optional[np.ndarray]:
        """灰度单通道图 → ``(N,3)`` 圆（x, y, r）或 ``None``。"""
        p = self._p
        if p.use_height_ratio_radius_constraint:
            h = int(gray.shape[0])
            r_lo = float(p.marker_diameter_ratio_min)
            r_hi = float(p.marker_diameter_ratio_max)
            if triplet_soft_radius_band:
                r_lo = min(r_lo, 0.03)
                r_hi = max(r_hi, 0.12)
            min_r = int(round(h * r_lo * 0.5))
            max_r = int(round(h * r_hi * 0.5))
            min_r = max(1, min_r)
            max_r = max(min_r + 1, max_r)
        else:
            min_r = p.hough_min_radius
            max_r = p.hough_max_radius

        if p.hough_max_radius_cap_px is not None:
            cap_i = int(round(float(p.hough_max_radius_cap_px)))
            cap_i = max(min_r + 1, cap_i)
            max_r = min(max_r, cap_i)
            if max_r <= min_r:
                max_r = min_r + 1

        min_dist = max(p.hough_min_dist, int(round(min_r * 1.2)))

        p1 = (
            int(hough_param1_override) if hough_param1_override is not None else int(p.hough_param1)
        )
        p1 = max(1, p1)
        circles = cv2.HoughCircles(
            gray,
            cv2.HOUGH_GRADIENT,
            dp=p.hough_dp,
            minDist=min_dist,
            param1=p1,
            param2=int(param2_override) if param2_override is not None else p.hough_param2,
            minRadius=min_r,
            maxRadius=max_r,
        )
        if circles is None:
            return None
        return circles[0, :, :]

    def detect_on_bgr(
        self, frame: np.ndarray, param2_override: Optional[int] = None
    ) -> Optional[np.ndarray]:
        """BGR 图，内部灰度+median 模糊后 Hough；出参同 :meth:`detect_on_gray`。"""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.medianBlur(gray, 5)
        return self.detect_on_gray(gray, param2_override=param2_override)

    def detect_clahe_extra_on_bgr(
        self, frame: np.ndarray, param2_override: Optional[int] = None
    ) -> Optional[np.ndarray]:
        """三圆模式补检：CLAHE + 放宽半径带与 Canny 相关阈值。"""
        p = self._p
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        enh = triplet_enhance_gray(gray)
        p2e = param2_override if param2_override is not None else p.hough_param2
        p2e = max(5, int(p2e) - 1)
        return self.detect_on_gray(
            enh,
            param2_override=p2e,
            triplet_soft_radius_band=True,
            hough_param1_override=max(50, int(p.hough_param1) - 35),
        )

    def iter_ring_clahe_variants(
        self, gray: np.ndarray
    ) -> Iterator[tuple[str, Optional[np.ndarray]]]:
        """环形低对比度：逐级 CLAHE 变体，产出 (标签, 圆组)。"""
        p = self._p
        enh_std = triplet_enhance_gray(gray)
        yield (
            "ring_clahe_std_p2a",
            self.detect_on_gray(
                enh_std,
                param2_override=max(5, int(p.hough_param2) - 4),
                triplet_soft_radius_band=True,
                hough_param1_override=max(48, int(p.hough_param1) - 38),
            ),
        )
        yield (
            "ring_clahe_std_p2b",
            self.detect_on_gray(
                enh_std,
                param2_override=max(4, int(p.hough_param2) - 6),
                triplet_soft_radius_band=True,
                hough_param1_override=max(40, int(p.hough_param1) - 55),
            ),
        )
        clahe_up = cv2.createCLAHE(clipLimit=4.2, tileGridSize=(8, 8))
        enh_str = cv2.GaussianBlur(clahe_up.apply(gray), (11, 11), 0)
        yield (
            "ring_clahe_strong_p26",
            self.detect_on_gray(
                enh_str,
                param2_override=6,
                triplet_soft_radius_band=True,
                hough_param1_override=72,
            ),
        )
        yield (
            "ring_clahe_strong_p25",
            self.detect_on_gray(
                enh_str,
                param2_override=5,
                triplet_soft_radius_band=True,
                hough_param1_override=58,
            ),
        )


def merge_hough_circles(
    circles_a: Optional[np.ndarray],
    circles_b: Optional[np.ndarray],
    hough_min_dist: int,
) -> Optional[np.ndarray]:
    """合并两次检测结果并去重。"""
    if circles_a is None and circles_b is None:
        return None
    if circles_a is None:
        return circles_b
    if circles_b is None:
        return circles_a

    merged = [c for c in circles_a]
    min_dist = max(2.0, float(hough_min_dist) * 0.5)
    for cb in circles_b:
        if not any(np.hypot(cb[0] - ca[0], cb[1] - ca[1]) < min_dist for ca in merged):
            merged.append(cb)
    return np.array(merged, dtype=np.float32)


def maybe_filter_hough_circles(
    circles: np.ndarray,
    *,
    expected_marker_radius_px: float | None,
    need_min_count: int,
    verbose: bool = False,
) -> np.ndarray:
    """按预估小圆半径（像素）剔除 Hough 干扰圆；过滤后不足则保留原集合。"""
    ex = expected_marker_radius_px
    if ex is None or ex <= 0 or circles is None or len(circles) == 0:
        return circles
    lo = float(ex) * 0.85
    hi = float(ex) * 1.25
    rcol = circles[:, 2].astype(np.float64)
    mask = (rcol >= lo) & (rcol <= hi)
    filtered = circles[mask]
    if len(filtered) < need_min_count:
        logger.debug(
            f"障碍物小圆半径过滤后数量不足 ({len(filtered)}<{need_min_count})，保留原 Hough 集合"
        )
        return circles
    msg = (
        f"障碍物小圆半径过滤: {len(circles)} -> {len(filtered)} "
        f"(期望 r_px≈{ex:.2f}, 区间 [{lo:.2f}, {hi:.2f}])"
    )
    if verbose:
        logger.info(msg)
    else:
        logger.debug(msg)
    return filtered


def prefilter_hough_radius_consensus(
    circles: np.ndarray,
    *,
    expected_marker_count: Optional[int],
    ring_pattern_expected: bool,
    need_min_count: int,
) -> np.ndarray:
    """Hough 过多时按半径主峰收紧，保留与障碍物小圆尺度一致的候选。"""
    if (
        circles is None
        or len(circles) < 12
        or expected_marker_count is None
        or not ring_pattern_expected
    ):
        return circles
    r = circles[:, 2].astype(np.float64)
    med = float(np.median(r))
    if med < 1.0:
        return circles
    for factor in (0.28, 0.38, 0.52):
        tol = max(2.5, med * factor)
        m = np.abs(r - med) <= tol
        sub = circles[m]
        if len(sub) >= need_min_count:
            if len(sub) < len(circles):
                logger.info(
                    f"Hough 半径共识预筛: {len(circles)} -> {len(sub)} "
                    f"(median_r≈{med:.1f}, tol={tol:.1f})"
                )
            return sub
    return circles


def min_hough_for_obstacle(expected_count: int | None, min_outer_markers: int) -> int:
    """拟合所需的最少 Hough 圆个数（三圆共线模式只需 3 个）。"""
    if expected_count == 3:
        return 3
    return int(min_outer_markers) + 1


def loose_merge_threshold(expected_count: int | None, min_outer_markers: int) -> int:
    """基础 Hough 不足时是否触发「放宽再合并」的个数阈值。"""
    if expected_count is None:
        return int(min_outer_markers) + 1
    return max(
        min_hough_for_obstacle(expected_count, min_outer_markers),
        int(expected_count * 0.7),
    )
