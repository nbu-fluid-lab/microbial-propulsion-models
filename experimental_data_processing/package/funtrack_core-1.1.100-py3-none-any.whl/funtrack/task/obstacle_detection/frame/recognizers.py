"""障碍物检测链：各档识别器。

每个 ``ObstacleRecognizer`` 是一个完整的单帧障碍物识别器，内部包含：
1. 帧内检测管道 (Hough → 过滤 → 拟合)
2. 边缘完整性检查
3. 输出校验

识别器链按顺序尝试多个识别器，任一成功即返回。
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

import cv2
import numpy as np
from nltlog import getLogger

from funtrack.task.obstacle_detection.detector import (
    frame_detection_engine_from_detector_kwargs,
)
from funtrack.task.obstacle_detection.output_validation import ObstacleResultExpectationValidator
from funtrack.task.obstacle_detection.frame.result import ObstacleDetectionResult

from .engine import ObstacleFrameDetectionEngine
from .recognize import recognize_frame

logger = getLogger("funtrack")


class ObstacleRecognizer(ObstacleResultExpectationValidator, ABC):
    """障碍物识别器：链上 **一个完整节点**（独立检测器 + 单帧全管線 + 输出闸门）。"""

    __slots__ = (
        "_expected_marker_count",
        "_marker_um",
        "_scale_um_per_pixel",
        "_circle_analysis_radius_um",
        "_strict_expected_count",
        "_sample_frames",
        "_frame_engine",
        "_frame_width_px",
        "_frame_height_px",
        "_custom_marker_radius_tol",
        "_custom_analysis_radius_tol",
        "_custom_center_offset_frac",
    )

    def __init__(
        self,
        *,
        expected_marker_count: int,
        marker_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
        strict_expected_count: bool,
        frame_width_px: int | None = None,
        frame_height_px: int | None = None,
    ) -> None:
        self._expected_marker_count = int(expected_marker_count)
        self._marker_um = marker_um
        self._scale_um_per_pixel = float(scale_um_per_pixel)
        self._circle_analysis_radius_um = circle_analysis_radius_um
        if not bool(strict_expected_count):
            raise ValueError("已移除非严格模式，strict_expected_count 必须为 True")
        self._strict_expected_count = bool(strict_expected_count)
        self._frame_width_px = frame_width_px
        self._frame_height_px = frame_height_px
        self._custom_marker_radius_tol: float | None = None
        self._custom_analysis_radius_tol: float | None = None
        self._custom_center_offset_frac: float | None = None
        det_kw = self.__class__.detector_kwargs(
            marker_um=self._marker_um,
            scale_um_per_pixel=self._scale_um_per_pixel,
            circle_analysis_radius_um=self._circle_analysis_radius_um,
        )
        try:
            sf_raw = int(det_kw.get("sample_frames", 10))
        except (TypeError, ValueError):
            sf_raw = 10
        self._sample_frames = int(max(1, sf_raw))

        # 读取自定义容差参数并从det_kw中移除，避免传给检测器
        if "marker_radius_rel_tol" in det_kw:
            self._custom_marker_radius_tol = float(det_kw.pop("marker_radius_rel_tol"))
        if "analysis_radius_rel_tol" in det_kw:
            self._custom_analysis_radius_tol = float(det_kw.pop("analysis_radius_rel_tol"))
        if "analysis_radius_fit_tol" in det_kw:
            self._custom_analysis_radius_tol = float(det_kw.pop("analysis_radius_fit_tol"))
        if "center_offset_frac" in det_kw:
            self._custom_center_offset_frac = float(det_kw.pop("center_offset_frac"))

        self._frame_engine = frame_detection_engine_from_detector_kwargs(**det_kw)

    @property
    def sample_frames(self) -> int:
        """与 ``ObstacleCircleDetector`` 构造 kwargs 一致的采样帧数；供视频链 ``run_video`` 取全链最大值。"""
        return self._sample_frames

    @property
    @abstractmethod
    def name(self) -> str: ...

    @classmethod
    @abstractmethod
    def detector_kwargs(
        cls,
        *,
        marker_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
    ) -> dict[str, object]:
        """在业务标定下给出本档 **完整** ``ObstacleCircleDetector`` 构造参数字典。"""

    @property
    def frame_detection_engine(self) -> ObstacleFrameDetectionEngine:
        """本节点冻结的单帧几何引擎（与 ``frame_pipeline`` 入参一致）。"""
        return self._frame_engine

    def _apply_output_gate(
        self, raw: ObstacleDetectionResult | None
    ) -> ObstacleDetectionResult | None:
        if raw is None:
            return None
        v = self.validate_against_calibration(
            raw,
            expected_marker_count=self._expected_marker_count,
            marker_diameter_um=self._marker_um,
            scale_um_per_pixel=self._scale_um_per_pixel,
            circle_analysis_radius_um=self._circle_analysis_radius_um,
            frame_width_px=self._frame_width_px,
            frame_height_px=self._frame_height_px,
            marker_radius_rel_tol=self._custom_marker_radius_tol,
            analysis_radius_rel_tol=self._custom_analysis_radius_tol,
            frame_center_max_offset_frac=self._custom_center_offset_frac,
        )
        if v.ok:
            return raw
        logger.info(
            "障碍物检测链: 识别器「{}」有候选但未通过输出校验，继续下一识别器。原因: {}",
            self.name,
            v.reason,
        )
        return None

    def recognize(
        self,
        bgr: np.ndarray,
        *,
        frame_index: int = 0,
        debug_visualize_dir: str | None = None,
    ) -> ObstacleDetectionResult | None:
        """单帧 BGR：本节点经 **完整帧内管線**（``recognize_frame``）识别后再做输出校验。"""
        raw = recognize_frame(
            self._frame_engine,
            bgr,
            frame_index=int(frame_index),
            expected_marker_count=self._expected_marker_count,
            strict_expected_count=self._strict_expected_count,
            debug_visualize_dir=debug_visualize_dir,
        )
        return self._apply_output_gate(raw)


class PrimaryObstacleRecognizer(ObstacleRecognizer):
    @property
    def name(self) -> str:
        return "primary"

    @classmethod
    def detector_kwargs(
        cls,
        *,
        marker_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
    ) -> dict[str, object]:
        """按业务参数生成主档 ``ObstacleCircleDetector`` 构造参数（完整一档）。"""
        _ = cls
        scale = float(scale_um_per_pixel)
        kwargs: dict[str, object] = {}
        if marker_um is not None and float(marker_um) > 0 and scale > 0:
            m = float(marker_um)
            marker_diameter_px = m / scale
            marker_radius_px = marker_diameter_px * 0.5
            kwargs = {
                "use_height_ratio_radius_constraint": False,
                "hough_min_radius": max(1, int(round(marker_radius_px * 0.6))),
                "hough_max_radius": max(2, int(round(marker_radius_px * 1.4))),
            }
            hmin, hmax = kwargs["hough_min_radius"], kwargs["hough_max_radius"]
            logger.info(
                f"障碍物小圆直径按颗粒类型约束: diameter_um={m:.2f}, diameter_px={marker_diameter_px:.2f}, "
                f"radius_range_px=[{hmin},{hmax}]"
            )
        expected_marker_radius_px: float | None = None
        if marker_um is not None and float(marker_um) > 0 and scale > 0:
            expected_marker_radius_px = float(marker_um) / scale * 0.5
        expected_analysis_radius_px: float | None = None
        if circle_analysis_radius_um is not None and scale > 0:
            try:
                cru = float(circle_analysis_radius_um)
            except (TypeError, ValueError):
                cru = 0.0
            if cru > 0:
                expected_analysis_radius_px = cru / scale
        if expected_marker_radius_px is not None:
            kwargs["expected_marker_radius_px"] = expected_marker_radius_px
        if expected_analysis_radius_px is not None:
            kwargs["expected_analysis_radius_px"] = expected_analysis_radius_px
            cap = max(3.0, float(expected_analysis_radius_px) * 0.22)
            if expected_marker_radius_px is not None:
                cap = max(cap, float(expected_marker_radius_px) * 1.55)
            kwargs["hough_max_radius_cap_px"] = cap

        # 输出校验容差
        kwargs["marker_radius_rel_tol"] = 0.30
        kwargs["analysis_radius_rel_tol"] = 0.35
        kwargs["center_offset_frac"] = 0.15

        return kwargs


class BinarizedPrimaryObstacleRecognizer(ObstacleRecognizer):
    """主档参数：单帧 **Otsu 二值化 + 形态学开运算** 预处理后再走完整帧内管線。

    单次 ``recognize`` 内按 ``_otsu_offset_try_sequence()`` 依次尝试多个相对 Otsu 的灰度阈值偏移
    （先 ``otsu_threshold_offset``，再 ``binarized_otsu_offset_candidates`` 中未出现过的值），
    首个通过输出校验的结果即返回。偏移为正阈值更高（更严），为负则更低（更松）。
    """

    #: 优先尝试的相对 Otsu 阈值偏移；亦会并入候选序列首位（与候选去重）。
    otsu_threshold_offset: int = -6
    #: 在单次识别中追加尝试的偏移列表（不含与 ``otsu_threshold_offset`` 重复的值）。
    binarized_otsu_offset_candidates: tuple[int, ...] = (-12, -4, -18)

    @property
    def name(self) -> str:
        return "binarized_primary"

    @classmethod
    def detector_kwargs(
        cls,
        *,
        marker_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
    ) -> dict[str, object]:
        _ = cls
        m = dict(
            PrimaryObstacleRecognizer.detector_kwargs(
                marker_um=marker_um,
                scale_um_per_pixel=scale_um_per_pixel,
                circle_analysis_radius_um=circle_analysis_radius_um,
            )
        )
        # 输出校验容差
        m["marker_radius_rel_tol"] = 0.30
        m["analysis_radius_rel_tol"] = 0.35
        m["center_offset_frac"] = 0.15
        return m

    @classmethod
    def _otsu_offset_try_sequence(cls) -> tuple[int, ...]:
        seen: set[int] = set()
        out: list[int] = []
        for d in (int(cls.otsu_threshold_offset), *cls.binarized_otsu_offset_candidates):
            di = int(d)
            if di not in seen:
                seen.add(di)
                out.append(di)
        return tuple(out)

    @classmethod
    def _binarized_bgr(cls, bgr: np.ndarray, *, otsu_offset: int | None = None) -> np.ndarray:
        """灰度 + Otsu 偏移二值化 + 自适应形态学去噪，再拼回 BGR。"""
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        otsu_t, _ = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        try:
            base = float(otsu_t)
        except (TypeError, ValueError):
            base = 127.0
        off = float(cls.otsu_threshold_offset if otsu_offset is None else int(otsu_offset))
        t = int(round(base + off))
        t = max(1, min(254, t))
        _, mask = cv2.threshold(blur, t, 255, cv2.THRESH_BINARY)
        # 偏松阈值（负偏移）更易引入散点：增加开+闭抑制杂点并填补小孔洞。
        if off <= -6:
            k3 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k3)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k3)
        else:
            k2 = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k2)
        return cv2.merge([mask, mask, mask])

    def recognize(
        self,
        bgr: np.ndarray,
        *,
        frame_index: int = 0,
        debug_visualize_dir: str | None = None,
    ) -> ObstacleDetectionResult | None:
        seq = type(self)._otsu_offset_try_sequence()
        n = len(seq)
        for i, delta in enumerate(seq):
            last = i == n - 1
            proc = type(self)._binarized_bgr(bgr, otsu_offset=delta)
            dbg: str | None = None
            if debug_visualize_dir is not None:
                dbg = str(Path(debug_visualize_dir) / f"otsu_{delta:+d}")
            raw = recognize_frame(
                self._frame_engine,
                proc,
                frame_index=int(frame_index),
                expected_marker_count=self._expected_marker_count,
                strict_expected_count=self._strict_expected_count,
                debug_visualize_dir=dbg,
                quiet=not last,
            )
            gated = self._apply_output_gate(raw)
            if gated is not None:
                if n > 1:
                    logger.info(
                        "障碍物检测链: 二值化档 otsu_delta={} 通过输出校验（第 {}/{} 次阈值尝试）",
                        delta,
                        i + 1,
                        n,
                    )
                return gated
        return None


class RelaxedHoughObstacleRecognizer(ObstacleRecognizer):
    """宽松 Hough 档（完整独立识别体）。"""

    @property
    def name(self) -> str:
        return "relaxed_hough"

    @classmethod
    def detector_kwargs(
        cls,
        *,
        marker_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
    ) -> dict[str, object]:
        _ = cls
        m = dict(
            PrimaryObstacleRecognizer.detector_kwargs(
                marker_um=marker_um,
                scale_um_per_pixel=scale_um_per_pixel,
                circle_analysis_radius_um=circle_analysis_radius_um,
            )
        )
        m["sample_frames"] = max(int(m.get("sample_frames", 10)) + 8, 18)
        m["sample_frames"] = min(24, int(m["sample_frames"]))
        m["hough_dp"] = 1.0
        m["hough_min_dist"] = 6
        m["hough_param1"] = 100
        m["hough_param2"] = 6
        m["inlier_ratio_tol"] = 0.35
        m["min_inlier_pixels"] = 2.5
        m["analysis_radius_fit_tol"] = 0.45
        m["marker_diameter_ratio_min"] = 0.035
        m["marker_diameter_ratio_max"] = 0.14
        if "hough_min_radius" in m and "hough_max_radius" in m:
            rmin, rmax = int(m["hough_min_radius"]), int(m["hough_max_radius"])
            m["hough_min_radius"] = max(1, int(round(rmin * 0.7)))
            m["hough_max_radius"] = max(int(m["hough_min_radius"]) + 1, int(round(rmax * 1.4)))
        cap = m.get("hough_max_radius_cap_px")
        if cap is not None:
            try:
                c = float(cap)
                if c > 0:
                    m["hough_max_radius_cap_px"] = c * 1.25
            except (TypeError, ValueError):
                pass
        m.pop("expected_analysis_radius_px", None)

        # 输出校验容差
        m["marker_radius_rel_tol"] = 0.35
        m["analysis_radius_rel_tol"] = 0.40
        m["center_offset_frac"] = 0.15

        return m


class UltraRelaxedHoughObstacleRecognizer(ObstacleRecognizer):
    """超宽松 Hough 档（完整独立识别体）。"""

    @property
    def name(self) -> str:
        return "ultra_relaxed_hough"

    @classmethod
    def detector_kwargs(
        cls,
        *,
        marker_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
    ) -> dict[str, object]:
        _ = cls
        m = dict(
            RelaxedHoughObstacleRecognizer.detector_kwargs(
                marker_um=marker_um,
                scale_um_per_pixel=scale_um_per_pixel,
                circle_analysis_radius_um=circle_analysis_radius_um,
            )
        )
        m["sample_frames"] = 24
        p2 = int(m.get("hough_param2", 6))
        m["hough_param2"] = max(4, p2 - 1)
        md = int(m.get("hough_min_dist", 6))
        m["hough_min_dist"] = max(4, md - 1)
        m["inlier_ratio_tol"] = min(0.42, float(m.get("inlier_ratio_tol", 0.35)) + 0.05)
        if "hough_min_radius" in m and "hough_max_radius" in m:
            rmin, rmax = int(m["hough_min_radius"]), int(m["hough_max_radius"])
            m["hough_min_radius"] = max(1, rmin - 1)
            m["hough_max_radius"] = max(int(m["hough_min_radius"]) + 1, rmax + 3)

        # 输出校验容差
        m["marker_radius_rel_tol"] = 0.40
        m["analysis_radius_rel_tol"] = 0.45
        m["center_offset_frac"] = 0.15

        return m


class TripletSmallScaleObstacleRecognizer(ObstacleRecognizer):
    """三障碍物小比例尺场景的定制补充识别器（完整独立识别体）。"""

    @property
    def name(self) -> str:
        return "triplet_small_scale"

    @classmethod
    def detector_kwargs(
        cls,
        *,
        marker_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
    ) -> dict[str, object]:
        _ = cls
        m = dict(
            UltraRelaxedHoughObstacleRecognizer.detector_kwargs(
                marker_um=marker_um,
                scale_um_per_pixel=scale_um_per_pixel,
                circle_analysis_radius_um=circle_analysis_radius_um,
            )
        )
        m["sample_frames"] = 30
        m["hough_dp"] = 1.0
        m["hough_min_dist"] = 10
        m["hough_param1"] = 80
        m["hough_param2"] = 4
        m["inlier_ratio_tol"] = 0.5
        m["min_inlier_pixels"] = 2.0
        m["analysis_radius_fit_tol"] = 0.6
        m["marker_diameter_ratio_min"] = 0.02
        m["marker_diameter_ratio_max"] = 0.20
        if "hough_min_radius" in m and "hough_max_radius" in m:
            rmin, rmax = int(m["hough_min_radius"]), int(m["hough_max_radius"])
            m["hough_min_radius"] = max(1, int(round(rmin * 0.6)))
            m["hough_max_radius"] = max(int(m["hough_min_radius"]) + 1, int(round(rmax * 1.6)))
        exp_r = m.get("expected_marker_radius_px")
        if isinstance(exp_r, (int, float)) and float(exp_r) > 0:
            m["hough_min_radius"] = max(1, int(round(float(exp_r) * 0.45)))
            m["hough_max_radius"] = max(
                int(m["hough_min_radius"]) + 1,
                int(round(float(exp_r) * 2.2)),
            )

        # 移除过严的分析圆半径限制，允许更大的范围
        m.pop("expected_analysis_radius_px", None)

        # 输出校验容差
        m["marker_radius_rel_tol"] = 0.45
        m["analysis_radius_rel_tol"] = 0.50
        m["center_offset_frac"] = 0.15

        return m
