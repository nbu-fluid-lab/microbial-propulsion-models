"""单帧障碍物 **拟合**（三圆共线 / 环形）：纯帧内几何，与视频抽帧无关。

帧内链与 ``ObstacleCircleDetector.fit_from_circle_detections`` 等路径直接调用本模块的
``fit_marker_candidate`` / ``fit_*``；参数为构造期固化的 ``ObstacleFrameFitParams``（见
``obstacle_frame_fit_params``）。

边缘完整性检查也集成在本模块中（作为拟合后校验的一部分）。
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from itertools import combinations
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from nltlog import getLogger

from funtrack.task.obstacle_detection.frame.result import ObstacleDetectionResult
from funtrack.task.obstacle_detection.frame.edge_completeness import (
    EdgeCompletenessParams,
    DEFAULT_EDGE_COMPLETENESS_PARAMS,
    check_circle_edge_completeness,
)

logger = getLogger("funtrack")
ENABLE_EDGE_COMPLETENESS_CHECK = False


def ring_pattern_expected(expected_count: Optional[int]) -> bool:
    """是否为环形 2N+1 期望（中心 1 + 周向 2N），即总数 ≥5 且非三圆模式。"""
    if expected_count is None:
        return False
    try:
        n = int(expected_count)
    except (TypeError, ValueError):
        return False
    return n >= 5


@dataclass(frozen=True, slots=True)
class ObstacleFrameFitParams:
    """单帧拟合用标量：小球/分析圆期望半径(px)、个数相关阈值等（由检测器构造字段显式填入）。"""

    expected_marker_radius_px: float | None
    expected_analysis_radius_px: float | None
    analysis_radius_fit_tol: float
    min_outer_markers: int
    min_inlier_pixels: float
    inlier_ratio_tol: float


def obstacle_frame_fit_params(
    *,
    expected_marker_radius_px: float | None,
    expected_analysis_radius_px: float | None,
    analysis_radius_fit_tol: float,
    min_outer_markers: int,
    min_inlier_pixels: float,
    inlier_ratio_tol: float,
) -> ObstacleFrameFitParams:
    """由 **显式标量** 构造拟合参数快照（不在识别热路径上对任意对象做属性反射）。"""
    return ObstacleFrameFitParams(
        expected_marker_radius_px=expected_marker_radius_px,
        expected_analysis_radius_px=expected_analysis_radius_px,
        analysis_radius_fit_tol=float(analysis_radius_fit_tol),
        min_outer_markers=int(min_outer_markers),
        min_inlier_pixels=float(min_inlier_pixels),
        inlier_ratio_tol=float(inlier_ratio_tol),
    )


def fit_marker_candidate(
    circles: np.ndarray,
    frame_index: int,
    expected_count: Optional[int],
    strict_expected_count: bool,
    p: ObstacleFrameFitParams,
    bgr: np.ndarray | None = None,
    edge_params: EdgeCompletenessParams | None = None,
    debug_dir: Path | None = None,
) -> Optional[ObstacleDetectionResult]:
    """拟合障碍物圆。

    Args:
        circles: Hough检测到的候选圆 (N, 3) - x, y, r
        frame_index: 帧索引
        expected_count: 期望的障碍物数量
        strict_expected_count: 是否严格模式
        p: 拟合参数
        bgr: BGR图像（可选，用于边缘完整性检查）
        edge_params: 边缘完整性检查参数

    Returns:
        拟合结果或None
    """
    if expected_count == 3:
        result = fit_three_collinear_equal_circles(
            circles,
            frame_index,
            strict_expected_count=strict_expected_count,
            p=p,
        )
    else:
        result = fit_circle_from_markers(
            circles,
            frame_index,
            p,
            expected_marker_count=expected_count,
            strict_expected_count=strict_expected_count,
            verbose=debug_dir is not None,
        )

    # 边缘完整性检查（临时可关闭）
    if result is not None and bgr is not None and ENABLE_EDGE_COMPLETENESS_CHECK:
        edge_params = edge_params or DEFAULT_EDGE_COMPLETENESS_PARAMS
        edge_check = check_circle_edge_completeness(bgr, result, edge_params)
        if not edge_check.passed:
            logger.info(f"帧 {frame_index}: 边缘完整性检查未通过, 过滤该候选: {edge_check.reason}")
            return None
        logger.debug(
            f"帧 {frame_index}: 边缘完整性检查通过 coverage={edge_check.coverage_ratio:.2f}"
        )

    return result


@dataclass(frozen=True, slots=True)
class _ThreeCollinearFitRequest:
    circles: np.ndarray
    frame_index: int
    strict_expected_count: bool
    p: ObstacleFrameFitParams


class _ThreeCollinearFitter:
    """三圆共线拟合器：封装候选筛选、打分、后验校验。"""

    def __init__(self, req: _ThreeCollinearFitRequest) -> None:
        """以单帧请求初始化拟合器，不修改输入数据。"""
        self._req = req

    def _select_candidate_indices(self) -> np.ndarray:
        """按半径统计和期望半径筛出三圆候选索引。"""
        circles = self._req.circles
        strict_expected_count = self._req.strict_expected_count
        p = self._req.p
        radii = circles[:, 2].astype(np.float64)
        r_med = float(np.median(radii))
        if r_med < 1e-3:
            return np.array([], dtype=np.int64)
        r_tol = 0.22 if strict_expected_count else 0.32
        mask_r = np.abs(radii - r_med) <= max(1.5, r_tol * r_med)
        inds = np.where(mask_r)[0]
        if len(inds) < 3:
            mask_r = np.abs(radii - r_med) <= max(2.5, 0.45 * r_med)
            inds = np.where(mask_r)[0]
        if len(inds) < 3:
            inds = np.arange(len(circles), dtype=np.int64)
        ex_r = p.expected_marker_radius_px
        if ex_r is not None and float(ex_r) > 0:
            ex_r_f = float(ex_r)
            mask_ex = np.abs(radii - ex_r_f) <= max(3.0, 0.45 * ex_r_f)
            inds_ex = np.where(mask_ex)[0]
            if len(inds_ex) >= 3:
                if len(inds_ex) > 48:
                    inds = inds_ex[np.argsort(np.abs(radii[inds_ex] - ex_r_f))[:48]]
                else:
                    inds = inds_ex
        if len(inds) > 48:
            inds = inds[np.argsort(np.abs(radii[inds] - np.median(radii[inds])))[:36]]
        return inds.astype(np.int64, copy=False)

    def _score_triplet(self, tri: np.ndarray) -> float | None:
        """按半径一致性、共线性和覆盖几何对三元组打分。"""
        strict_expected_count = self._req.strict_expected_count
        p0, p1, p2 = tri[0, :2], tri[1, :2], tri[2, :2]
        t0, t1, t2 = float(tri[0, 2]), float(tri[1, 2]), float(tri[2, 2])
        r_mean = (t0 + t1 + t2) / 3.0
        r_spread = float(np.std([t0, t1, t2]) / (r_mean + 1e-6))
        if strict_expected_count:
            if r_spread > 0.20:
                return None
        elif r_spread > 0.38:
            return None
        v = p2 - p0
        span_len = float(np.linalg.norm(v))
        if span_len < max(6.0, 4.0 * r_mean):
            return None
        cross = float((p1[0] - p0[0]) * (p2[1] - p0[1]) - (p1[1] - p0[1]) * (p2[0] - p0[0]))
        d_line = abs(cross) / (span_len + 1e-6)
        col_err = d_line / (span_len + 1e-6)
        if strict_expected_count:
            if col_err > 0.055:
                return None
        elif col_err > 0.14:
            return None
        d01 = float(np.linalg.norm(p1 - p0))
        d12 = float(np.linalg.norm(p2 - p1))
        sp = abs(d01 - d12) / (d01 + d12 + 1e-6)
        x_spread = float(np.std(tri[:, 0]) / (span_len + 1e-6))
        x_rng = float(np.max(tri[:, 0]) - np.min(tri[:, 0]))
        y_rng = float(np.max(tri[:, 1]) - np.min(tri[:, 1]))
        vertical_ok = x_rng <= max(10.0, 0.17 * span_len + 6.0)
        horizontal_ok = y_rng <= max(10.0, 0.17 * span_len + 6.0)
        if strict_expected_count:
            if not vertical_ok and not horizontal_ok:
                return None
        elif not vertical_ok and not horizontal_ok:
            if x_rng + y_rng > max(18.0, 0.28 * span_len):
                return None
        mr_max = float(np.max([t0, t1, t2]))
        center_xy_try = np.mean(tri[:, :2], axis=0)
        analysis_try = max(
            float(np.linalg.norm(tri[i, :2] - center_xy_try) + tri[i, 2]) for i in range(3)
        )
        r_cap = span_len * 0.62 + mr_max * 2.5
        if analysis_try > r_cap + 15.0:
            return None
        tri_span_cx = (float(np.min(tri[:, 0])) + float(np.max(tri[:, 0]))) * 0.5
        tri_span_cy = (float(np.min(tri[:, 1])) + float(np.max(tri[:, 1]))) * 0.5
        span = max(1.0, span_len)
        cx_norm_off = abs(float(center_xy_try[0]) - tri_span_cx) / span
        cy_norm_off = abs(float(center_xy_try[1]) - tri_span_cy) / span
        center_penalty = 8.0 * (cx_norm_off + cy_norm_off)
        return (
            12.0
            - 95.0 * col_err
            - 28.0 * r_spread
            - 6.0 * sp
            - 4.0 * x_spread
            - center_penalty
            + (2.0 if vertical_ok else 0.0)
            + (2.0 if horizontal_ok else 0.0)
        )

    def _find_best_triplet(self) -> tuple[np.ndarray, float] | None:
        """遍历候选三元组并返回最高分结果。"""
        inds = self._select_candidate_indices()
        if len(inds) < 3:
            return None
        best_score = float("-inf")
        best_tri: np.ndarray | None = None
        for ia, ib, ic in combinations(inds.tolist(), 3):
            tri = self._req.circles[[ia, ib, ic]].astype(np.float64)
            tri = tri[np.argsort(tri[:, 1])]
            score = self._score_triplet(tri)
            if score is None:
                continue
            if score > best_score:
                best_score = score
                best_tri = tri.copy()
        if best_tri is None:
            return None
        return best_tri, best_score

    def _postcheck_center(self, best_tri: np.ndarray, mr: float) -> bool:
        """检查形心是否过度偏离三点跨度中心。"""
        if mr <= 0:
            return True
        center_xy = np.mean(best_tri[:, :2], axis=0)
        tri_cx = float(center_xy[0])
        tri_cy = float(center_xy[1])
        tri_span_cx = (float(np.min(best_tri[:, 0])) + float(np.max(best_tri[:, 0]))) * 0.5
        tri_span_cy = (float(np.min(best_tri[:, 1])) + float(np.max(best_tri[:, 1]))) * 0.5
        cx_off = abs(tri_cx - tri_span_cx)
        cy_off = abs(tri_cy - tri_span_cy)
        if cx_off > mr * 2.5 or cy_off > mr * 2.5:
            logger.debug(
                f"三圆模式: 拟合中心偏出三点跨度中心 "
                f"(cx_off={cx_off:.1f}, cy_off={cy_off:.1f}, mr={mr:.1f})"
            )
            return False
        return True

    def postcheck_center(self, best_tri: np.ndarray, mr: float) -> bool:
        """对外暴露三圆形心后验检查。"""
        return self._postcheck_center(best_tri, mr)

    def fit(self) -> tuple[np.ndarray, float] | None:
        """执行三圆拟合，返回最佳三元组与分数。"""
        return self._find_best_triplet()


def fit_three_collinear_equal_circles(
    circles: np.ndarray,
    frame_index: int,
    *,
    strict_expected_count: bool,
    p: ObstacleFrameFitParams,
) -> Optional[ObstacleDetectionResult]:
    """
    三个半径相近、近似共线的标准圆（按 y 自上而下排序写入 marker_points）。
    分析圆：取三圆心形心为圆心，半径为到三圆边界的最大距离。
    """
    if circles is None or len(circles) < 3:
        return None

    req = _ThreeCollinearFitRequest(
        circles=circles,
        frame_index=frame_index,
        strict_expected_count=strict_expected_count,
        p=p,
    )
    fitter = _ThreeCollinearFitter(req)
    best = fitter.fit()
    if best is None:
        logger.debug("三圆共线模式: 未找到满足几何约束的三元组")
        return None

    best_tri, best_score = best
    center_xy = np.mean(best_tri[:, :2], axis=0)
    mr = float(np.median(best_tri[:, 2]))
    analysis_r = max(
        float(np.linalg.norm(best_tri[i, :2] - center_xy) + best_tri[i, 2]) for i in range(3)
    )

    if not fitter.postcheck_center(best_tri, mr):
        return None

    if (
        p.expected_analysis_radius_px is not None
        and p.expected_analysis_radius_px > 0
        and p.expected_marker_radius_px is not None
        and p.expected_marker_radius_px > 0
    ):
        r_exp = float(p.expected_analysis_radius_px)
        tol = p.analysis_radius_fit_tol
        lo, hi = r_exp * (1.0 - tol), r_exp * (1.0 + tol)
        if analysis_r < lo or analysis_r > hi:
            logger.debug(
                f"三圆模式: 分析圆半径与预设偏差过大: fitted={analysis_r:.2f} px, 期望≈{r_exp:.2f} px"
            )
            return None

    marker_points: list[tuple[float, float, float]] = [
        (float(best_tri[i, 0]), float(best_tri[i, 1]), float(best_tri[i, 2])) for i in range(3)
    ]
    return ObstacleDetectionResult(
        center_x=float(center_xy[0]),
        center_y=float(center_xy[1]),
        radius=float(analysis_r),
        frame_index=int(frame_index),
        marker_count=3,
        score=float(best_score),
        strict_mode_used=bool(strict_expected_count),
        marker_points=marker_points,
        obstacle_marker_radius_px=mr,
    )


class _RingFitter:
    """环形拟合器：封装多中心搜索与单中心环拟合评分。"""

    def __init__(
        self,
        circles: np.ndarray,
        frame_index: int,
        p: ObstacleFrameFitParams,
        *,
        expected_total: int | None,
        strict_expected_count: bool,
        verbose: bool,
    ) -> None:
        """以单帧圆检测结果初始化环形拟合上下文。"""
        self._circles = circles
        self._frame_index = int(frame_index)
        self._p = p
        self._expected_total = expected_total
        self._strict_expected_count = strict_expected_count
        self._verbose = bool(verbose)

    def fit_one_center(
        self,
        *,
        center_idx: int,
        min_required_outer: int,
    ) -> ObstacleDetectionResult | None:
        result, _ = self._fit_one_center_with_reason(
            center_idx=center_idx,
            min_required_outer=min_required_outer,
        )
        return result

    def _fit_one_center_with_reason(
        self,
        *,
        center_idx: int,
        min_required_outer: int,
    ) -> tuple[ObstacleDetectionResult | None, str | None]:
        """在指定中心索引下执行一次环形拟合并返回结果。"""
        circles = self._circles
        p = self._p
        expected_total = self._expected_total
        strict_expected_count = self._strict_expected_count
        points = circles[:, :2]
        center = points[int(center_idx)]

        dists_all = np.linalg.norm(points - center, axis=1)
        outer_mask = dists_all > 1e-6
        outer_points = points[outer_mask]
        dists = dists_all[outer_mask]
        if len(dists) < min_required_outer:
            return None, "outer_points_insufficient"

        d_sorted = np.sort(dists)
        expected_outer = (expected_total - 1) if expected_total is not None else None
        window = (
            min(len(d_sorted), max(min_required_outer, expected_outer))
            if expected_outer is not None
            else max(min_required_outer, int(round(len(d_sorted) * 0.6)))
        )
        window = int(max(3, min(len(d_sorted), window)))
        if len(d_sorted) <= window:
            cluster = d_sorted
        else:
            best_start = 0
            best_range = float("inf")
            for s in range(0, len(d_sorted) - window + 1):
                seg = d_sorted[s : s + window]
                seg_range = float(seg[-1] - seg[0])
                if seg_range < best_range:
                    best_range = seg_range
                    best_start = s
            cluster = d_sorted[best_start : best_start + window]

        ring_r = float(np.median(cluster))
        cluster_spread = float(np.max(cluster) - np.min(cluster)) if len(cluster) > 1 else 0.0
        if expected_total is not None:
            tol = max(p.min_inlier_pixels, cluster_spread * 1.5, 3.0)
        else:
            tol = max(
                p.min_inlier_pixels,
                ring_r * p.inlier_ratio_tol,
                cluster_spread * 0.6,
            )

        inliers = np.abs(dists - ring_r) <= tol
        inlier_count = int(np.sum(inliers))
        if inlier_count < min_required_outer:
            return None, "inlier_count_insufficient"

        if (
            expected_outer is not None
            and ring_pattern_expected(expected_total)
            and inlier_count > expected_outer
        ):
            inds = np.flatnonzero(inliers)
            errs = np.abs(dists[inds] - ring_r)
            pick = inds[np.argsort(errs)[:expected_outer]]
            inliers = np.zeros_like(inliers, dtype=bool)
            inliers[pick] = True
            inlier_count = expected_outer
            ring_r = float(np.median(dists[inliers]))
            cluster_spread = float(np.max(dists[inliers]) - np.min(dists[inliers]))
            tol = max(p.min_inlier_pixels, cluster_spread * 1.5, 3.0)

        inlier_dists = dists[inliers]
        inlier_points = outer_points[inliers]
        spread = float(np.std(inlier_dists))

        angles = np.arctan2(inlier_points[:, 1] - center[1], inlier_points[:, 0] - center[0])
        angles = np.sort((angles + 2 * np.pi) % (2 * np.pi))
        if len(angles) > 1:
            angle_diffs = np.diff(np.concatenate([angles, angles[:1] + 2 * np.pi]))
            largest_gap = float(np.max(angle_diffs))
            coverage = float(2 * math.pi - largest_gap)
            coverage_ratio = coverage / float(2 * math.pi)
        else:
            largest_gap = float(2 * math.pi)
            coverage_ratio = 0.0

        if (
            expected_outer is not None
            and ring_pattern_expected(expected_total)
            and inlier_count >= 4
        ):
            ideal_step = 2.0 * math.pi / float(expected_outer)
            gap_cap = 1.55 * ideal_step if strict_expected_count else 2.08 * ideal_step
            if largest_gap > gap_cap:
                logger.debug(
                    f"环形周向间隔过大: largest_gap={largest_gap:.3f} rad cap={gap_cap:.3f} "
                    f"(expected_outer={expected_outer})"
                )
                return None, "largest_gap_too_large"

        marker_count = inlier_count + 1
        if expected_total is not None:
            if strict_expected_count:
                lower = max(3, expected_total - 2)
                upper = expected_total + 2
                if marker_count < lower or marker_count > upper:
                    logger.debug(
                        f"严格模式数量过滤: marker_count={marker_count}, expect=[{lower},{upper}]"
                    )
                    return None, "strict_marker_count_out_of_range"
                min_cov = 0.68 if ring_pattern_expected(expected_total) else 0.55
                if coverage_ratio < min_cov:
                    logger.debug(
                        f"严格模式覆盖率过滤: coverage_ratio={coverage_ratio:.3f} < {min_cov}"
                    )
                    return None, "strict_coverage_ratio_too_low"
            else:
                if ring_pattern_expected(expected_total) and inlier_count >= 4:
                    min_cov_loose = 0.60
                    if coverage_ratio < min_cov_loose:
                        logger.debug(
                            f"环形非严格覆盖率过滤: coverage_ratio={coverage_ratio:.3f} < {min_cov_loose}"
                        )
                        return None, "loose_coverage_ratio_too_low"
            ring_pen = 2.8 if ring_pattern_expected(expected_total) else 1.2
            count_penalty = abs(marker_count - expected_total) * ring_pen
        else:
            count_penalty = 0.0

        outer_indices = np.where(outer_mask)[0]
        inlier_outer_indices = outer_indices[inliers]
        ring_uniformity = 0.0
        if len(angles) > 2 and expected_outer is not None:
            ad = np.diff(np.concatenate([angles, angles[:1] + 2 * math.pi]))
            ideal_step = 2.0 * math.pi / float(len(angles))
            ring_uniformity = float(1.0 / (1.0 + np.std(ad - ideal_step)))

        score = (
            float(inlier_count)
            - spread * 0.25
            - count_penalty
            + coverage_ratio * 2.0
            + ring_uniformity * 3.5
        )

        if circles.shape[1] >= 3:

            def _marker_xyr(ci: int) -> tuple[float, float, float]:
                row = circles[int(ci)]
                return (float(row[0]), float(row[1]), float(row[2]))

            marker_points = [_marker_xyr(int(center_idx))]
            marker_points.extend(_marker_xyr(int(ci)) for ci in inlier_outer_indices)
            obstacle_marker_radius_px = float(np.median(circles[:, 2]))
        else:
            marker_points = [
                (float(center[0]), float(center[1]), 5.0),
                *[(float(pp[0]), float(pp[1]), 5.0) for pp in inlier_points],
            ]
            obstacle_marker_radius_px = 5.0

        radius = ring_r
        if circles.shape[1] >= 3:
            marker_radii = circles[inlier_outer_indices, 2]
            if len(marker_radii) > 0:
                center_r = (
                    float(circles[int(center_idx), 2]) if int(center_idx) < len(circles) else 0.0
                )
                marker_radius = float(np.median(np.concatenate([[center_r], marker_radii])))
                radius = radius + marker_radius
                obstacle_marker_radius_px = marker_radius
                logger.debug(f"分析圆半径加上障碍物小圆半径: +{marker_radius:.2f} -> {radius:.2f}")

        if (
            p.expected_analysis_radius_px is not None
            and p.expected_analysis_radius_px > 0
            and p.expected_marker_radius_px is not None
            and p.expected_marker_radius_px > 0
        ):
            r_exp = float(p.expected_analysis_radius_px)
            ar_tol = p.analysis_radius_fit_tol
            lo, hi = r_exp * (1.0 - ar_tol), r_exp * (1.0 + ar_tol)
            if radius < lo or radius > hi:
                logger.debug(
                    f"拟合分析圆半径与预设偏差过大: fitted={radius:.2f} px, 期望≈{r_exp:.2f} px "
                    f"([{lo:.2f}, {hi:.2f}])"
                )
                return None, "analysis_radius_out_of_tolerance"

        return ObstacleDetectionResult(
            center_x=float(center[0]),
            center_y=float(center[1]),
            radius=radius,
            frame_index=self._frame_index,
            marker_count=marker_count,
            score=score,
            strict_mode_used=bool(strict_expected_count),
            marker_points=marker_points,
            obstacle_marker_radius_px=float(obstacle_marker_radius_px),
        ), None

    def fit(self) -> ObstacleDetectionResult | None:
        """执行环形拟合：环形模式多中心搜索，其余模式用质心最近点。"""
        points = self._circles[:, :2]
        if len(points) < (self._p.min_outer_markers + 1):
            if self._verbose:
                logger.info(
                    "帧 {}: 环形拟合失败原因: points_insufficient(len_points={}, min_required={})",
                    int(self._frame_index),
                    int(len(points)),
                    int(self._p.min_outer_markers + 1),
                )
            else:
                logger.debug(
                    "帧 {}: 环形拟合失败原因: points_insufficient(len_points={}, min_required={})",
                    int(self._frame_index),
                    int(len(points)),
                    int(self._p.min_outer_markers + 1),
                )
            return None
        min_required_outer = self._p.min_outer_markers
        if self._expected_total is not None:
            min_required_outer = max(
                self._p.min_outer_markers,
                int(round((self._expected_total - 1) * 0.6)),
            )
        centroid = np.mean(points, axis=0)
        dists_to_centroid = np.linalg.norm(points - centroid, axis=1)
        order = np.argsort(dists_to_centroid)
        if ring_pattern_expected(self._expected_total):
            max_try = min(len(points), 40)
            best: ObstacleDetectionResult | None = None
            reason_counts: dict[str, int] = {}
            for k in range(max_try):
                ci = int(order[k])
                res, reason = self._fit_one_center_with_reason(
                    center_idx=ci,
                    min_required_outer=min_required_outer,
                )
                if res is None:
                    key = reason or "unknown"
                    reason_counts[key] = int(reason_counts.get(key, 0) + 1)
                    continue
                if best is None or res.score > best.score:
                    best = res
            if best is None and reason_counts:
                parts = [f"{k}:{v}" for k, v in sorted(reason_counts.items(), key=lambda x: -x[1])]
                if self._verbose:
                    logger.info(
                        "帧 {}: 环形拟合失败原因统计: {}",
                        int(self._frame_index),
                        ", ".join(parts),
                    )
                else:
                    logger.debug(
                        "帧 {}: 环形拟合失败原因统计: {}",
                        int(self._frame_index),
                        ", ".join(parts),
                    )
            return best
        center_idx = int(np.argmin(dists_to_centroid))
        res, reason = self._fit_one_center_with_reason(
            center_idx=center_idx, min_required_outer=min_required_outer
        )
        if res is None:
            if self._verbose:
                logger.info(
                    "帧 {}: 环形拟合失败原因: {}",
                    int(self._frame_index),
                    str(reason or "unknown"),
                )
            else:
                logger.debug(
                    "帧 {}: 环形拟合失败原因: {}",
                    int(self._frame_index),
                    str(reason or "unknown"),
                )
        return res


def fit_ring_from_markers_one_center(
    circles: np.ndarray,
    frame_index: int,
    *,
    expected_total: Optional[int],
    strict_expected_count: bool,
    center_idx: int,
    min_required_outer: int,
    p: ObstacleFrameFitParams,
) -> Optional[ObstacleDetectionResult]:
    """在给定中心索引下拟合环形障碍物；用于多中心搜索。"""
    fitter = _RingFitter(
        circles,
        frame_index,
        p,
        expected_total=expected_total,
        strict_expected_count=strict_expected_count,
        verbose=False,
    )
    return fitter.fit_one_center(
        center_idx=int(center_idx), min_required_outer=int(min_required_outer)
    )


def fit_circle_from_markers(
    circles: np.ndarray,
    frame_index: int,
    p: ObstacleFrameFitParams,
    expected_marker_count: Optional[int] = None,
    strict_expected_count: bool = True,
    verbose: bool = False,
) -> Optional[ObstacleDetectionResult]:
    expected_total = (
        int(expected_marker_count)
        if expected_marker_count is not None and int(expected_marker_count) > 2
        else None
    )
    fitter = _RingFitter(
        circles,
        frame_index,
        p,
        expected_total=expected_total,
        strict_expected_count=strict_expected_count,
        verbose=bool(verbose),
    )
    return fitter.fit()
