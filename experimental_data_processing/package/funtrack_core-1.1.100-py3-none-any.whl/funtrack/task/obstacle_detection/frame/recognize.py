"""单帧障碍物识别入口。

提供 ``recognize_frame`` 函数作为单帧识别的标准入口，内部包含：
1. Hough 圆检测 + 合并 + 过滤
2. 圆拟合（三圆共线 / 环形）
3. 边缘完整性检查

该函数被 ``ObstacleRecognizer.recognize()`` 调用。
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from nltlog import getLogger

from funtrack.task.obstacle_detection.frame.debug_viz import _imwrite_debug
from funtrack.task.obstacle_detection.preview import draw_obstacle_result_on_bgr

from .engine import ObstacleFrameDetectionEngine
from .pipeline import build_obstacle_frame_detect_request, run_obstacle_frame_detection
from .result import ObstacleDetectionResult
from .edge_completeness import check_circle_edge_completeness
from ..utils import coerce_positive_int_or_none

logger = getLogger("funtrack")


def recognize_frame(
    engine: ObstacleFrameDetectionEngine,
    bgr: np.ndarray,
    *,
    frame_index: int,
    expected_marker_count: Optional[int],
    strict_expected_count: bool,
    debug_visualize_dir: str | Path | None = None,
    quiet: bool = False,
) -> Optional[ObstacleDetectionResult]:
    """单帧障碍物识别入口函数。

    内部执行完整流水线：
    1. Hough 圆检测 (CollectHoughTask)
    2. 过滤与共识 (FilterAndConsensusTask)
    3. 圆拟合 (FitMarkerTask)
    4. 边缘完整性检查

    Args:
        engine: 帧检测引擎（包含Hough参数、拟合参数等）
        bgr: BGR图像
        frame_index: 帧索引
        expected_marker_count: 期望的障碍物数量
        strict_expected_count: 是否严格模式
        debug_visualize_dir: 调试图像输出目录
        quiet: 是否静默模式（减少日志）

    Returns:
        识别结果或None
    """
    expected_count = coerce_positive_int_or_none(expected_marker_count)

    debug_dir: Path | None = None
    dbg_n = 0
    if debug_visualize_dir is not None:
        debug_dir = Path(debug_visualize_dir).expanduser().resolve()
        debug_dir.mkdir(parents=True, exist_ok=True)
        logger.info("障碍物检测调试图输出目录: {}", str(debug_dir))
    logger.info(
        "障碍物检测(单帧): expected_count={}, strict={}",
        expected_count,
        strict_expected_count,
    )

    # 执行帧内检测管道 (Hough → 过滤 → 拟合)
    frame_resp = run_obstacle_frame_detection(
        build_obstacle_frame_detect_request(
            engine=engine,
            frame=bgr,
            frame_index=int(frame_index),
            expected_count=expected_count,
            strict_expected_count=strict_expected_count,
            debug_dir=debug_dir,
            dbg_n=dbg_n,
        )
    )
    best = frame_resp.result
    dbg_n = frame_resp.dbg_n

    # 保存调试图像
    if debug_dir is not None and best is not None:
        dbg_n += 1
        _imwrite_debug(
            debug_dir / f"{dbg_n:04d}_FINAL_best_frame{best.frame_index}.png",
            draw_obstacle_result_on_bgr(bgr, best),
        )
    elif debug_dir is not None and best is None:
        dbg_n += 1
        blank = np.zeros((240, 640, 3), dtype=np.uint8)
        cv2.putText(
            blank,
            "obstacle_detect: NO RESULT",
            (20, 120),
            cv2.FONT_HERSHEY_SIMPLEX,
            1.0,
            (0, 0, 255),
            2,
            cv2.LINE_AA,
        )
        _imwrite_debug(debug_dir / f"{dbg_n:04d}_FINAL_no_result.png", blank)

    # 边缘完整性检查已在 fit_marker_candidate 中集成
    # 这里不再重复检查，仅记录日志

    if not strict_expected_count:
        logger.warning("非严格模式已禁用，本次识别将按严格模式执行")
    if best is not None:
        logger.info(
            f"障碍物检测完成: best center=({best.center_x:.2f}, {best.center_y:.2f}), "
            f"radius={best.radius:.2f}, markers={best.marker_count}, "
            f"score={best.score:.3f}, strict_used={best.strict_mode_used}"
        )
    else:
        if quiet:
            logger.debug("障碍物检测完成: 未找到可用固定圆")
        else:
            logger.warning("障碍物检测完成: 未找到可用固定圆")
    return best
