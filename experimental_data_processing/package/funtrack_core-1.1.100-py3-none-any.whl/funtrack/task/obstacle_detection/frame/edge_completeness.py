"""障碍物圆边缘完整性检查：过滤不完整圆/半圆等脏数据。

在 ``pipeline`` 的 ``FitMarkerTask`` 之后执行，提取圆周边缘并检查：
1. 边缘梯度方向一致性
2. 圆周覆盖完整性

供 ``frame_pipeline`` 调用，单独提取不影响原核心逻辑。
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import NamedTuple

import cv2
import numpy as np
from nltlog import getLogger

from funtrack.task.obstacle_detection.frame.result import ObstacleDetectionResult

logger = getLogger("funtrack")


class EdgeCompletenessResult(NamedTuple):
    """边缘完整性检查结果。"""

    passed: bool
    reason: str
    coverage_ratio: float = 0.0
    gradient_consistency: float = 0.0


@dataclass(frozen=True, slots=True)
class EdgeCompletenessParams:
    """边缘完整性检查参数。"""

    min_coverage_ratio: float = 0.1
    min_gradient_consistency: float = 0.70
    sample_points: int = 72
    edge_search_radius: float = 3.0


DEFAULT_EDGE_COMPLETENESS_PARAMS = EdgeCompletenessParams()


def check_circle_edge_completeness(
    bgr: np.ndarray,
    circle: ObstacleDetectionResult,
    params: EdgeCompletenessParams | None = None,
) -> EdgeCompletenessResult:
    """检查圆的边缘完整性。

    通过在圆周上采样，检查：
    1. 边缘梯度方向是否一致指向圆心（完整圆的边缘梯度方向应该高度一致）
    2. 圆周上有多少比例的点能检测到有效边缘

    Args:
        bgr: BGR图像
        circle: 检测到的圆
        params: 检查参数，默认使用DEFAULT_EDGE_COMPLETENESS_PARAMS

    Returns:
        EdgeCompletenessResult: 检查结果
    """
    if params is None:
        params = DEFAULT_EDGE_COMPLETENESS_PARAMS

    cx, cy = float(circle.center_x), float(circle.center_y)
    r = float(circle.radius)
    h, w = bgr.shape[:2]

    if cx < 0 or cy < 0 or cx > w or cy > h:
        return EdgeCompletenessResult(False, f"圆心({cx:.1f},{cy:.1f})超出图像范围[{w}x{h}]")

    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

    sample_points = max(8, int(params.sample_points))
    angle_step = 2.0 * math.pi / sample_points

    valid_edge_count = 0
    gradient_diffs = []
    edge_angles = []

    for i in range(sample_points):
        angle = i * angle_step
        px = cx + r * math.cos(angle)
        py = cy + r * math.sin(angle)

        if not (0 <= px < w and 0 <= py < h):
            continue

        px_int, py_int = int(round(px)), int(round(py))
        if not (0 <= px_int < w and 0 <= py_int < h):
            continue

        search_r = params.edge_search_radius
        half = max(1, int(search_r))
        x1 = max(0, px_int - half)
        x2 = min(w, px_int + half + 1)
        y1 = max(0, py_int - half)
        y2 = min(h, py_int + half + 1)
        patch = gray[y1:y2, x1:x2]

        if patch.size == 0:
            continue

        sobelx = cv2.Sobel(patch, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(patch, cv2.CV_64F, 0, 1, ksize=3)
        gx = float(sobelx[half, half]) if sobelx.shape[0] > half and sobelx.shape[1] > half else 0.0
        gy = float(sobely[half, half]) if sobely.shape[0] > half and sobely.shape[1] > half else 0.0

        mag = math.sqrt(gx * gx + gy * gy)
        if mag < 10.0:
            continue

        valid_edge_count += 1

        gradient_angle = math.atan2(gy, gx)
        radial_angle = angle + math.pi
        diff = abs(gradient_angle - radial_angle)
        if diff > math.pi:
            diff = 2.0 * math.pi - diff

        gradient_diffs.append(diff)
        edge_angles.append(angle)

    if valid_edge_count < 8:
        return EdgeCompletenessResult(
            False,
            f"有效边缘点不足: {valid_edge_count} < 8",
            coverage_ratio=0.0,
            gradient_consistency=0.0,
        )

    coverage_ratio = valid_edge_count / sample_points

    if gradient_diffs:
        avg_diff = sum(gradient_diffs) / len(gradient_diffs)
        max_allowed_diff = 0.5
        if avg_diff > max_allowed_diff:
            gradient_consistency = 0.0
        else:
            gradient_consistency = 1.0 - (avg_diff / max_allowed_diff)
            gradient_consistency = max(0.0, min(1.0, gradient_consistency))
    else:
        gradient_consistency = 0.0

    if coverage_ratio < params.min_coverage_ratio:
        return EdgeCompletenessResult(
            False,
            f"边缘覆盖率不足: {coverage_ratio:.2f} < {params.min_coverage_ratio}",
            coverage_ratio=coverage_ratio,
            gradient_consistency=gradient_consistency,
        )

    if gradient_consistency < params.min_gradient_consistency:
        return EdgeCompletenessResult(
            False,
            f"梯度一致性不足: {gradient_consistency:.2f} < {params.min_gradient_consistency}",
            coverage_ratio=coverage_ratio,
            gradient_consistency=gradient_consistency,
        )

    return EdgeCompletenessResult(
        True,
        f"边缘完整: 覆盖率={coverage_ratio:.2f}, 梯度一致性={gradient_consistency:.2f}",
        coverage_ratio=coverage_ratio,
        gradient_consistency=gradient_consistency,
    )


def check_circle_edge_completeness_quick(
    bgr: np.ndarray,
    center_x: float,
    center_y: float,
    radius: float,
    min_coverage_ratio: float = 0.65,
    sample_points: int = 36,
) -> EdgeCompletenessResult:
    """快速版本的边缘完整性检查（仅覆盖度）。

    仅检查圆周上有多少比例的点能检测到有效边缘，不检查梯度方向。
    适用于需要更快执行的场景。
    """
    cx, cy = float(center_x), float(center_y)
    r = float(radius)
    h, w = bgr.shape[:2]

    if cx < 0 or cy < 0 or cx > w or cy > h:
        return EdgeCompletenessResult(False, f"圆心超出图像范围")

    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)

    sample_points = max(8, int(sample_points))
    angle_step = 2.0 * math.pi / sample_points

    valid_edge_count = 0

    for i in range(sample_points):
        angle = i * angle_step
        px = cx + r * math.cos(angle)
        py = cy + r * math.sin(angle)

        if not (0 <= px < w and 0 <= py < h):
            continue

        px_int, py_int = int(round(px)), int(round(py))
        if not (0 <= px_int < w and 0 <= py_int < h):
            continue

        search_r = 3.0
        half = max(1, int(search_r))
        x1 = max(0, px_int - half)
        x2 = min(w, px_int + half + 1)
        y1 = max(0, py_int - half)
        y2 = min(h, py_int + half + 1)
        patch = gray[y1:y2, x1:x2]

        if patch.size == 0:
            continue

        sobelx = cv2.Sobel(patch, cv2.CV_64F, 1, 0, ksize=3)
        sobely = cv2.Sobel(patch, cv2.CV_64F, 0, 1, ksize=3)
        gx = float(sobelx[half, half]) if sobelx.shape[0] > half and sobelx.shape[1] > half else 0.0
        gy = float(sobely[half, half]) if sobely.shape[0] > half and sobely.shape[1] > half else 0.0

        mag = math.sqrt(gx * gx + gy * gy)
        if mag < 10.0:
            continue

        valid_edge_count += 1

    coverage_ratio = valid_edge_count / sample_points if sample_points > 0 else 0.0

    if coverage_ratio < min_coverage_ratio:
        return EdgeCompletenessResult(
            False,
            f"边缘覆盖率不足: {coverage_ratio:.2f} < {min_coverage_ratio}",
            coverage_ratio=coverage_ratio,
            gradient_consistency=0.0,
        )

    return EdgeCompletenessResult(
        True,
        f"边缘完整: 覆盖率={coverage_ratio:.2f}",
        coverage_ratio=coverage_ratio,
        gradient_consistency=1.0,
    )


__all__ = [
    "EdgeCompletenessResult",
    "EdgeCompletenessParams",
    "DEFAULT_EDGE_COMPLETENESS_PARAMS",
    "check_circle_edge_completeness",
    "check_circle_edge_completeness_quick",
]
