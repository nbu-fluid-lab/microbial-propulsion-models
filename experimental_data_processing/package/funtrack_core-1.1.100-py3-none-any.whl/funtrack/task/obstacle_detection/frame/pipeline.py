"""单帧障碍物检测：Request -> 多 Task -> Response。"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

import cv2
import numpy as np
from nltlog import getLogger

from funtrack.task.obstacle_detection.frame.debug_viz import (
    _DEBUG_COLOR_FILTERED,
    _DEBUG_COLOR_HOUGH,
    _DEBUG_COLOR_HOUGH_LOOSE,
    _DEBUG_COLOR_MERGED,
    _DEBUG_COLOR_REJECT,
    _draw_hough_circles_on_bgr,
    _imwrite_debug,
)
from funtrack.task.obstacle_detection.preview import draw_obstacle_result_on_bgr
from . import fit as frame_fit
from . import hough as fh
from .engine import ObstacleFrameDetectionEngine
from funtrack.task.obstacle_detection.frame.result import ObstacleDetectionResult

logger = getLogger("funtrack")
_HOUGH_BLACK_PIXEL_THRESHOLD = 64
_HOUGH_CIRCLE_BLACK_RATIO_MIN = 0.20
_HOUGH_RING_BLACK_RATIO_MIN = 0.30
_HOUGH_RING_INNER_RADIUS_RATIO = 0.8
_HOUGH_OUTER_RING_OUTER_RADIUS_RATIO = 1.2
_HOUGH_OUTER_RING_BLACK_RATIO_MIN = 0.30
_HOUGH_MARKER_CENTER_MAX_DIST_ANALYSIS_RADIUS_FACTOR = 2.0

TaskOutcome = Literal["continue", "abort_none"]


def _log_frame(
    debug_dir: Path | None,
    fmt: str,
    *args: object,
) -> None:
    if debug_dir is not None:
        logger.info(fmt, *args)
    else:
        logger.debug(fmt, *args)


@dataclass(frozen=True, slots=True)
class ObstacleFrameDetectRequest:
    engine: ObstacleFrameDetectionEngine
    frame: np.ndarray
    frame_index: int
    expected_count: int | None
    strict_expected_count: bool
    debug_dir: Path | None
    dbg_n: int


@dataclass(frozen=True, slots=True)
class ObstacleFrameDetectResponse:
    result: ObstacleDetectionResult | None
    dbg_n: int


@dataclass
class _FrameDetectState:
    request: ObstacleFrameDetectRequest
    triplet: bool = field(init=False)
    base_p2: int | None = field(init=False)
    loose_p2: int | None = field(init=False)
    circles_base: np.ndarray | None = None
    circles_loose: np.ndarray | None = None
    circles: np.ndarray | None = None
    circles_pre_filter: np.ndarray | None = None
    candidate: ObstacleDetectionResult | None = None
    need_hough: int = 0
    dbg_n: int = field(init=False)

    def __post_init__(self) -> None:
        ec = self.request.expected_count
        self.triplet = ec == 3
        self.dbg_n = int(self.request.dbg_n)
        if self.triplet:
            hp2 = int(self.request.engine.hough_param2)
            self.base_p2 = max(4, hp2 - 2)
            self.loose_p2 = max(3, hp2 - 5)
        else:
            self.base_p2 = None
            self.loose_p2 = None


class ObstacleFrameDetectionTask:
    name: str

    def __init__(self, name: str) -> None:
        self.name = name

    def run(self, state: _FrameDetectState) -> TaskOutcome:
        raise NotImplementedError


class CollectHoughTask(ObstacleFrameDetectionTask):
    def __init__(self) -> None:
        super().__init__("collect_hough")

    def run(self, state: _FrameDetectState) -> TaskOutcome:
        req = state.request
        eng = req.engine
        hp = eng.frame_hough_params
        hough = fh.ObstacleFrameHoughTool(hp)
        fi = int(req.frame_index)
        frame = req.frame
        expected_count = req.expected_count

        circles_base = hough.detect_on_bgr(frame, param2_override=state.base_p2)
        state.circles_base = circles_base
        base_count = 0 if circles_base is None else len(circles_base)
        circles_loose: np.ndarray | None = None
        circles = circles_base
        if expected_count is not None and (
            circles is None
            or len(circles) < fh.loose_merge_threshold(expected_count, eng.min_outer_markers)
        ):
            loose_p2 = (
                state.loose_p2 if state.loose_p2 is not None else max(4, int(eng.hough_param2) - 3)
            )
            circles_loose = hough.detect_on_bgr(frame, param2_override=loose_p2)
            circles = fh.merge_hough_circles(circles, circles_loose, eng.hough_min_dist)
            loose_count = 0 if circles_loose is None else len(circles_loose)
            merged_count = 0 if circles is None else len(circles)
            _log_frame(
                req.debug_dir,
                f"帧 {fi}: 基础检测={base_count}, 放宽检测={loose_count}, 合并后={merged_count}",
            )
        else:
            _log_frame(req.debug_dir, f"帧 {fi}: 检测到小圆={base_count}")

        if state.triplet and (circles is None or len(circles) < 3):
            c_clahe = hough.detect_clahe_extra_on_bgr(
                frame,
                param2_override=max(5, int(eng.hough_param2) - 4),
            )
            circles = fh.merge_hough_circles(circles, c_clahe, eng.hough_min_dist)
            if c_clahe is not None:
                _log_frame(
                    req.debug_dir,
                    f"帧 {fi}: 三圆低对比度 CLAHE 补检，合并后小圆={0 if circles is None else len(circles)}",
                )

        need_hough = fh.min_hough_for_obstacle(expected_count, eng.min_outer_markers)
        state.need_hough = need_hough
        if frame_fit.ring_pattern_expected(expected_count) and (
            circles is None or len(circles) < need_hough
        ):
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            for label, c_extra in hough.iter_ring_clahe_variants(gray):
                if c_extra is None:
                    continue
                before = 0 if circles is None else len(circles)
                circles = fh.merge_hough_circles(circles, c_extra, eng.hough_min_dist)
                after = 0 if circles is None else len(circles)
                if after > before:
                    _log_frame(
                        req.debug_dir,
                        f"帧 {fi}: 环形分级补检 {label} +{len(c_extra)} -> 合并={after}",
                    )
                if circles is not None and len(circles) >= need_hough:
                    break

        state.circles_loose = circles_loose
        state.circles = circles
        return "continue"


class DebugHoughTask(ObstacleFrameDetectionTask):
    def __init__(self) -> None:
        super().__init__("debug_hough")

    def run(self, state: _FrameDetectState) -> TaskOutcome:
        req = state.request
        if req.debug_dir is None:
            return "continue"
        fi_tag = int(req.frame_index)
        state.dbg_n += 1
        _imwrite_debug(req.debug_dir / f"{state.dbg_n:04d}_f{fi_tag}_00_source.png", req.frame)
        state.dbg_n += 1
        _imwrite_debug(
            req.debug_dir / f"{state.dbg_n:04d}_f{fi_tag}_01_hough_base.png",
            _draw_hough_circles_on_bgr(req.frame, state.circles_base, color=_DEBUG_COLOR_HOUGH),
        )
        if state.circles_loose is not None:
            state.dbg_n += 1
            _imwrite_debug(
                req.debug_dir / f"{state.dbg_n:04d}_f{fi_tag}_02_hough_loose.png",
                _draw_hough_circles_on_bgr(
                    req.frame, state.circles_loose, color=_DEBUG_COLOR_HOUGH_LOOSE
                ),
            )
        state.dbg_n += 1
        _imwrite_debug(
            req.debug_dir / f"{state.dbg_n:04d}_f{fi_tag}_03_hough_merged.png",
            _draw_hough_circles_on_bgr(req.frame, state.circles, color=_DEBUG_COLOR_MERGED),
        )
        return "continue"


class GateMinHoughBeforeFilterTask(ObstacleFrameDetectionTask):
    def __init__(self) -> None:
        super().__init__("gate_hough_count_pre_filter")

    def run(self, state: _FrameDetectState) -> TaskOutcome:
        if state.circles is None or len(state.circles) < state.need_hough:
            _log_frame(
                state.request.debug_dir, f"帧 {int(state.request.frame_index)}: 小圆数量不足，跳过"
            )
            return "abort_none"
        return "continue"


class FilterAndConsensusTask(ObstacleFrameDetectionTask):
    def __init__(self) -> None:
        super().__init__("filter_and_consensus")

    def run(self, state: _FrameDetectState) -> TaskOutcome:
        req = state.request
        eng = req.engine
        expected_count = req.expected_count
        min_h = state.need_hough
        state.circles_pre_filter = state.circles
        need = (
            fh.min_hough_for_obstacle(expected_count, eng.min_outer_markers)
            if expected_count is not None
            else eng.min_outer_markers + 1
        )
        circles = fh.maybe_filter_hough_circles(
            state.circles,
            expected_marker_radius_px=eng.expected_marker_radius_px,
            need_min_count=need,
            verbose=req.debug_dir is not None,
        )
        circles = _filter_hough_circles_by_center_distance(
            circles,
            frame_shape=req.frame.shape,
            expected_analysis_radius_px=eng.expected_analysis_radius_px,
            factor=_HOUGH_MARKER_CENTER_MAX_DIST_ANALYSIS_RADIUS_FACTOR,
            frame_index=int(req.frame_index),
            verbose=req.debug_dir is not None,
        )
        circles = _filter_hough_circles_by_black_ratio(
            req.frame,
            circles,
            min_black_ratio=_HOUGH_CIRCLE_BLACK_RATIO_MIN,
            black_threshold=_HOUGH_BLACK_PIXEL_THRESHOLD,
            need_min_count=min_h,
            frame_index=int(req.frame_index),
            verbose=req.debug_dir is not None,
        )
        if (
            frame_fit.ring_pattern_expected(expected_count)
            and expected_count is not None
            and circles is not None
            and len(circles) > max(24, int(expected_count) * 4)
        ):
            pre = fh.prefilter_hough_radius_consensus(
                circles,
                expected_marker_count=expected_count,
                ring_pattern_expected=frame_fit.ring_pattern_expected(expected_count),
                need_min_count=fh.min_hough_for_obstacle(expected_count, eng.min_outer_markers),
            )
            if pre is not None and len(pre) >= min_h:
                circles = pre
        state.circles = circles
        return "continue"


class DebugFilterTask(ObstacleFrameDetectionTask):
    def __init__(self) -> None:
        super().__init__("debug_filter")

    def run(self, state: _FrameDetectState) -> TaskOutcome:
        req = state.request
        if req.debug_dir is None:
            return "continue"
        fi_tag = int(req.frame_index)
        state.dbg_n += 1
        _imwrite_debug(
            req.debug_dir / f"{state.dbg_n:04d}_f{fi_tag}_04_pre_radius_filter.png",
            _draw_hough_circles_on_bgr(
                req.frame, state.circles_pre_filter, color=_DEBUG_COLOR_MERGED
            ),
        )
        state.dbg_n += 1
        _imwrite_debug(
            req.debug_dir / f"{state.dbg_n:04d}_f{fi_tag}_05_after_radius_filter.png",
            _draw_hough_circles_on_bgr(req.frame, state.circles, color=_DEBUG_COLOR_FILTERED),
        )
        return "continue"


class GateMinHoughAfterFilterTask(ObstacleFrameDetectionTask):
    def __init__(self) -> None:
        super().__init__("gate_hough_count_post_filter")

    def run(self, state: _FrameDetectState) -> TaskOutcome:
        if state.circles is None or len(state.circles) < state.need_hough:
            _log_frame(
                state.request.debug_dir,
                f"帧 {int(state.request.frame_index)}: 半径过滤后小圆数量不足，跳过",
            )
            return "abort_none"
        return "continue"


class FitMarkerTask(ObstacleFrameDetectionTask):
    def __init__(self) -> None:
        super().__init__("fit_marker")

    def run(self, state: _FrameDetectState) -> TaskOutcome:
        req = state.request
        eng = req.engine
        fi = int(req.frame_index)
        candidate = frame_fit.fit_marker_candidate(
            state.circles,
            fi,
            req.expected_count,
            req.strict_expected_count,
            eng.frame_fit_params,
            bgr=req.frame,  # 传入BGR图像用于边缘完整性检查
            debug_dir=req.debug_dir,
        )
        state.candidate = candidate

        if req.debug_dir is not None:
            state.dbg_n += 1
            out_p = req.debug_dir / f"{state.dbg_n:04d}_f{fi}_06_fit.png"
            if candidate is not None:
                _imwrite_debug(out_p, draw_obstacle_result_on_bgr(req.frame, candidate))
            else:
                vis = _draw_hough_circles_on_bgr(
                    req.frame, state.circles, color=_DEBUG_COLOR_REJECT
                )
                cv2.putText(
                    vis,
                    "fit_failed_or_rejected",
                    (20, 40),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1.0,
                    (0, 0, 255),
                    2,
                    cv2.LINE_AA,
                )
                _imwrite_debug(out_p, vis)

        if candidate is None:
            _log_frame(req.debug_dir, f"帧 {fi}: 圆拟合失败或未通过约束")
            return "abort_none"

        _log_frame(
            req.debug_dir,
            f"帧 {fi}: 候选圆 center=({candidate.center_x:.2f}, {candidate.center_y:.2f}), "
            f"radius={candidate.radius:.2f}, markers={candidate.marker_count}, score={candidate.score:.3f}",
        )
        return "continue"


DEFAULT_FRAME_DETECTION_TASKS: tuple[ObstacleFrameDetectionTask, ...] = (
    CollectHoughTask(),
    DebugHoughTask(),
    FilterAndConsensusTask(),
    DebugFilterTask(),
    GateMinHoughAfterFilterTask(),
    FitMarkerTask(),
)


def _filter_hough_circles_by_black_ratio(
    frame_bgr: np.ndarray,
    circles: np.ndarray | None,
    *,
    min_black_ratio: float,
    black_threshold: int,
    need_min_count: int,
    frame_index: int,
    verbose: bool,
) -> np.ndarray | None:
    if circles is None or len(circles) == 0:
        return circles
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    uvals = np.unique(gray)
    is_binary_01 = bool(
        uvals.size <= 2 and np.all(np.isin(uvals, np.array([0, 255], dtype=uvals.dtype)))
    )
    h, w = gray.shape[:2]
    keep: list[np.ndarray] = []
    dropped = 0
    for row in circles:
        cx = int(round(float(row[0])))
        cy = int(round(float(row[1])))
        rr = max(1, int(round(float(row[2]))))
        outer_mask = np.zeros((h, w), dtype=np.uint8)
        cv2.circle(outer_mask, (cx, cy), rr, 255, thickness=-1, lineType=cv2.LINE_AA)
        in_circle = outer_mask > 0
        area = int(np.count_nonzero(in_circle))
        if area <= 0:
            dropped += 1
            continue
        if is_binary_01:
            black_circle = (gray == 0) & in_circle
        else:
            black_circle = (gray < int(black_threshold)) & in_circle
        circle_ratio = float(np.count_nonzero(black_circle)) / float(area)

        inner_r = max(1, int(round(rr * float(_HOUGH_RING_INNER_RADIUS_RATIO))))
        inner_mask = np.zeros((h, w), dtype=np.uint8)
        cv2.circle(inner_mask, (cx, cy), inner_r, 255, thickness=-1, lineType=cv2.LINE_AA)
        ring_region = in_circle & (~(inner_mask > 0))
        ring_area = int(np.count_nonzero(ring_region))
        if ring_area > 0:
            if is_binary_01:
                black_ring = (gray == 0) & ring_region
            else:
                black_ring = (gray < int(black_threshold)) & ring_region
            ring_ratio = float(np.count_nonzero(black_ring)) / float(ring_area)
        else:
            ring_ratio = 0.0

        outer_r = max(1, int(round(rr * float(_HOUGH_OUTER_RING_OUTER_RADIUS_RATIO))))
        outer_shell_mask = np.zeros((h, w), dtype=np.uint8)
        cv2.circle(outer_shell_mask, (cx, cy), outer_r, 255, thickness=-1, lineType=cv2.LINE_AA)
        outer_ring_region = (outer_shell_mask > 0) & (~in_circle)
        outer_ring_area = int(np.count_nonzero(outer_ring_region))
        if outer_ring_area > 0:
            if is_binary_01:
                black_outer_ring = (gray == 0) & outer_ring_region
            else:
                black_outer_ring = (gray < int(black_threshold)) & outer_ring_region
            outer_ring_ratio = float(np.count_nonzero(black_outer_ring)) / float(outer_ring_area)
        else:
            outer_ring_ratio = 0.0

        if (
            circle_ratio >= float(min_black_ratio)
            or ring_ratio >= float(_HOUGH_RING_BLACK_RATIO_MIN)
            or outer_ring_ratio >= float(_HOUGH_OUTER_RING_BLACK_RATIO_MIN)
        ):
            keep.append(row)
        else:
            dropped += 1
    if dropped <= 0:
        return circles
    if verbose:
        logger.info(
            "帧 {}: Hough 黑点占比过滤 {} -> {} (circle_min={:.2f}, ring_min={:.2f}, ring=[{:.2f}r,1.00r], outer_ring_min={:.2f}, outer_ring=[1.00r,{:.2f}r])",
            int(frame_index),
            len(circles),
            len(keep),
            float(min_black_ratio),
            float(_HOUGH_RING_BLACK_RATIO_MIN),
            float(_HOUGH_RING_INNER_RADIUS_RATIO),
            float(_HOUGH_OUTER_RING_BLACK_RATIO_MIN),
            float(_HOUGH_OUTER_RING_OUTER_RADIUS_RATIO),
        )
    else:
        logger.debug(
            "帧 {}: Hough 黑点占比过滤 {} -> {} (circle_min={:.2f}, ring_min={:.2f}, ring=[{:.2f}r,1.00r], outer_ring_min={:.2f}, outer_ring=[1.00r,{:.2f}r])",
            int(frame_index),
            len(circles),
            len(keep),
            float(min_black_ratio),
            float(_HOUGH_RING_BLACK_RATIO_MIN),
            float(_HOUGH_RING_INNER_RADIUS_RATIO),
            float(_HOUGH_OUTER_RING_BLACK_RATIO_MIN),
            float(_HOUGH_OUTER_RING_OUTER_RADIUS_RATIO),
        )
    _ = need_min_count
    if len(keep) <= 0:
        return np.empty((0, 3), dtype=circles.dtype)
    return np.asarray(keep, dtype=circles.dtype)


def _filter_hough_circles_by_center_distance(
    circles: np.ndarray | None,
    *,
    frame_shape: tuple[int, ...],
    expected_analysis_radius_px: float | None,
    factor: float,
    frame_index: int,
    verbose: bool,
) -> np.ndarray | None:
    if circles is None or len(circles) == 0:
        return circles
    if expected_analysis_radius_px is None or float(expected_analysis_radius_px) <= 0:
        return circles
    h, w = int(frame_shape[0]), int(frame_shape[1])
    if h <= 0 or w <= 0:
        return circles
    cx_img = 0.5 * float(w)
    cy_img = 0.5 * float(h)
    max_dist = float(expected_analysis_radius_px) * float(factor)
    keep: list[np.ndarray] = []
    for row in circles:
        dx = float(row[0]) - cx_img
        dy = float(row[1]) - cy_img
        dist = float((dx * dx + dy * dy) ** 0.5)
        if dist <= max_dist:
            keep.append(row)
    if len(keep) == len(circles):
        return circles
    if verbose:
        logger.info(
            "帧 {}: Hough 圆心距图像中心过滤 {} -> {} (max_dist={:.2f}px, factor={:.2f})",
            int(frame_index),
            len(circles),
            len(keep),
            float(max_dist),
            float(factor),
        )
    else:
        logger.debug(
            "帧 {}: Hough 圆心距图像中心过滤 {} -> {} (max_dist={:.2f}px, factor={:.2f})",
            int(frame_index),
            len(circles),
            len(keep),
            float(max_dist),
            float(factor),
        )
    if len(keep) <= 0:
        return np.empty((0, 3), dtype=circles.dtype)
    return np.asarray(keep, dtype=circles.dtype)


def build_obstacle_frame_detect_request(
    *,
    engine: ObstacleFrameDetectionEngine,
    frame: np.ndarray,
    frame_index: int,
    expected_count: int | None,
    strict_expected_count: bool,
    debug_dir: Path | None,
    dbg_n: int,
) -> ObstacleFrameDetectRequest:
    return ObstacleFrameDetectRequest(
        engine=engine,
        frame=frame,
        frame_index=frame_index,
        expected_count=expected_count,
        strict_expected_count=strict_expected_count,
        debug_dir=debug_dir,
        dbg_n=dbg_n,
    )


def build_obstacle_frame_detection_tasks(
    request: ObstacleFrameDetectRequest,
) -> tuple[ObstacleFrameDetectionTask, ...]:
    _ = request
    return DEFAULT_FRAME_DETECTION_TASKS


def run_obstacle_frame_detection(
    request: ObstacleFrameDetectRequest,
    *,
    tasks: tuple[ObstacleFrameDetectionTask, ...] | None = None,
) -> ObstacleFrameDetectResponse:
    active_tasks = tasks if tasks is not None else build_obstacle_frame_detection_tasks(request)
    state = _FrameDetectState(request=request)
    for task in active_tasks:
        out = task.run(state)
        if out == "abort_none":
            return ObstacleFrameDetectResponse(result=None, dbg_n=state.dbg_n)
    return ObstacleFrameDetectResponse(result=state.candidate, dbg_n=state.dbg_n)


__all__ = [
    "ObstacleFrameDetectRequest",
    "ObstacleFrameDetectResponse",
    "ObstacleFrameDetectionTask",
    "DEFAULT_FRAME_DETECTION_TASKS",
    "build_obstacle_frame_detect_request",
    "build_obstacle_frame_detection_tasks",
    "run_obstacle_frame_detection",
]
