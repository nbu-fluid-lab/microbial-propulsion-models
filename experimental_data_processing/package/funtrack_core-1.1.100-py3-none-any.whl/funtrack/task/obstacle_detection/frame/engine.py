"""单帧障碍物检测 **引擎快照**：Hough/拟合参数子集 + 合并用标量。

``frame_pipeline`` 只依赖本类型，不依赖 ``ObstacleCircleDetector``，避免帧内几何与
「视频抽帧 / 多档策略」类耦合。产品路径下由 ``ObstacleCircleDetector`` 在构造末组装
``ObstacleFrameDetectionEngine``；测试可用 ``from_obstacle_circle_detector`` 从任意
带同名属性的对象构造。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .fit import ObstacleFrameFitParams
from .hough import ObstacleFrameHoughParams


@dataclass(frozen=True, slots=True)
class ObstacleFrameDetectionEngine:
    """单帧 Hough→合并→过滤→拟合 所需的全部不可变输入。"""

    hough_min_dist: int
    hough_param2: int
    min_outer_markers: int
    expected_marker_radius_px: float | None
    expected_analysis_radius_px: float | None
    frame_hough_params: ObstacleFrameHoughParams
    frame_fit_params: ObstacleFrameFitParams

    @classmethod
    def from_obstacle_circle_detector(cls, det: Any) -> ObstacleFrameDetectionEngine:
        """从带 ``frame_hough_params`` / ``frame_fit_params`` 及合并用字段的对象构造（测试/mock）。"""
        return cls(
            hough_min_dist=int(det.hough_min_dist),
            hough_param2=int(det.hough_param2),
            min_outer_markers=int(det.min_outer_markers),
            expected_marker_radius_px=getattr(det, "expected_marker_radius_px", None),
            expected_analysis_radius_px=getattr(det, "expected_analysis_radius_px", None),
            frame_hough_params=det.frame_hough_params,
            frame_fit_params=det.frame_fit_params,
        )
