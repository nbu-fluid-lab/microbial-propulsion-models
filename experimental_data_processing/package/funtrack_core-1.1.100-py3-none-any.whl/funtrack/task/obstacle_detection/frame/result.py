"""obstacle_detection 内部结果模型。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass
class ObstacleDetectionResult:
    """障碍物识别结果（仅在 obstacle_detection 内部流转）。"""

    center_x: float
    center_y: float
    radius: float
    frame_index: int
    marker_count: int
    score: float
    strict_mode_used: bool
    marker_points: list[tuple[float, float, float]]
    obstacle_marker_radius_px: float = 5.0

    def to_dict(self) -> dict[str, object]:
        """转为可 ``json.dumps`` 的平面对象。"""
        return {
            "center_x": float(self.center_x),
            "center_y": float(self.center_y),
            "radius": float(self.radius),
            "frame_index": int(self.frame_index),
            "marker_count": int(self.marker_count),
            "score": float(self.score),
            "strict_mode_used": bool(self.strict_mode_used),
            "marker_points": [[float(x), float(y), float(zr)] for x, y, zr in self.marker_points],
            "obstacle_marker_radius_px": float(self.obstacle_marker_radius_px),
        }

    @classmethod
    def from_dict(cls, d: Mapping[str, Any]) -> ObstacleDetectionResult:
        """与 ``to_dict`` 对称；缺字段时报错。"""
        mpts_raw = d["marker_points"]
        marker_points: list[tuple[float, float, float]] = []
        for item in mpts_raw:
            if not isinstance(item, (list, tuple)) or len(item) < 3:
                continue
            marker_points.append((float(item[0]), float(item[1]), float(item[2])))
        return cls(
            center_x=float(d["center_x"]),
            center_y=float(d["center_y"]),
            radius=float(d["radius"]),
            frame_index=int(d["frame_index"]),
            marker_count=int(d["marker_count"]),
            score=float(d["score"]),
            strict_mode_used=bool(d["strict_mode_used"]),
            marker_points=marker_points,
            obstacle_marker_radius_px=float(d.get("obstacle_marker_radius_px", 5.0)),
        )
