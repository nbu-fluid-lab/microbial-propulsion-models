"""障碍物单帧/链路的调试图绘制与落盘。"""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
from nltlog import getLogger

logger = getLogger("funtrack")

# BGR，调试图用
_DEBUG_COLOR_HOUGH = (80, 220, 80)
_DEBUG_COLOR_HOUGH_LOOSE = (200, 160, 80)
_DEBUG_COLOR_MERGED = (60, 200, 255)
_DEBUG_COLOR_FILTERED = (180, 80, 255)
_DEBUG_COLOR_REJECT = (100, 100, 100)


def _draw_hough_circles_on_bgr(
    bgr: np.ndarray,
    circles: np.ndarray | None,
    *,
    color: tuple[int, int, int] = _DEBUG_COLOR_HOUGH,
    thickness: int = 4,
) -> np.ndarray:
    """在 BGR 图像上描 Hough 圆，用于中间步骤可视化。"""
    vis = bgr.copy()
    if circles is not None and len(circles) > 0:
        for row in circles:
            x = int(round(float(row[0])))
            y = int(round(float(row[1])))
            r = int(round(max(1.0, float(row[2]))))
            cv2.circle(vis, (x, y), r, color, thickness, lineType=cv2.LINE_AA)
            cv2.circle(vis, (x, y), 3, (0, 0, 255), -1, lineType=cv2.LINE_AA)
    return vis


def _imwrite_debug(path: Path, bgr: np.ndarray) -> None:
    """将调试图写入磁盘；失败时打日志。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    ok = cv2.imwrite(str(path), bgr)
    if not ok:
        logger.warning(f"调试图写入失败: {path}")


__all__ = [
    "_DEBUG_COLOR_FILTERED",
    "_DEBUG_COLOR_HOUGH",
    "_DEBUG_COLOR_HOUGH_LOOSE",
    "_DEBUG_COLOR_MERGED",
    "_DEBUG_COLOR_REJECT",
    "_draw_hough_circles_on_bgr",
    "_imwrite_debug",
]
