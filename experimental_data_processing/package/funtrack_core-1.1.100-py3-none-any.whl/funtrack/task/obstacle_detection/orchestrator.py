"""障碍物检测链：多个 **识别器子类实例** 的顺序编排。

视频路径下由 ``run_video`` **统一抽帧**（步数取链上各识别器 ``sample_frames`` 的最大值）；
对 **每一帧 BGR** 依次调用各识别器的 ``recognize``任一识别器通过即返回，否则再读下一采样帧。静态图后缀走单帧读入后同样过链。

``ObstacleCircleDetector`` 仅保留单帧检测；视频路径统一由本链 ``run_video`` 负责抽帧编排。
"""

from __future__ import annotations

import json
from collections.abc import Sequence
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
from nltlog import getLogger

from .output_validation import default_marker_count_abs_tolerance
from .frame.recognizers import (
    BinarizedPrimaryObstacleRecognizer,
    ObstacleRecognizer,
    PrimaryObstacleRecognizer,
    RelaxedHoughObstacleRecognizer,
    TripletSmallScaleObstacleRecognizer,
    UltraRelaxedHoughObstacleRecognizer,
)
from .frame.result import ObstacleDetectionResult
from .utils import to_jsonable_shallow_dict

logger = getLogger("funtrack")

_IMAGE_SUFFIXES = (".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp")


class ObstacleDetectionChain:
    """按给定顺序对 **同一视频路径** 执行多档识别；各识别器在构造时已绑定标定与画幅。

    链上每一项均为 ``ObstacleRecognizer`` 的 **具体实例**（参数档不同）。视频上由
    ``run_video`` 抽帧后，对 **每一帧** 按顺序调用 ``recognize``，直至某一档通过输出闸门。
    """

    __slots__ = (
        "_recognizers",
        "_expected_marker_count",
        "_marker_um",
        "_scale_um_per_pixel",
        "_circle_analysis_radius_um",
        "_strict_expected_count",
        "_frame_width_px",
        "_frame_height_px",
    )

    def __init__(
        self,
        recognizers: Sequence[ObstacleRecognizer],
        *,
        expected_marker_count: int | None = None,
        marker_um: float | None = None,
        scale_um_per_pixel: float | None = None,
        circle_analysis_radius_um: float | None = None,
        strict_expected_count: bool | None = None,
        frame_width_px: int | None = None,
        frame_height_px: int | None = None,
    ) -> None:
        self._recognizers: tuple[ObstacleRecognizer, ...] = tuple(recognizers)
        self._expected_marker_count = expected_marker_count
        self._marker_um = marker_um
        self._scale_um_per_pixel = scale_um_per_pixel
        self._circle_analysis_radius_um = circle_analysis_radius_um
        self._strict_expected_count = strict_expected_count
        self._frame_width_px = frame_width_px
        self._frame_height_px = frame_height_px

    @classmethod
    def _enable_triplet_small_scale_recognizer(
        cls,
        *,
        expected_marker_count: int,
        marker_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
    ) -> bool:
        """是否启用三障碍物小比例尺定制识别器。"""
        _ = cls
        if int(expected_marker_count) != 3:
            return False
        if float(scale_um_per_pixel) > 0.2:
            return False
        if marker_um is None or float(marker_um) < 10.0:
            return False
        analysis_r = circle_analysis_radius_um
        if analysis_r is None:
            return False
        return 80.0 <= float(analysis_r) <= 220.0

    def _coerce_recognizer_sample_frames(self, recognizer: object) -> int:
        raw = getattr(recognizer, "sample_frames", 10)
        try:
            n = int(raw)
        except (TypeError, ValueError):
            n = 10
        return max(1, n)

    def _coerce_chain_sample_frames(self) -> int:
        """链路抽帧数取各识别器 ``sample_frames`` 的最大值，避免后置识别器需要更密抽帧却被截断。"""
        if not self._recognizers:
            return 10
        values: list[int] = []
        for r in self._recognizers:
            values.append(self._coerce_recognizer_sample_frames(r))
        return max(values) if values else 10

    @classmethod
    def with_default_recognizers(
        cls,
        *,
        expected_marker_count: int,
        marker_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
        strict_expected_count: bool,
        frame_width_px: int | None = None,
        frame_height_px: int | None = None,
    ) -> ObstacleDetectionChain:
        """主路径 → 二值化主档 → 宽松 Hough → 超宽松 Hough；业务参数与画幅由调用方注入。"""
        kw = dict(
            expected_marker_count=expected_marker_count,
            marker_um=marker_um,
            scale_um_per_pixel=scale_um_per_pixel,
            circle_analysis_radius_um=circle_analysis_radius_um,
            strict_expected_count=strict_expected_count,
            frame_width_px=frame_width_px,
            frame_height_px=frame_height_px,
        )
        recognizers: list[ObstacleRecognizer] = [
            PrimaryObstacleRecognizer(**kw),
            BinarizedPrimaryObstacleRecognizer(**kw),
            RelaxedHoughObstacleRecognizer(**kw),
            UltraRelaxedHoughObstacleRecognizer(**kw),
        ]
        if cls._enable_triplet_small_scale_recognizer(
            expected_marker_count=expected_marker_count,
            marker_um=marker_um,
            scale_um_per_pixel=scale_um_per_pixel,
            circle_analysis_radius_um=circle_analysis_radius_um,
        ):
            recognizers.append(TripletSmallScaleObstacleRecognizer(**kw))
        return cls(
            tuple(recognizers),
            expected_marker_count=expected_marker_count,
            marker_um=marker_um,
            scale_um_per_pixel=scale_um_per_pixel,
            circle_analysis_radius_um=circle_analysis_radius_um,
            strict_expected_count=strict_expected_count,
            frame_width_px=frame_width_px,
            frame_height_px=frame_height_px,
        )

    @property
    def recognizers(self) -> tuple[ObstacleRecognizer, ...]:
        return self._recognizers

    def run_recognizers_on_bgr(
        self,
        bgr: np.ndarray,
        *,
        frame_index: int,
        debug_base_dir: Path | None = None,
    ) -> ObstacleDetectionResult | None:
        """对单帧 BGR 依次尝试各识别器 ``recognize``；首个通过输出闸门的非空结果即返回。"""
        for rec in self._recognizers:
            debug_dir: str | None = None
            if debug_base_dir is not None:
                d = debug_base_dir / f"f{int(frame_index):06d}" / rec.name
                d.mkdir(parents=True, exist_ok=True)
                debug_dir = str(d)
            candidate = rec.recognize(
                bgr,
                frame_index=frame_index,
                debug_visualize_dir=debug_dir,
            )
            if candidate is not None:
                logger.info(
                    "障碍物检测链: 帧 {} 识别器「{}」通过输出校验",
                    frame_index,
                    rec.name,
                )
                return candidate
        return None

    def run_video(
        self,
        video_path: str,
        *,
        debug: bool = False,
        debug_output_dir: str | None = None,
    ) -> ObstacleDetectionResult | None:
        """统一抽帧；每帧上跑 ``run_recognizers_on_bgr``，直到命中或耗尽采样。"""
        entry_info = {
            "video_path": str(video_path),
            "debug": bool(debug),
            "debug_output_dir": str(debug_output_dir) if debug_output_dir is not None else None,
            "expected_marker_count": self._expected_marker_count,
            "marker_diameter_um": self._marker_um,
            "scale_um_per_pixel": self._scale_um_per_pixel,
            "circle_analysis_radius_um": self._circle_analysis_radius_um,
            "strict_expected_count": self._strict_expected_count,
            "frame_width_px": self._frame_width_px,
            "frame_height_px": self._frame_height_px,
            "recognizer_chain": [r.name for r in self._recognizers],
            "sample_frames": self._coerce_chain_sample_frames(),
        }
        logger.info("障碍物检测入口入参: {}", json.dumps(entry_info, ensure_ascii=False))

        path = Path(video_path)
        if not path.exists():
            logger.warning("障碍物检测链: 路径不存在 {}", video_path)
            return None
        debug_base_dir: Path | None = None
        if debug:
            if debug_output_dir is not None and str(debug_output_dir).strip():
                debug_base_dir = Path(debug_output_dir).expanduser().resolve()
            else:
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                debug_base_dir = (
                    Path.cwd() / "output" / "obstacle_chain_debug" / f"{path.stem}_{ts}"
                )
            debug_base_dir.mkdir(parents=True, exist_ok=True)
            logger.info("障碍物检测链调试图目录: {}", str(debug_base_dir))

        if path.suffix.lower() in _IMAGE_SUFFIXES:
            bgr = cv2.imread(str(path))
            if bgr is None:
                logger.warning("障碍物检测链: 无法读取图像 {}", video_path)
                return None
            return self.run_recognizers_on_bgr(
                bgr,
                frame_index=0,
                debug_base_dir=debug_base_dir,
            )

        sample_frames = self._coerce_chain_sample_frames()

        cap = cv2.VideoCapture(str(path))
        if not cap.isOpened():
            logger.warning("障碍物检测链: 无法打开视频 {}", video_path)
            return None
        try:
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
            if total_frames <= 0:
                return None
            sample_ids = np.linspace(0, total_frames - 1, num=sample_frames, dtype=int)
            for fi in sample_ids:
                cap.set(cv2.CAP_PROP_POS_FRAMES, int(fi))
                ok, frame = cap.read()
                if not ok or frame is None:
                    logger.warning("障碍物检测链: 采样帧读取失败 frame={}", int(fi))
                    continue
                out = self.run_recognizers_on_bgr(
                    frame,
                    frame_index=int(fi),
                    debug_base_dir=debug_base_dir,
                )
                if out is not None:
                    return out
        finally:
            cap.release()
        return None

    def log_total_failure(self, video_path: str) -> None:
        """输出链路全失败时的完整参数快照（JSON格式）。"""
        if (
            self._expected_marker_count is None
            or self._scale_um_per_pixel is None
            or self._strict_expected_count is None
        ):
            logger.warning(
                "障碍物检测链：全部识别器失败（无完整业务参数上下文）video_path={}", video_path
            )
            return
        tol_mc = default_marker_count_abs_tolerance(self._expected_marker_count)

        error_info = {
            "error_type": "OBSTACLE_DETECTION_FAILED",
            "video_path": str(video_path),
            "expected_marker_count": self._expected_marker_count,
            "marker_diameter_um": self._marker_um,
            "scale_um_per_pixel": self._scale_um_per_pixel,
            "circle_analysis_radius_um": self._circle_analysis_radius_um,
            "strict_expected_count": self._strict_expected_count,
            "frame_width_px": self._frame_width_px,
            "frame_height_px": self._frame_height_px,
            "validation": {
                "marker_count_tolerance": tol_mc,
                "marker_radius_tolerance": 0.20,
                "analysis_radius_tolerance": 0.20,
                "center_offset_tolerance": 0.15,
            },
            "recognizer_chain": [r.name for r in self._recognizers],
        }
        logger.warning("障碍物检测失败: {}", json.dumps(error_info, ensure_ascii=False))
