"""障碍物检测 **视频** 服务入口：Request/Response + 统一抽帧执行。"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Mapping

from nltlog import getLogger

from funtrack.core.utils import read_obstacle_video_frame_size_px
from funtrack.task.obstacle_detection.frame.result import ObstacleDetectionResult
from funtrack.task.obstacle_detection.service_support import default_obstacle_detection_chain
from funtrack.task.obstacle_detection.utils import ensure_no_extra_keys

logger = getLogger("funtrack")

_REQUEST_KEYS = {
    "video_path",
    "expected_marker_count",
    "marker_um",
    "scale_um_per_pixel",
    "circle_analysis_radius_um",
    "strict_expected_count",
    "debug",
    "debug_output_dir",
}
_RESPONSE_KEYS = {"ok", "result", "error"}


@dataclass(frozen=True, slots=True)
class ObstacleVideoDetectionRequest:
    """视频障碍物链外部入参；可与 JSON 完全互转。"""

    video_path: str
    expected_marker_count: int
    marker_um: float | None
    scale_um_per_pixel: float
    circle_analysis_radius_um: float | None
    strict_expected_count: bool
    debug: bool = False
    debug_output_dir: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "video_path": self.video_path,
            "expected_marker_count": int(self.expected_marker_count),
            "marker_um": self.marker_um,
            "scale_um_per_pixel": float(self.scale_um_per_pixel),
            "circle_analysis_radius_um": self.circle_analysis_radius_um,
            "strict_expected_count": bool(self.strict_expected_count),
            "debug": bool(self.debug),
            "debug_output_dir": self.debug_output_dir,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_dict(cls, d: Mapping[str, object]) -> ObstacleVideoDetectionRequest:
        ensure_no_extra_keys(d, allowed=_REQUEST_KEYS, kind="ObstacleVideoDetectionRequest")
        v = d.get("video_path")
        if not isinstance(v, str) or not v.strip():
            raise ValueError("video_path 须为非空字符串")
        e = d.get("expected_marker_count")
        if e is None:
            raise ValueError("expected_marker_count 必填")
        em = d.get("marker_um")
        if em is not None and not isinstance(em, (int, float)):
            raise ValueError("marker_um 须为 number 或 null")
        s = d.get("scale_um_per_pixel")
        if s is None or not isinstance(s, (int, float)):
            raise ValueError("scale_um_per_pixel 须为 number")
        ar = d.get("circle_analysis_radius_um")
        if ar is not None and not isinstance(ar, (int, float)):
            raise ValueError("circle_analysis_radius_um 须为 number 或 null")
        st = d.get("strict_expected_count")
        if not isinstance(st, bool):
            raise ValueError("strict_expected_count 须为 bool")
        if not st:
            raise ValueError("已移除非严格模式，strict_expected_count 必须为 true")
        dbg = d.get("debug", False)
        if not isinstance(dbg, bool):
            raise ValueError("debug 须为 bool")
        dbg_dir = d.get("debug_output_dir")
        if dbg_dir is not None and not isinstance(dbg_dir, str):
            raise ValueError("debug_output_dir 须为 string 或 null")
        ec = int(e)
        if ec <= 0:
            raise ValueError("expected_marker_count 须为正整数")
        scale = float(s)
        if scale <= 0:
            raise ValueError("scale_um_per_pixel 须为正数")
        marker = float(em) if em is not None else None
        if marker is not None and marker <= 0:
            raise ValueError("marker_um 须为正数或 null")
        ar_v = float(ar) if ar is not None else None
        if ar_v is not None and ar_v <= 0:
            raise ValueError("circle_analysis_radius_um 须为正数或 null")
        return cls(
            video_path=v.strip(),
            expected_marker_count=ec,
            marker_um=marker,
            scale_um_per_pixel=scale,
            circle_analysis_radius_um=ar_v,
            strict_expected_count=bool(st),
            debug=bool(dbg),
            debug_output_dir=dbg_dir.strip() if isinstance(dbg_dir, str) else None,
        )

    @classmethod
    def from_json(cls, s: str) -> ObstacleVideoDetectionRequest:
        return cls.from_dict(json.loads(s))


@dataclass(frozen=True, slots=True)
class ObstacleVideoDetectionResponse:
    """视频障碍物链的对外结果；无圆时 ``ok`` 为 False 且 ``result`` 为 ``None``。"""

    ok: bool
    result: dict[str, object] | None
    error: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "ok": self.ok,
            "result": self.result,
            "error": self.error,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False)

    @classmethod
    def from_dict(cls, d: Mapping[str, object]) -> ObstacleVideoDetectionResponse:
        ensure_no_extra_keys(d, allowed=_RESPONSE_KEYS, kind="ObstacleVideoDetectionResponse")
        ok = d.get("ok")
        if not isinstance(ok, bool):
            raise ValueError("ok 须为 bool")
        r = d.get("result")
        if r is not None and not isinstance(r, dict):
            raise ValueError("result 须为 object 或 null")
        err = d.get("error")
        if err is not None and not isinstance(err, str):
            raise ValueError("error 须为 string 或 null")
        return cls(
            ok=ok,
            result=dict(r) if r is not None else None,
            error=err,
        )

    @classmethod
    def from_json(cls, s: str) -> ObstacleVideoDetectionResponse:
        return cls.from_dict(json.loads(s))


def run_obstacle_video_detection_request(
    request: ObstacleVideoDetectionRequest,
) -> ObstacleVideoDetectionResponse:
    """执行视频链并返回 Response。"""
    if not bool(request.strict_expected_count):
        raise ValueError("已移除非严格模式，strict_expected_count 必须为 True")
    frame_wh = read_obstacle_video_frame_size_px(str(request.video_path))
    fw, fh = frame_wh if frame_wh is not None else (None, None)
    chain = default_obstacle_detection_chain(
        expected_marker_count=int(request.expected_marker_count),
        marker_um=request.marker_um,
        scale_um_per_pixel=float(request.scale_um_per_pixel),
        circle_analysis_radius_um=request.circle_analysis_radius_um,
        frame_width_px=fw,
        frame_height_px=fh,
    )
    raw: ObstacleDetectionResult | None = chain.run_video(
        str(request.video_path),
        debug=bool(request.debug),
        debug_output_dir=request.debug_output_dir,
    )
    if raw is None:
        chain.log_total_failure(request.video_path)
        return ObstacleVideoDetectionResponse(
            ok=False, result=None, error="no_obstacle_circle_result"
        )
    return ObstacleVideoDetectionResponse(
        ok=True,
        result=raw.to_dict(),
        error=None,
    )
