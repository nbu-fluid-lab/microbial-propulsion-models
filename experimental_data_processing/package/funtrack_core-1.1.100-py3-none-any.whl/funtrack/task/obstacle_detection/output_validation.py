"""障碍物检测结果与业务预期的一致性校验（输出级闸门）。

供 ``obstacle_detection`` 策略与 ``task`` 等本仓库模块直接引用。
"""

from __future__ import annotations

from dataclasses import dataclass

from funtrack.task.obstacle_detection.frame.result import ObstacleDetectionResult


@dataclass(frozen=True)
class ObstacleOutputValidation:
    ok: bool
    reason: str = ""


class ObstacleResultExpectationValidator:
    """董事会约定：个数容差、小球/分析圆 ±20%、圆心相对画幅中心 ±15%。"""

    DEFAULT_MARKER_RADIUS_REL_TOL = 0.10
    DEFAULT_ANALYSIS_RADIUS_REL_TOL = 0.10
    DEFAULT_MARKER_COUNT_REL_FRACTION = 0.10
    DEFAULT_FRAME_CENTER_MAX_OFFSET_FRAC = 0.10

    def default_marker_count_abs_tolerance(self, expected_marker_count: int) -> int:
        """输出校验允许的 ``|检出个数−期望个数|`` 上限（至少 1）。"""
        ec = int(expected_marker_count)
        if ec <= 0:
            return 0
        return max(1, int(round(ec * float(self.DEFAULT_MARKER_COUNT_REL_FRACTION))))

    def validate_obstacle_detection_result(
        self,
        result: ObstacleDetectionResult,
        *,
        expected_marker_count: int,
        marker_diameter_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
        marker_radius_rel_tol: float | None = None,
        analysis_radius_rel_tol: float | None = None,
        marker_count_abs_tol: int | None = None,
        frame_width_px: int | None = None,
        frame_height_px: int | None = None,
        frame_center_max_offset_frac: float | None = None,
    ) -> ObstacleOutputValidation:
        """校验障碍物识别结果是否与业务预期一致。"""
        m_tol = (
            float(marker_radius_rel_tol)
            if marker_radius_rel_tol is not None
            else float(self.DEFAULT_MARKER_RADIUS_REL_TOL)
        )
        a_tol = (
            float(analysis_radius_rel_tol)
            if analysis_radius_rel_tol is not None
            else float(self.DEFAULT_ANALYSIS_RADIUS_REL_TOL)
        )
        fc_frac = (
            float(frame_center_max_offset_frac)
            if frame_center_max_offset_frac is not None
            else float(self.DEFAULT_FRAME_CENTER_MAX_OFFSET_FRAC)
        )

        try:
            ec = int(expected_marker_count)
        except (TypeError, ValueError):
            return ObstacleOutputValidation(False, "expected_marker_count 无效")
        if ec <= 0:
            return ObstacleOutputValidation(False, "expected_marker_count 须为正")

        mc = int(result.marker_count)
        tol_mc = (
            int(marker_count_abs_tol)
            if marker_count_abs_tol is not None
            else self.default_marker_count_abs_tolerance(ec)
        )
        tol_mc = max(0, tol_mc)
        if abs(mc - ec) > tol_mc:
            return ObstacleOutputValidation(
                False,
                f"障碍物个数偏差过大: 检出 marker_count={mc}, 期望={ec}, 允许偏差±{tol_mc}",
            )

        scale = float(scale_um_per_pixel)
        if scale <= 0:
            return ObstacleOutputValidation(False, "scale_um_per_pixel 须为正")

        if marker_diameter_um is not None:
            try:
                d_um = float(marker_diameter_um)
            except (TypeError, ValueError):
                d_um = 0.0
            if d_um > 0:
                r_exp_px = (d_um / scale) * 0.5
                r_obs = float(result.obstacle_marker_radius_px)
                if r_exp_px > 0:
                    lo = r_exp_px * (1.0 - m_tol)
                    hi = r_exp_px * (1.0 + m_tol)
                    if r_obs < lo or r_obs > hi:
                        return ObstacleOutputValidation(
                            False,
                            f"障碍物小球半径(px)不符: 检出={r_obs:.3f}, 期望≈{r_exp_px:.3f}, "
                            f"允许区间[{lo:.3f},{hi:.3f}] (±{int(m_tol * 100)}%)",
                        )

        if circle_analysis_radius_um is not None:
            try:
                r_um = float(circle_analysis_radius_um)
            except (TypeError, ValueError):
                r_um = 0.0
            if r_um > 0:
                r_exp_px = r_um / scale
                r_obs = float(result.radius)
                if r_exp_px > 0:
                    lo = r_exp_px * (1.0 - a_tol)
                    hi = r_exp_px * (1.0 + a_tol)
                    if r_obs < lo or r_obs > hi:
                        return ObstacleOutputValidation(
                            False,
                            f"分析圆半径(px)不符: 检出={r_obs:.3f}, 期望≈{r_exp_px:.3f}, "
                            f"允许区间[{lo:.3f},{hi:.3f}] (±{int(a_tol * 100)}%)",
                        )

        if frame_width_px is not None and frame_height_px is not None:
            try:
                fw = int(frame_width_px)
                fh = int(frame_height_px)
            except (TypeError, ValueError):
                fw, fh = 0, 0
            if fw > 0 and fh > 0 and fc_frac >= 0:
                cx_img = 0.5 * float(fw)
                cy_img = 0.5 * float(fh)

                effective_frac = float(fc_frac)
                max_dx = effective_frac * float(fw)
                max_dy = effective_frac * float(fh)
                dx = abs(float(result.center_x) - cx_img)
                dy = abs(float(result.center_y) - cy_img)
                if dx > max_dx or dy > max_dy:
                    return ObstacleOutputValidation(
                        False,
                        f"分析圆圆心须靠近图像中心(各轴±{int(effective_frac * 100)}%画幅): "
                        f"检出圆心(px)=({float(result.center_x):.2f},{float(result.center_y):.2f}), "
                        f"图像{fw}×{fh}px, 允许偏移≤dx {max_dx:.1f}px、dy {max_dy:.1f}px, "
                        f"实际偏移 dx={dx:.1f}, dy={dy:.1f}",
                    )

        return ObstacleOutputValidation(True, "")

    def validate_against_calibration(
        self,
        result: ObstacleDetectionResult,
        *,
        expected_marker_count: int,
        marker_diameter_um: float | None,
        scale_um_per_pixel: float,
        circle_analysis_radius_um: float | None,
        frame_width_px: int | None,
        frame_height_px: int | None,
        marker_radius_rel_tol: float | None = None,
        analysis_radius_rel_tol: float | None = None,
        frame_center_max_offset_frac: float | None = None,
    ) -> ObstacleOutputValidation:
        """使用业务参数 + 可选画幅做输出级校验。"""
        return self.validate_obstacle_detection_result(
            result,
            expected_marker_count=expected_marker_count,
            marker_diameter_um=marker_diameter_um,
            scale_um_per_pixel=scale_um_per_pixel,
            circle_analysis_radius_um=circle_analysis_radius_um,
            frame_width_px=frame_width_px,
            frame_height_px=frame_height_px,
            marker_radius_rel_tol=marker_radius_rel_tol,
            analysis_radius_rel_tol=analysis_radius_rel_tol,
            frame_center_max_offset_frac=frame_center_max_offset_frac,
        )


_DEFAULT_EXPECTATION_VALIDATOR = ObstacleResultExpectationValidator()

DEFAULT_MARKER_RADIUS_REL_TOL = ObstacleResultExpectationValidator.DEFAULT_MARKER_RADIUS_REL_TOL
DEFAULT_ANALYSIS_RADIUS_REL_TOL = ObstacleResultExpectationValidator.DEFAULT_ANALYSIS_RADIUS_REL_TOL
DEFAULT_MARKER_COUNT_REL_FRACTION = (
    ObstacleResultExpectationValidator.DEFAULT_MARKER_COUNT_REL_FRACTION
)
DEFAULT_FRAME_CENTER_MAX_OFFSET_FRAC = (
    ObstacleResultExpectationValidator.DEFAULT_FRAME_CENTER_MAX_OFFSET_FRAC
)


def default_marker_count_abs_tolerance(expected_marker_count: int) -> int:
    return _DEFAULT_EXPECTATION_VALIDATOR.default_marker_count_abs_tolerance(expected_marker_count)


def validate_obstacle_detection_result(
    result: ObstacleDetectionResult,
    *,
    expected_marker_count: int,
    marker_diameter_um: float | None,
    scale_um_per_pixel: float,
    circle_analysis_radius_um: float | None,
    marker_radius_rel_tol: float | None = None,
    analysis_radius_rel_tol: float | None = None,
    marker_count_abs_tol: int | None = None,
    frame_width_px: int | None = None,
    frame_height_px: int | None = None,
    frame_center_max_offset_frac: float | None = None,
) -> ObstacleOutputValidation:
    return _DEFAULT_EXPECTATION_VALIDATOR.validate_obstacle_detection_result(
        result,
        expected_marker_count=expected_marker_count,
        marker_diameter_um=marker_diameter_um,
        scale_um_per_pixel=scale_um_per_pixel,
        circle_analysis_radius_um=circle_analysis_radius_um,
        marker_radius_rel_tol=marker_radius_rel_tol,
        analysis_radius_rel_tol=analysis_radius_rel_tol,
        marker_count_abs_tol=marker_count_abs_tol,
        frame_width_px=frame_width_px,
        frame_height_px=frame_height_px,
        frame_center_max_offset_frac=frame_center_max_offset_frac,
    )
