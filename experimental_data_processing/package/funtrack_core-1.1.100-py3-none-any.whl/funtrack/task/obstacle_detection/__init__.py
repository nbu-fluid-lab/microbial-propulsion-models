"""障碍物检测：业务参数辅助函数、**识别器子类**（构造器绑定个数/半径/比例尺等）、链式编排器。

单帧几何管道入参为 ``ObstacleFrameDetectionEngine``（构造期快照）；**以图为入参** 的完整识别
与输出校验见 ``ObstacleRecognizer.recognize``。整段视频产品上由 ``ObstacleDetectionChain.run_video``
统一抽帧后对每帧跑识别器链；识别器层仅负责单帧识别，不承担视频抽帧/遍历逻辑。

视频链的 **Request / Task / Response** 与障碍物结果平面 JSON 形见
``service`` / ``image_service``（python-develop-spec：可 JSON 回归、入口与结果边界清晰）。
"""

from __future__ import annotations

from funtrack.core.utils import read_obstacle_video_frame_size_px

from .frame.engine import ObstacleFrameDetectionEngine
from .frame.hough import ObstacleFrameHoughTool
from .orchestrator import ObstacleDetectionChain
from .output_validation import (
    ObstacleOutputValidation,
    ObstacleResultExpectationValidator,
    default_marker_count_abs_tolerance,
    validate_obstacle_detection_result,
)
from .frame.recognizers import (
    BinarizedPrimaryObstacleRecognizer,
    ObstacleRecognizer,
    PrimaryObstacleRecognizer,
    RelaxedHoughObstacleRecognizer,
    TripletSmallScaleObstacleRecognizer,
    UltraRelaxedHoughObstacleRecognizer,
)
from .image_service import (
    ObstacleImageDetectionRequest,
    ObstacleImageDetectionResponse,
    run_obstacle_image_detection_request,
)
from .service import (
    ObstacleVideoDetectionRequest,
    ObstacleVideoDetectionResponse,
    run_obstacle_video_detection_request,
)

__all__ = [
    "ObstacleFrameDetectionEngine",
    "ObstacleFrameHoughTool",
    "ObstacleDetectionChain",
    "ObstacleRecognizer",
    "ObstacleOutputValidation",
    "ObstacleResultExpectationValidator",
    "BinarizedPrimaryObstacleRecognizer",
    "PrimaryObstacleRecognizer",
    "RelaxedHoughObstacleRecognizer",
    "TripletSmallScaleObstacleRecognizer",
    "UltraRelaxedHoughObstacleRecognizer",
    "default_marker_count_abs_tolerance",
    "validate_obstacle_detection_result",
    "ObstacleVideoDetectionRequest",
    "ObstacleVideoDetectionResponse",
    "ObstacleImageDetectionRequest",
    "ObstacleImageDetectionResponse",
    "read_obstacle_video_frame_size_px",
    "run_obstacle_image_detection_request",
    "run_obstacle_video_detection_request",
]
