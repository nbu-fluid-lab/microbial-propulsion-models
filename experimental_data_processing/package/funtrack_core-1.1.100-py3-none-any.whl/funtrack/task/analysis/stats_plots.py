"""运动学结果统计与可视化（DataFrame 版本）。"""

from pathlib import Path

import numpy as np
import pandas as pd
from nltlog import getLogger

from .utils import filter_tracks

logger = getLogger("funtrack")

KINEMATICS_REQUIRED_FOR_ANALYZER = ["idx", "frame", "time", "speed", "angular_velocity"]


def load_kinematics(df: pd.DataFrame) -> pd.DataFrame:
    """校验运动学 DataFrame。"""
    out = df.copy()
    out.columns = out.columns.str.strip()
    missing = [c for c in KINEMATICS_REQUIRED_FOR_ANALYZER if c not in out.columns]
    if missing:
        raise ValueError(f"运动学结果缺少列: {missing}")
    return out


def compute_speed_angular_stats(df: pd.DataFrame) -> dict:
    """计算速度与角速度统计量。"""
    valid = df[(df["speed"].notna()) & (df["angular_velocity"].notna()) & (df["speed"] >= 0)].copy()
    if len(valid) == 0:
        return {}
    speed = valid["speed"]
    ang = valid["angular_velocity"]
    corr = np.corrcoef(speed, ang)[0, 1] if len(valid) > 1 else np.nan
    return {
        "n_points": len(valid),
        "n_tracks": int(valid["idx"].nunique()),
        "speed_mean": float(speed.mean()),
        "speed_std": float(speed.std()),
        "speed_max": float(speed.max()),
        "angular_velocity_mean_abs": float(ang.abs().mean()),
        "angular_velocity_std": float(ang.std()),
        "angular_velocity_max_abs": float(ang.abs().max()),
        "correlation_speed_angular": float(corr) if not np.isnan(corr) else None,
    }


def analyze_tracks(
    df: pd.DataFrame,
    min_points=100,
    max_speed=None,
    max_angular_velocity=None,
):
    """过滤轨迹并返回过滤结果。"""
    src = load_kinematics(df)
    return filter_tracks(
        src,
        min_points=min_points,
        max_speed=max_speed,
        max_angular_velocity=max_angular_velocity,
    )


def analyze_and_visualize(
    df: pd.DataFrame,
    output_dir=None,
    output_prefix: str = "",
    min_points=100,
    max_speed=None,
    max_angular_velocity=None,
):
    """兼容旧接口：仅执行过滤并返回结果。"""
    _ = (Path(output_dir) if output_dir else None, output_prefix)
    return analyze_tracks(
        df=df,
        min_points=min_points,
        max_speed=max_speed,
        max_angular_velocity=max_angular_velocity,
    )


def plot_scatter(df, output_path=None):
    _ = (df, output_path)
    logger.info("scatter 绘图在新版 Web 前端完成")
