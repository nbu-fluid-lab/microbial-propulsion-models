"""轨迹分析工具函数：平滑、速度/角速度计算、过滤。"""

import numpy as np
import pandas as pd
from nltlog import getLogger
from scipy import signal
from scipy.ndimage import uniform_filter1d

logger = getLogger("funtrack")


def smooth_tracks(df, method="moving_average", window_size=5, alpha=0.3):
    """对轨迹进行平滑（供 kinematics 使用）。"""
    df = df.copy()
    df = df.sort_values(by=["idx", "frame"])
    df["x_raw"] = df["x"].copy()
    df["y_raw"] = df["y"].copy()
    for track_id in df["idx"].unique():
        track_mask = df["idx"] == track_id
        track_data = df[track_mask].copy()
        if len(track_data) < 3:
            continue
        if method == "moving_average":
            window = min(window_size, len(track_data))
            if window % 2 == 0:
                window += 1
            df.loc[track_mask, "x"] = uniform_filter1d(
                track_data["x"].values, size=window, mode="nearest"
            )
            df.loc[track_mask, "y"] = uniform_filter1d(
                track_data["y"].values, size=window, mode="nearest"
            )
        elif method == "exponential":
            df.loc[track_mask, "x"] = track_data["x"].ewm(alpha=alpha, adjust=False).mean().values
            df.loc[track_mask, "y"] = track_data["y"].ewm(alpha=alpha, adjust=False).mean().values
        elif method == "savgol":
            window = min(window_size, len(track_data))
            if window % 2 == 0:
                window += 1
            polyorder = min(3, window - 1)
            if len(track_data) >= window:
                df.loc[track_mask, "x"] = signal.savgol_filter(
                    track_data["x"].values, window, polyorder, mode="nearest"
                )
                df.loc[track_mask, "y"] = signal.savgol_filter(
                    track_data["y"].values, window, polyorder, mode="nearest"
                )
    return df


def calculate_velocity(df, scale_um_per_pixel=1.0):
    """
    计算速度 vx, vy, speed（供 kinematics 使用），单位均为 μm/s。

    参数:
        df: 含 idx, frame, time, x, y 的轨迹 DataFrame
        scale_um_per_pixel: 比例尺，单位 微米/像素（1 表示 1 微米/像素）

    返回:
        添加 vx, vy, speed 列的 DataFrame，单位 μm/s
    """
    df = df.copy()
    df = df.sort_values(by=["idx", "frame"])
    df["dx"] = df.groupby("idx")["x"].diff()
    df["dy"] = df.groupby("idx")["y"].diff()
    df["dt"] = df.groupby("idx")["time"].diff()
    df["vx"] = df["dx"] / df["dt"].replace(0, np.nan)
    df["vy"] = df["dy"] / df["dt"].replace(0, np.nan)
    df["speed"] = np.sqrt(df["vx"] ** 2 + df["vy"] ** 2)
    df["vx"] = df["vx"].fillna(0)
    df["vy"] = df["vy"].fillna(0)
    df["speed"] = df["speed"].fillna(0)
    df["vx"] = df["vx"] * scale_um_per_pixel
    df["vy"] = df["vy"] * scale_um_per_pixel
    df["speed"] = df["speed"] * scale_um_per_pixel
    return df


def calculate_angle(df):
    """计算朝向 angle（弧度，供 kinematics 使用）。"""
    df = df.copy()
    df["angle"] = np.arctan2(df["vy"], df["vx"])
    df["angle"] = df["angle"] % (2 * np.pi)
    return df


def calculate_angular_velocity(df):
    """计算角速度 angular_velocity（供 kinematics 使用）。"""
    df = df.copy()
    df = df.sort_values(by=["idx", "frame"])
    df["dangle"] = df.groupby("idx")["angle"].diff()
    df["dangle"] = df["dangle"].apply(
        lambda x: (
            x - 2 * np.pi
            if x > np.pi
            else (x + 2 * np.pi if x < -np.pi else x)
            if pd.notna(x)
            else 0
        )
    )
    df["dt"] = df.groupby("idx")["time"].diff()
    df["angular_velocity"] = df["dangle"] / df["dt"].replace(0, np.nan)
    df["angular_velocity"] = df["angular_velocity"].fillna(0)
    return df


def filter_tracks(df, min_points=100, max_speed=None, max_angular_velocity=None):
    """
    按轨迹点数、速度、角速度过滤（输入需含 idx, speed, angular_velocity）。
    返回: (df_filtered, removed_track_ids).
    """
    df = df.copy()
    track_counts = df.groupby("idx").size()
    valid_tracks = track_counts[track_counts >= min_points].index
    df_filtered = df[df["idx"].isin(valid_tracks)].copy()
    removed_tracks = track_counts[track_counts < min_points].index.tolist()
    if removed_tracks:
        logger.info(
            f"过滤短轨迹: 移除了 {len(removed_tracks)} 条轨迹（少于 {min_points} 个数据点）"
        )
    if max_speed is not None:
        before = len(df_filtered)
        df_filtered = df_filtered[df_filtered["speed"] <= max_speed]
        if before - len(df_filtered) > 0:
            logger.info(
                f"过滤异常速度: 移除了 {before - len(df_filtered)} 个数据点（速度 > {max_speed}）"
            )
    if max_angular_velocity is not None:
        before = len(df_filtered)
        df_filtered = df_filtered[df_filtered["angular_velocity"].abs() <= max_angular_velocity]
        if before - len(df_filtered) > 0:
            logger.info(f"过滤异常角速度: 移除了 {before - len(df_filtered)} 个数据点")
    return df_filtered, removed_tracks
