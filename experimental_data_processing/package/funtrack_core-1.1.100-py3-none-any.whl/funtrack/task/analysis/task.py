"""轨迹数据分析任务（由上层注入 DataFrame 输入）。"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict

from nltlog import getLogger
import pandas as pd

from funtrack.task.analysis.stats_plots import (
    KINEMATICS_REQUIRED_FOR_ANALYZER,
    analyze_and_visualize,
    compute_speed_angular_stats,
)
from funtrack.core import BaseTask, FuntrackTaskRequest

logger = getLogger("funtrack")


@dataclass
class TrajectoryDataRequest(FuntrackTaskRequest):
    results_db_path: str = ""
    video_id: int = 0
    min_points: int = 100
    max_speed: Any | None = None
    max_angular_velocity: Any | None = None
    analysis_extras: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TrajectoryDataRequest:
        payload = dict(data or {})
        known = set(cls.__dataclass_fields__) - {"analysis_extras"}
        ctor: dict[str, Any] = {}
        extras: dict[str, Any] = {}
        ae = payload.get("analysis_extras")
        if isinstance(ae, dict):
            extras.update(ae)
        for k, v in payload.items():
            if k == "analysis_extras":
                continue
            if k in known:
                ctor[k] = v
            else:
                extras[k] = v
        if extras:
            ctor["analysis_extras"] = extras
        return cls(**{k: v for k, v in ctor.items() if k in cls.__dataclass_fields__})


class TrajectoryDataTask(BaseTask):
    """基于 201 运动学表进行统计过滤。"""

    task_name = "302"

    def __init__(self, request: TrajectoryDataRequest):
        super().__init__(request)

    def validate_inputs(self) -> bool:
        db = str(self.request.results_db_path or "").strip()
        if db:
            p = Path(db)
            if not p.exists():
                logger.error(f"结果数据库不存在: {p}")
                return False
        return True

    def get_output_paths(self) -> dict[str, Path]:
        return {"results_db": Path(self.request.results_db_path)}

    def get_task_inputs(self) -> dict[str, Any]:
        r = self.request
        return {
            "results_db_path": str(Path(r.results_db_path)),
            "video_id": int(r.video_id),
            "min_points": r.min_points,
            "max_speed": r.max_speed,
            "max_angular_velocity": r.max_angular_velocity,
            "required_kinematics_columns": list(KINEMATICS_REQUIRED_FOR_ANALYZER),
        }

    def get_dependencies(self) -> list[Any]:
        return []

    def get_task_results(self) -> dict[str, Any] | None:
        if not self.results:
            return None
        df = self.results.get("df")
        removed = self.results.get("removed_tracks", [])
        if df is None:
            return {"removed_tracks_count": len(removed)}
        return {
            "data_points": len(df),
            "tracks": int(df["idx"].nunique()) if len(df) > 0 else 0,
            "removed_tracks_count": len(removed),
        }

    def apply_output_paths(self, paths: dict[str, Path]) -> None:
        _ = paths

    def get_skip_return_value(self, record: dict[str, Any]) -> tuple[None, list[Any]]:
        _ = record
        return (None, [])

    def _run(
        self,
        *,
        kinematics_df: pd.DataFrame,
        statistics_df: pd.DataFrame | None = None,
        **kwargs: Any,
    ) -> tuple[pd.DataFrame, list[Any]]:
        """执行轨迹分析（纯计算）：显式输入 ``kinematics_df``，可选 ``statistics_df``。"""
        r = self.request
        params = {
            "min_points": r.min_points,
            "max_speed": r.max_speed,
            "max_angular_velocity": r.max_angular_velocity,
        }
        params.update(r.analysis_extras or {})
        extra = dict(kwargs)
        if not isinstance(kinematics_df, pd.DataFrame):
            raise TypeError("kinematics_df 必须为 pandas.DataFrame")
        df_kin = kinematics_df.copy()
        if len(df_kin.columns) > 0:
            df_kin.columns = df_kin.columns.str.strip()
        params.update(extra)
        self.print_info(
            Input_DataFrame=f"kinematics_df rows={len(df_kin)}",
            Output_DataFrame="analysis_filtered_df",
        )
        if len(df_kin) == 0:
            self.results = {"df": df_kin, "removed_tracks": []}
            return df_kin, []
        missing = [c for c in KINEMATICS_REQUIRED_FOR_ANALYZER if c not in df_kin.columns]
        if missing:
            raise ValueError(f"kinematics_df 缺少分析必需列: {missing}")

        if statistics_df is None:
            df_stats = pd.DataFrame()
        elif not isinstance(statistics_df, pd.DataFrame):
            raise TypeError("statistics_df 必须为 pandas.DataFrame")
        else:
            df_stats = statistics_df
        if len(df_stats) > 0 and "idx" in df_stats.columns and "is_filtered" in df_stats.columns:
            col = df_stats["is_filtered"]
            valid_indices = (
                df_stats.loc[~col, "idx"].tolist()
                if col.dtype == bool
                else df_stats.loc[
                    ~col.astype(str).str.strip().str.lower().isin(["true", "1"]), "idx"
                ].tolist()
            )
            df_for_analysis = df_kin[df_kin["idx"].isin(valid_indices)].copy()
        else:
            df_for_analysis = df_kin

        df, removed_tracks = analyze_and_visualize(df=df_for_analysis, **params)
        self.results = {"df": df, "removed_tracks": removed_tracks}
        return df, removed_tracks

    def print_summary(self):
        if not self.results or self.results.get("df") is None:
            return
        df = self.results["df"]
        if len(df) == 0:
            return
        stats = compute_speed_angular_stats(df)
        sm = float(stats.get("speed_mean", 0.0))
        logger.info(
            f"302 summary: points={len(df)} tracks={int(df['idx'].nunique())} speed_mean={sm:.4f}"
        )
