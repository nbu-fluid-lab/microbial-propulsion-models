# task 模块说明

`funtrack.task` 是业务任务层，按领域拆分为多个子目录。每个任务通常包含：

- `*Request`：任务入参
- `*Task`：任务执行逻辑（继承 `BaseTask`）
- 同目录 `utils` / `engine` / `plot`：该任务的辅助实现

## 任务总览

| 领域目录 | 主要 Task | 任务编号 | 入口文件 | 主要输入 | 主要输出 | 简要说明 |
|---|---|---|---|---|---|---|
| `tracking` | `TrajectoryTrackingTask` | `101` | `task/tracking/task.py` | 原始视频路径 + 跟踪参数 | 轨迹识别结果（写入 `tracks_101`） | 从视频识别并跟踪颗粒轨迹，是后续运动学和统计的上游。 |
| `kinematics` | `ParticleKinematicsTask` | `201` | `task/kinematics/task.py` | `tracks_101` + 比例尺 | 运动学表 `kinematics_201` | 把轨迹转换为速度、角度、角速度等时序运动学数据。 |
| `statistics` | `ParticleStatisticsTask` | `202` | `task/statistics/task.py` | `kinematics_201` + 画幅尺寸/比例尺 | 统计表 `statistics_202` | 按颗粒聚合统计时长、位移、距离、速度范围，并给出过滤标记。 |
| `circle` | `CircleRegionTask` | `301` | `task/circle/task.py` | `kinematics_201`（可结合 `statistics_202`）+ 圆参数 | 穿圈段结果与圆分析输出（落库） | 执行圆区域分析；无障碍物走动态圆，有障碍物走固定圆。 |
| `analysis` | `TrajectoryDataTask` | `302` | `task/analysis/task.py` | `kinematics_201` + 分析阈值 | 统计结果/图表与过滤结果 | 对运动学数据做统计分析与可视化，用于诊断与报告。 |
| `video` | `VideoInfoTask` | `video_info` | `task/video/task.py` | 原始视频路径 | 视频元信息 JSON | 提取视频基础信息（尺寸、帧数、fps、时长等）。 |

## 典型执行链路

常见流水线顺序如下：

1. `tracking (101)`：从视频得到轨迹。
2. `kinematics (201)`：由轨迹计算速度/角速度等运动学。
3. `statistics (202)`：按颗粒聚合统计并标记过滤状态。
4. `circle (301)`：基于运动学（可参考 202 过滤）做圆区域分析。
5. `analysis (302)`：做统计分析与可视化输出。

`video_info` 可独立运行，通常用于前置检查或补充元数据。

## 任务间依赖关系（当前代码）

当前有少量跨域复用关系：

- `circle/task.py` 会调用 `obstacle_detection` 的入口与校验，用于障碍物固定圆识别。
- `kinematics/task.py` 复用 `analysis/utils.py` 的速度与角速度计算函数。

其余任务大多在各自目录内完成核心逻辑，跨域耦合较少。

## obstacle_detection 的定位

`obstacle_detection` 位于 `task` 同级目录，主要服务 `circle` 的障碍物固定圆识别场景。对外推荐入口：

- `run_obstacle_video_detection_request(request: ObstacleVideoDetectionRequest) -> ObstacleVideoDetectionResponse`

详细说明见：`funtrack/task/obstacle_detection/README.md`。

