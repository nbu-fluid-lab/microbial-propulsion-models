from funtrack.task.video.task import VideoInfoRequest, VideoInfoTask

__all__ = ["VideoInfoRequest", "VideoInfoTask"]
