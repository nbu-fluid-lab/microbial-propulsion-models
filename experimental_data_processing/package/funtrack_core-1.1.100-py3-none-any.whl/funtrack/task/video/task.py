"""
视频基础信息分析任务
分析原始视频的元数据（路径、文件大小、尺寸、高宽比、帧数等），结果保存为 JSON。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

from nltlog import getLogger

from funtrack.core import BaseTask, FuntrackTaskRequest
from funtrack.utils import extract_video_info

logger = getLogger("funtrack")


@dataclass
class VideoInfoRequest(FuntrackTaskRequest):
    video_path: str = ""


class VideoInfoTask(BaseTask):
    """视频基础信息任务：提取路径、文件大小、尺寸、高宽比、帧数等，保存为 JSON"""

    task_name = "video_info"

    def __init__(self, request: VideoInfoRequest):
        super().__init__(request)
        self.output_json = None

    def validate_inputs(self) -> bool:
        vp = Path(self.request.video_path)
        if not vp.exists():
            logger.error(f"视频文件不存在: {vp}")
            return False
        return True

    def get_output_paths(self) -> Dict[str, Path]:
        base = Path(self.request.video_path).stem
        prefix = self.output_prefix if self.output_prefix else ""
        return {
            "json": self.output_dir / f"{prefix}{base}_video_info.json",
        }

    def get_task_inputs(self):
        return {"video_path": str(Path(self.request.video_path))}

    def get_task_results(self):
        return self.results.get("info") if self.results else None

    def apply_output_paths(self, paths):
        self.output_json = paths.get("json")

    def _results_from_skip_record(self, record):
        return {"info": record.get("results")}

    def get_skip_return_value(self, record):
        return record.get("results")

    def _run(self, **kwargs) -> Dict[str, Any]:
        _ = kwargs
        paths = self.get_output_paths()
        self.output_json = paths["json"]
        video = str(Path(self.request.video_path))

        self.print_info(Input_Video=video, Output_JSON=str(self.output_json))

        info = extract_video_info(video)
        if "error" in info:
            logger.warning(f"视频信息提取不完整: {info['error']}")

        with open(self.output_json, "w", encoding="utf-8") as f:
            json.dump(info, f, ensure_ascii=False, indent=2)

        logger.info(f"视频信息已保存: {self.output_json}")
        self.results = {"info": info}
        return info

    def print_summary(self):
        info = None
        if self.output_json and Path(self.output_json).exists():
            try:
                with open(self.output_json, encoding="utf-8") as f:
                    info = json.load(f)
            except (json.JSONDecodeError, OSError):
                pass
        if info is None and self.results and "info" in self.results:
            info = self.results["info"]
        if not info:
            return
        if "error" in info:
            logger.warning(f"视频信息异常: {info['error']}")
            return
        logger.info("=" * 60)
        logger.info("Video Info Summary")
        logger.info("=" * 60)
        logger.info(f"  path: {info.get('path', '')}")
        logger.info(f"  file_size_bytes: {info.get('file_size_bytes')}")
        logger.info(f"  width x height: {info.get('width')} x {info.get('height')}")
        logger.info(f"  aspect_ratio: {info.get('aspect_ratio')}")
        logger.info(f"  frame_count: {info.get('frame_count')}")
        logger.info(f"  fps: {info.get('fps')}")
        logger.info(f"  duration_sec: {info.get('duration_sec')}")
        logger.info("=" * 60)
