"""
颗粒运动学任务：由上层注入的 tracks DataFrame 生成每颗粒每时刻运动学基础表。

**单位约定（输出 kinematics_201 等价 DataFrame）**
- ``x``, ``y``：**微米（μm）**，由 tracks 像素坐标 × 任务请求中的 ``scale_um_per_pixel``（流水线从 ``videos.scale_um_per_pixel`` 注入）得到。
- ``vx``, ``vy``, ``speed``：**微米/秒（μm/s）**。
- ``tracks_101`` 的 ``x``, ``y`` 仍为**像素（px）**，不在此任务改写。
"""

import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import pandas as pd
from nltlog import getLogger

from funtrack.task.analysis.utils import (
    calculate_angle,
    calculate_angular_velocity,
    calculate_velocity,
    smooth_tracks,
)
from funtrack.core import BaseTask, FuntrackTaskRequest

logger = getLogger("funtrack")

KINEMATICS_COLUMNS = [
    "idx",
    "frame",
    "time",
    "x",
    "y",
    "angle",
    "cumulative_angle_rad",
    "speed",
    "vx",
    "vy",
    "angular_velocity",
]

TRACKS_REQUIRED_COLUMNS = ["frame", "idx", "x", "y"]
"""计算运动学所需的最小 tracks 字段集合。"""


@dataclass
class ParticleKinematicsRequest(FuntrackTaskRequest):
    tracks_db_path: str = ""
    video_id: int = 0
    smooth: bool = False
    smooth_method: str = "moving_average"
    smooth_window: int = 5
    smooth_alpha: float = 0.3
    scale_um_per_pixel: float = 1.0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ParticleKinematicsRequest":
        payload = dict(data or {})
        allowed = {
            "tracks_db_path",
            "video_id",
            "output_dir",
            "output_prefix",
            "overwrite",
            "request_id",
            "meta",
            "smooth",
            "smooth_method",
            "smooth_window",
            "smooth_alpha",
            "scale_um_per_pixel",
        }
        return cls(**{k: v for k, v in payload.items() if k in allowed})

    def to_dict(self) -> dict[str, Any]:
        return super().to_dict()


class ParticleKinematicsTask(BaseTask):
    """颗粒运动学任务：由轨迹表生成每颗粒每时刻的运动学基础表。"""

    task_name = "201"

    def __init__(self, request: ParticleKinematicsRequest):
        super().__init__(request)
        self.output_ref = None

    def validate_inputs(self) -> bool:
        db = str(self.request.tracks_db_path or "").strip()
        if db:
            p = Path(db)
            if not p.exists():
                logger.error(f"tracks_db_path not found: {p}")
                return False
        return True

    def get_output_paths(self) -> dict[str, Path]:
        return {"results_db": Path(self.request.tracks_db_path)}

    def get_task_inputs(self) -> dict[str, Any]:
        r = self.request
        return {
            "tracks_db_path": str(Path(r.tracks_db_path)),
            "video_id": int(r.video_id),
            "smooth": bool(r.smooth),
            "smooth_method": r.smooth_method,
            "smooth_window": int(r.smooth_window),
            "smooth_alpha": float(r.smooth_alpha),
            "scale_um_per_pixel": float(r.scale_um_per_pixel),
            "required_tracks_columns": list(TRACKS_REQUIRED_COLUMNS),
        }

    def get_dependencies(self) -> list[Any]:
        return []

    def get_task_results(self) -> dict[str, Any] | None:
        if not self.results or self.results.get("df") is None:
            return None
        df = self.results["df"]
        return {
            "data_points": len(df),
            "tracks": int(df["idx"].nunique()) if len(df) > 0 else 0,
        }

    def apply_output_paths(self, paths: dict[str, Path]) -> None:
        self.output_ref = None

    def _results_from_skip_record(self, record: dict[str, Any]) -> dict[str, Any]:
        return record.get("results") or {}

    def get_skip_return_value(self, record: dict[str, Any]) -> pd.DataFrame | None:
        if self.results and self.results.get("df") is not None:
            return self.results["df"]
        return None

    def _run(self, *, tracks_df: pd.DataFrame, **kwargs: Any) -> pd.DataFrame:
        """执行运动学计算（纯计算）：显式输入 ``tracks_df``，输出运动学 DataFrame。"""
        r = self.request
        _ = kwargs
        if not isinstance(tracks_df, pd.DataFrame):
            raise TypeError("tracks_df 必须为 pandas.DataFrame")
        df = tracks_df.copy()
        if len(df.columns) > 0:
            df.columns = df.columns.str.strip()
        missing = [c for c in TRACKS_REQUIRED_COLUMNS if c not in df.columns]
        self.print_info(
            Input_DataFrame=f"tracks_df rows={len(df)}",
            Output_DataFrame="kinematics_201_like_df",
        )
        # 无轨迹或表缺失：返回空 kinematics DataFrame，供 202/301 正常结束
        if df.empty:
            if missing:
                logger.info(
                    f"轨迹数据为空或不可用（缺列 {missing}），返回空 kinematics DataFrame（0 颗粒）"
                )
            out = pd.DataFrame(columns=KINEMATICS_COLUMNS)
            self.results = {"df": out}
            return out
        if missing:
            logger.error(f"轨迹表缺少列: {missing}")
            raise ValueError(f"trajectory table missing columns: {missing}")
        if "time" not in df.columns:
            df["time"] = df["frame"]
        df = df.sort_values(by=["idx", "frame"])

        if r.smooth:
            df = smooth_tracks(
                df,
                method=r.smooth_method,
                window_size=int(r.smooth_window),
                alpha=float(r.smooth_alpha),
            )
        else:
            df["x_raw"] = df["x"].copy()
            df["y_raw"] = df["y"].copy()

        df = calculate_velocity(df, scale_um_per_pixel=float(r.scale_um_per_pixel))
        df = calculate_angle(df)
        df = calculate_angular_velocity(df)

        df["cumulative_angle_rad"] = df["dangle"].fillna(0).groupby(df["idx"]).cumsum()

        out = df[["idx", "frame", "time", "x", "y"]].copy()
        s_req = float(r.scale_um_per_pixel)
        s_eff = s_req if (s_req > 0 and math.isfinite(s_req)) else 1.0
        out["x"] = out["x"].astype(float) * s_eff
        out["y"] = out["y"].astype(float) * s_eff
        out["angle"] = df["angle"].values
        out["cumulative_angle_rad"] = df["cumulative_angle_rad"].values
        out["speed"] = df["speed"].values
        out["vx"] = df["vx"].values
        out["vy"] = df["vy"].values
        out["angular_velocity"] = df["angular_velocity"].values

        logger.info(f"颗粒运动学计算完成，输出行数={len(out)}")

        self.results = {"df": out}
        return out

    def print_summary(self):
        df = self.results["df"] if self.results and self.results.get("df") is not None else None
        if df is None or len(df) == 0:
            return
        logger.info("=" * 60)
        logger.info(
            "Particle Kinematics Summary (坐标, 朝向/累积角, 速度/绝对值/vx/vy, 角速度/绝对值)"
        )
        logger.info("=" * 60)
        logger.info(f"Data points: {len(df)}, Tracks: {df['idx'].nunique()}")
        if "speed" in df.columns:
            logger.info(
                f"  Mean speed: {df['speed'].mean():.4f} μm/s, Max: {df['speed'].max():.4f} μm/s"
            )
        if "vx" in df.columns and "vy" in df.columns:
            logger.info(
                f"  vx range: [{df['vx'].min():.2f}, {df['vx'].max():.2f}], vy: [{df['vy'].min():.2f}, {df['vy'].max():.2f}]"
            )
        if "angular_velocity" in df.columns:
            logger.info(
                f"  Mean |angular_velocity|: {df['angular_velocity'].abs().mean():.4f} rad/s"
            )
        if "cumulative_angle_rad" in df.columns:
            logger.info(
                f"  Cumulative angle (rad) range: [{df['cumulative_angle_rad'].min():.2f}, {df['cumulative_angle_rad'].max():.2f}]"
            )
        logger.info("=" * 60)
